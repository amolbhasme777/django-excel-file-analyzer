#!/bin/bash

# Run the python file
cd /root/protel_PMS_web_scraper_v1/nextgen_rotrip_vaya_code/protel_vaya_scraper/protel_vaya_scraper || exit

# Activate the virtual environment (if necessary)
source /root/protel_PMS_web_scraper_v1/venv/bin/activate

python data_processing_script.py
