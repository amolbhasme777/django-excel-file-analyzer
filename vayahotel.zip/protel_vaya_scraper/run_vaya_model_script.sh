#!/bin/bash

# Run the python file
cd /root/protel_PMS_web_scraper_v1/nextgen_rotrip_vaya_code/protel_vaya_scraper/protel_vaya_scraper || exit

# Activate the virtual environment (if necessary)
source ../../../venv/bin/activate

python vaya_model_mail.py
