import importlib.util
import logging
import os
import mariadb
from mariadb import Error
import mysql
from scrapy.utils.project import get_project_settings

# Accessing settings
settings = get_project_settings()

# Accessing settings without using strings
common_constant_path = settings.get("COMMON_CONSTANT_PATH")
common_constant_file_name = settings.get("COMMON_CONSTANT_FILE_NAME")
protel_config_path = settings.get("PROTEL_CONFIG_PATH")
protel_config_file_name = settings.get("PROTEL_CONFIG_FILE_NAME")


def import_module_from_file(file_name, module_name):
    """
    The function imports a module from a file using the file name and module name.

    :param file_name: The name of the file that you want to import from. This should include the file
    extension (e.g., "myfile.py")
    :param module_name: The name of the module you want to import from the file. This is the name that
    you will use to reference the imported module in your code
    :return: the imported module.
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    file_path = os.path.join(parent_dir, file_name)
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Importing common_constant and config module
const = import_module_from_file(common_constant_path, common_constant_file_name)
config = import_module_from_file(protel_config_path, protel_config_file_name)


# The class `DatabaseConnection` initializes a connection attribute and establishes a connection.
class DatabaseConnection:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        """
        The `connect` function establishes a connection to a MariaDB database using the provided configuration
        parameters.
        """
        try:
            HOSTNAME = config.HOSTNAME
            USERNAME = config.USERNAME
            PASSWORD = config.PASSWORD
            DATABASE = config.DATABASE
            PORT = config.PORT

            self.connection = mysql.connector.connect(
                user=USERNAME,
                password=PASSWORD,
                host=HOSTNAME,
                port=PORT,
                database=DATABASE,
            )
        except Error as connection_error:
            logging.error(
                f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {connection_error}"
            )

    def close(self):
        if self.connection is not None:
            self.connection.close()
