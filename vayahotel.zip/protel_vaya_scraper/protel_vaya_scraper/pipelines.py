# Define your item pipelines here
# Don't forget to add your pipeline to the ITEM_PIPELINES setting

# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
# useful for handling different item types with a single interface
import logging
from . import common_constant as const
from protel_vaya_scraper.protel_database_connection import DatabaseConnection

logging.basicConfig(level=logging.DEBUG)

class ProtelVayaScraperPipeline:
    """
    This pipeline is used to fetch data from the database and generate Excel reports.
    It also handles closing the MySQL connection and cursor.
    """

    def __init__(self):
        try:
            self.db_conn = DatabaseConnection()
        except Exception as connection_error:
            logging.error(
                f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {connection_error}"
            )

    def process_item(self, item, spider):
        return item
  
    def close_spider(self, spider):
        """
        The `close_spider` function closes the MySQL connection, with error handling.

        :param spider: The `spider` parameter is an instance of the spider class that is being closed
        """

        try:
            cursor = self.db_conn.connection.cursor()    
            if hasattr(self, const.CONST_CURSOR):
                cursor.close()
            if hasattr(self, const.CONST_CONNECTION):
                self.db_conn.close()
        except Exception as exp:
            logging.error(f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {exp}")
