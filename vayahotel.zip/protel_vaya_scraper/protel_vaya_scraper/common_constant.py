####################### Protel Vaya Constant ###########################
import numpy as np

AUTH_TOKEN = None

#Flag to download and parse report invoice jpg
DOWNLOAD_PARSE_INVOICE = False

# Protel constants
CONST_PROTEL_LOGIN_URL = "https://app.protel.net/login"
CONST_PROTEL_PMS_API_URL = "https://cloudservices.protel.net/phr-gw/api/properties/pms/login?pmsTypesFilter=PROTELAIR"
CONST_PROTEL_RESERVATION_STATES_API_URL = (
    "https://app.protel.net/app-backend/api/3/system/reservationStates?format=json"
)
CONST_PROTEL_RESERVATION_PERIOD_API_URL = (
    "https://app.protel.net/reservationservice/api/v1/reservations/created-on"
)
CONST_PROTEL_ROOM_PLAN_API_URL = "https://app.protel.net/app-backend/api/ng/v1/roomPlan?format=json&start={start}&end={end}"
CONST_PROTEL_REPORT_DEFINITION_API_URL = (
    "https://app.protel.net/app-backend/api/ext/reportdefinitions?node=root"
)
CONST_PROTEL_PRINT_REPORT_API_URL = (
    "https://app.protel.net/app-backend/api/ext/reports/printReportAsTask/XLSX"
)
CONST_PROTEL_REPORT_TASK_DOWNLOAD = (
    "https://app.protel.net/app-backend/api/ng/v1/tasks/task/{}"
)
CONST_PROTEL_REPORT_DOWNLOAD_API_URL = (
    "https://app.protel.net/app-backend/VFSServlet?token={filetoken}"
)
CONST_PROTEL_ROOMTYPE_API_URL = (
    "https://app.protel.net/app-backend/api/ng/v1/system/roomTypes?type=all&format=json"
)
CONST_PROTEL_GUEST_PROFILE_API_URL = (
    "https://app.protel.net/app-backend/api/ng/v1/guests/guest/{guest_id}?format=json"
)
CONST_PROTEL_MEAL_PLAN_API_URL =  (
    "https://app.protel.net/app-backend/api/ext/activelists/config/MEALPLAN?listBase=ELEMENT&listType=MEALPLAN&userDefinedList=&grid=true"
)

CONST_PROTEL_MEAL_PLAN_DETAIL_API_URL = (
    "https://app.protel.net/app-backend/api/ext/activelists/activelist/MEALPLAN?listBase=ELEMENT&userDefinedList=&grid=true&filter=rates=%5B{rates_ids}%5D;mealcodes=%5B{mealcodes_ids}%5D;categories=%5B{categories_ids}%5D;reservationStates=%5B{reservation_states_ids}%5D;pageSize=1000;validfrom={start_date};validto={end_date}&validfrom={start_date}&validto={end_date}"
)
CONST_PROTEL_REPORT_INVOICE_FILTER = ["Halbpension", "Frühstück", "Logis"]
CONST_PROTEL_OUTPUT_LOG = "logs/protel.log"
CONST_PROTEL_ERROR_LOG = "logs/error.log"
CONST_VAYA_MODEL_LOG = "logs/vaya_model.log"
CONST_PROTEL_CREATED_BY = "protel"
CONST_END_DATE = None
CONST_USERNAME_FIELD = "username"
CONST_PASSWORD_FIELD = "password"
CONST_VAYA_CONTENT_TYPE = "Content-Type"
CONST_VAYA_APPLICATION_JSON = "application/json"
CONST_XLSX_EXTENSION = ".xlsx"
CONST_CSV_EXTENSION =  ".csv"


CONST_PROTEL_REPORT_INVOICE_FOLDER = "protel_report_files/invoice"
CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_FOLDER = (
    "protel_report_files/distributed_channel"
)
CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_STATS_FOLDER = (
    "protel_report_files/distributed_channel_stats"
)
CONST_PROTEL_REPORT_HS_FOLDER = "protel_report_files/hotel_status"
CONST_PROTEL_REPORT_HSBT_FOLDER = "protel_report_files/hotel_status_book_type"
CONST_PROTEL_REPORT_HSBR_FOLDER = "protel_report_files/hotel_status_room_type"

# Suffixes
CONST_PROTEL_HSBT_SUFFIX = "HouseStateByBookingType_"
CONST_PROTEL_HS_SUFFIX = "HouseState_"
CONST_PROTEL_HSBR_SUFFIX = "HouseStateSortedByRooms_"
CONST_PROTEL_DC_STATS_SUFFIX = "ReservationCodeAnalysisChannel_"
CONST_PROTEL_DC_SUFFIX = "Channels_"
CONST_PROTEL_INVOICE_JPG_SUFFIX = "JournalItem_"

CONST_AUTHORIZATION = "Authorization"

CONST_PROTEL_GLOBALHOTELID = "globalHotelId"
CONST_PROTEL_HOTELID = "hotelId"
CONST_PROTEL_SPIDER_NAME = "protel"

CONST_PROTEL_PROPERTY_ID = "property_id"
CONST_PROTEL_PROPERTY_NAME = "property_name"
CONST_PROTEL_REPORT_DEFINITION_DETAILS = "report_definition_details"

CONST_PROTEL_INVOICE_SECTION = "Rechnung"
CONST_PROTEL_RESERVATION_SECTION = "Reservierung"
CONST_PROTEL_CHANNELS = "Channels"
CONST_PROTEL_DC_STATS_CHANNEL = "ReservationCodeAnalysisChannel"
CONST_PROTEL_HOUSESTATE = "HouseState"
CONST_PROTEL_INVOICE_REPORT_SECTION = "JournalItem"
CONST_PROTEL_HSBT = "HouseStateByBookingType"
CONST_PROTEL_HSBR = "HouseStateSortedByRooms"
CONST_PROTEL_REPORT_DEFINITION_EXTLIST = "reportDefinitionExtList"
CONST_PROTEL_REPORT_DEFINITIONID_ID = "reportDefinitionId"
CONST_PROTEL_HOTEL = "Hotel"

CONST_PROTEL_FILENAME = "filename"
CONST_PROTEL_DC_SEPERATOR = "Zimmer"
CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER = "parsed_excel_reports"

CONST_PROTEL_INVOICEJPG_PATTERNTODROP = [
    "Zeitraum:",
    "Systemdatum:",
    "Warengruppe:",
    "Artikel:",
    "Summe (Artikel):",
    "Summe (Gruppe):",
    "Gesamtsumme:",
]
CONST_PROTEL_INVOICEJPG_VALUESTODROP = [
    np.nan,
    "Benutzer:",
    "VAYA Fieberbrunn, 6391 Fieberbrunn",
    "Buchungsd",
    "Rechnung",
    "Res.",
    "Buchungstext",
    "E-Preis",
    "Summe",
    "Zimmer",
    "Gast",
    "Anreise",
    "Abreise",
]
CONST_PROTEL_INVOICEJPG_NEWCOLUMNS = [
    "booking_date",
    "invoice_id",
    "invoice",
    "reservation_id",
    "nights",
    "booking_text",
    "e_price",
    "total",
    "misc",
    "room_id",
    "room_type",
    "guest",
    "arrival",
    "departure",
]

CONST_PROTEL_DC_PATERN_DROP = [
    "NaN",
    "Parameter:",
    "Zeitraum::",
    "Systemdatum:",
    "Reservierung",
]
CONST_PROTEL_DCS_PATERN_DROP = [
    "NaN",
    "Parameter:",
    "Reportdatum:",
    "Umsatz",
    "Status",
    "SystemID:",
    "Total",
    "Systemdatum:",
]
CONST_PROTEL_DCS_NEW_COLUMNS = [
    "booking_channel",
    "nights_rooms_day",
    "guests_day",
    "total_sales_day",
    "sales_rooms_day",
    "logis_day",
    "logis_rooms_day",
    "nights_rooms_month",
    "guests_month",
    "total_sales_month",
    "sales_rooms_month",
    "logis_month",
    "logis_rooms_month",
    "nights_rooms_year",
    "guests_year",
    "total_sales_year",
    "sales_rooms_year",
    "logis_year",
    "logis_rooms_year",
]

CONST_VAYA_MODEL_WEEKLY_CALCULATIONS_COLUMN_NAMES = {
    "date_": "Reservations",
    "property_id": "Property Id",
    "rooms_free": "New rooms",
    "rooms_occ": "Occupied rooms",
    "rooms_occ_percent": "Occupancy rate",
    "arrival_rooms_count": "New guests",
    "leave_rooms_count": "Leaving guests",
    "inhouse_persons": "Guest"
}

CONST_PROTEL_HS_PATERN_DROP = [
    "Auswertungszeitraum:",
    "Gruppierung",
    "Type",
    "Filter",
    "Umsatz",
    "OOO Zimmer",
    "Pseudozimmer",
    "Status",
    "Zimmer",
    "Datum",
    "Total / Seite",
    "Total",
    "Systemdatum:",
]

CONST_PROTEL_HS_NEW_COLUMNS = [
    "date_",
    "rooms_free",
    "rooms_free_percent",
    "rooms_occ",
    "rooms_occ_percent",
    "beds_percentage",
    "arrival_rooms_count",
    "arrival_persons_count",
    "leave_rooms_count",
    "leave_persons_count",
    "inhouse_beds",
    "inhouse_persons",
    "logis",
    "fandb",
    "extras",
    "total",
    "misc_count",
    "misc_percent",
]

CONST_PROTEL_HSBT_PATERN_DROP = [
    "Datum",
    "Total",
    "Druckdatum:",
    "Auswertungszeitraum:",
    "Systemdatum:",
]
CONST_PROTEL_HSBR_PATERN_DROP = [
    "NaN",
    "Systemdatum:",
    "frei",
    "Total / Seite",
    "Total",
    "Ohne",
]

CONST_PROTEL_FILTERED_FILE_SUFFIX = "_filtered.xlsx"
CONST_PROTEL_MERGED_REPORT_FOLDER = "protel_report_files/protel_merged_report"

CONST_VAYA_MODEL_REPORT_FOLDER = "protel_report_files/vaya_model_reports"


CONST_NAME = "name"
CONST_DISPLAYGROUP = "displayGroups"
CONST_PARAMETERS = "parameters"
CONST_INPUTCOMPONENTS = "inputComponents"
CONST_OPTIONS = "options"
CONST_OPTION = "option"
CONST_FLTTYPE = "fltType"
CONST_FLTROOM = "fltRoom"
CONST_FLTSTATEIDS = "fltStateIDs"
CONST_FLITCATEGORY = "fltCategory"
CONST_FLTITEMGROUPIDS = "fltItemGroupIDs"
CONST_FLTITEMIDS = "fltItemIDs"
CONST_TASKID = "taskID"
CONST_BOKERID = "bookerID"
CONST_RESERVATIONID = "reservationID"
CONST_BOOKERNAME = "bookerName"
CONST_ARRIVALDATE = "arrivalDate"
CONST_DEPARTUREDATE = "departureDate"
CONST_GUESTCOUNT = "guestCount"
CONST_RESSTATENAME = "resStateName"
CONST_COUNTRY = "country"
CONST_CHANNEL = "channel"
CONST_RESERVATIONDATE = "reservationCreationDate"
CONST_RATENAME = "rateName"
CONST_HEARREASON = "hearReason"
CONST_COMEREASON = "comeReason"
CONST_MARKETCODE = "marketCode"
CONST_CATEGORYID = "categoryID"
CONST_GUESTID = "guestID"
CONST_GUESTNAMES = "guestNames"
CONST_AGEGROUPADULT = "ageGroup_Adult"

# constant Fields
CONST_BOOKER = "booker"
CONST_ROOM_ID = "room_id"
CONST_ARRIVAL = "arrival"
CONST_DEPARTURE = "departure"
CONST_ROOM_NIGHTS = "room_nights"
CONST_LOGIS = "logis"
CONST_EXTRAS = "extras"
CONST_FANDB = "fandb"
CONST_DC_TOTAL_PRICE = "total_price"
CONST_DATE_ = "date_"
CONST_NIGHT_ROOMS_DAY = "nights_rooms_day"
CONST_GUESTS_DAY = "guests_day"
CONST_TOTAL_SALES_DAY = "total_sales_day"
CONST_SALES_ROOMS_DAY = "sales_rooms_day"
CONST_LOGIS_DAY = "logis_day"
CONST_LOGIS_ROOMS_DAY = "logis_rooms_day"
CONST_NIGHTS_ROOMS_MONTH = "nights_rooms_month"
CONST_GUESTS_MONTH = "guests_month"
CONST_TOTAL_SALES_MONTH = "total_sales_month"
CONST_SALES_ROOMS_MONTH = "sales_rooms_month"
CONST_LOGIS_MONTH = "logis_month"
CONST_LOGIS_ROOMS_MONTH = "logis_rooms_month"
CONST_NIGHTS_ROOMS_YEAR = "nights_rooms_year"
CONST_GUESTS_YEAR = "guests_year"
CONST_TOTAL_SALES_YEAR = "total_sales_year"
CONST_SALES_ROOMS_YEAR = "sales_rooms_year"
CONST_LOGIS_YEAR = "logis_year"
CONST_LOGIS_ROOMS_YEAR = "logis_rooms_year"
CONST_ROOMS_FREE = "rooms_free"
CONST_ROOMS_FREE_PERCENTAGE = "rooms_free_percent"
CONST_ROOMS_OCC = "rooms_occ"
CONST_ROOMS_OCC_PERCENTAGE = "rooms_occ_percent"
CONST_BEDS_PERCENTAGE = "beds_percentage"
CONST_ARRIVAL_ROOMS_COUNT = "arrival_rooms_count"
CONST_ARRIVAL_PERSONS_COUNT = "arrival_persons_count"
CONST_LEAVE_ROOMS_COUNT = "leave_rooms_count"
CONST_LEAVE_PERSONS_COUNT = "leave_persons_count"
CONST_INHOUSE_BEDS = "inhouse_beds"
CONST_INHOUSE_PERSONS = "inhouse_persons"
CONST_TOTAL = "total"
CONST_MISC_COUNT = "misc_count"
CONST_MISC_PERCENTAGE = "misc_percent"
CONST_HOUSEKEEPER = "Housekeeper"
CONST_RECEPTIONIST = "Receptionist"
CONST_KITCHEN_STAFF = "Kitchen Staff"
CONST_WAITER = "Waiter"
CONST_ROW_INDEX_A = "A"
CONST_ROW_INDEX_B = "B"
CONST_ROW_INDEX_RANGE_2 = 2
CONST_ROW_INDEX_RANGE_3 = 3
CONST_ROW_INDEX_RANGE_4 = 4
CONST_ROW_INDEX_RANGE_5 = 5
CONST_ROW_INDEX_RANGE_6 = 6
CONST_ROW_INDEX_RANGE_7 = 7
CONST_PROPERTY_ID = "property_id"
CONST_COUNT = "COUNT(*)"
CONST_DC_DATA_INSERTION = "DC data insertion successfully."

CONST_READ_EXCEL_ENGINE = "openpyxl"
CONST_PROTEL_DATE_FORMAT = "%Y-%m-%dT%H:%M:%S"
CONST_PROTEL_EXCEL_DATE_FORMAT = "%Y-%m-%d_%H-%M-%S"
CONST_PROTEL_MAIL_DATE_FORMAT = "%dth %b, %Y"
EXCEL_RECORD_DATE_FORMAT = "%Y-%m-%d"

CONST_ERROR_WHILE_CONNECTING_TO_MARIADB = "Error while connecting to MariaDB :"
CONST_SHEET1 = "Sheet1"
CONST_CURSOR = "cursor"
CONST_CONNECTION = "connection"
CONST_PMS_START_DATE = 1
CONST_PMS_END_DATE = 6
DEFAULT_VALUE = 0
CONST_PMS_START_RANGE = 1
CONST_HOTEL_ID = "Hotel_ID"
CONST_HOTEL = "Hotel"
CONST_DATE = "Date"
CONST_ROOM_TYPE = "Room_Type"
CONST_BOOKING = "Bookings"
CONST_PMS_LOGIS = "Logis"
CONST_F_AND_D = "F&B"
CONST_TOTAL_PRICE = "Total_Price"
CONST_AUTHENTICATION_EXPIRE_TIME = 14
CONST_WB = "wb"
CONST_RESERVATION_STATE_IDS_NOT_FOUND = "Reservations states ids not found"
CONST_METHOD_POST = "POST"
CONST_ONLY_WITH_CONFIDENTIAL_RATE = "onlyWithConfidentialRate"
CONST_DAY_USE = "dayUse"
CONST_RESERVATION_STATE = "reservationStates"
CONST_LIST_TYPE = "listType"
CONST_RESERVATION_BY_CREATTION = "RESERVATION_BY_CREATION"
CONST_VALID_FROM = "validFrom"
CONST_VALID_TO = "validTo"
CONST_LIST_BASE = "listBase"
CONST_PAGING = "paging"
CONST_ELEMENT = "ELEMENT"
CONST_SIZE = "size"
CONST_PAGE = "page"
CONST_SIZE_NUMBER = 5000
CONST_FILTER = "filter"
CONST_ID = "id"
CONST_DATA = "data"
CONST_STATUS_CODE = 200
CONST_REPORT_DEFINATION_API_FAILED = "Report definition API failed "
CONST_DATA_PARSED_SAVED_SUCESS = "Data parsed and saved successfully!!"

#Meal Plan API
CONST_MEAL_PLAN_API_FAILED = "Meal plan API failed"

CONST_FILTER_RESERVATION_STATUS = ['Checked In', 'Definitiv', 'Checked Out']
CONST_FILTER_HOUSE_RESERVATION_STATUS = "Definitiv"
CONST_FILTER_OBJ =  "filterObjects" 

# fields
CONST_RESERVATION_ID = "reservation_id"
CONST_BOOKING_CHANNEL = "booking_channel"

german_to_english_mapping = {
    "Datum": "date",
    "Zimmer": "room",
    "Res.-Status": "reservation_status",
    "Res.-Nr.": CONST_RESERVATION_ID,
    "Personen": "persons",
    "Bucher": CONST_BOOKER,
    "Preiscode": "rate_code",
    "Bemerk.": "notes",
    "Frühstück": "breakfast",
    "Fruehstueck": "breakfast",
    "Halbpension":"halfboard",
}

CONST_PROTEL_CONTINUE_BUTTON_XPATH = (
    "//button[@type='submit']"
)
CONST_PROTEL_LOGIN_BUTTON_XPATH = (
    "//button[@type='submit']"
)

# PMS Email constants
CONST_SENDER_MAIL = "rotlistngi@gmail.com"
CONST_SENDER_MAIL_PASSWORD = "wuzh qeyw cjnf fabj"
CONST_RECIPIENT_MAIL = "victor.roos@rotrip.nl"
CONST_RECIPIENT_CC_MAIL = "victor.roos@rotrip.nl"
CONST_PMS_EMAIL_SUBJECT = "Protel PMS Daily Booking {date}"
CONST_PMS_WEEKLY_EMAIL_SUBJECT = "Protel PMS Weekly Booking {from_date} to {to_date}"
CONST_PMS_BOOKINGS = "Protel_PMS_Bookings"
CONST_PMS_WEEKLY_BOOKINGS = "Protel_PMS_Weekly_Bookings"
CONST_PMS_FILTER_BOOKINGS_BY_ROOM_TYPE = "Protel_PMS_Bookings_With_Room_Type"
CONST_PROTEL_FORMAT_DATE = "%Y-%m-%d"
CONST_PLAIN = "plain"
CONST_FILE_READ_AND_BINARY_MODE = "rb"
CONST_APPLICATION = "application"
CONST_OCTET_STREAM = "octet-stream"
CONST_DISPLAY_CONTENT = "Content-Disposition"
CONST_ATTACHMENT = "attachment"
CONST_MAIL_SUCCESFULLY_SENT_MESSAGE = (
    "Report sent to mail successfully"
)
CONST_MAIL_NOT_SENT_MESSAGE = "Report not sent"
CONST_MAIL_PORT_NUMBER = 587
CONST_SMTP_MAIL_ID = "smtp.gmail.com"

# logger messages
CONST_PROTEL_DOWNLOAD_SAVE_LOG = "File {filename} downloaded and saved"


CONST_SMTP_SERVER = "smtp.gmail.com"
CONST_MIMENASE_HEADER_CONTENT = "Content-Disposition"

GOOGLE_API_SCOPES = [
        'https://www.googleapis.com/auth/spreadsheets',
        'https://www.googleapis.com/auth/drive'
        ]

GOOGLE_API_CREDS = 'credentials.json'

EMAIL_LIST = ['victor.roos@rotrip.nl','alexander.geeris@rotrip.nl','martijnvandeleest@gmaill.com','rotlistngi@gmail.com']

CONST_PMS_EMAIL_BODY = """
Hi Team,

Daily booking report from {report_date}, is now available for your review. You can access the report by opening the attached file to this email.


Thanks,
Vaya Bot
"""

CONST_PMS_WEEKLY_EMAIL_BODY = """
Hi Team,

Weekly booking report from {from_date} to {to_date}, is now available for your review. You can access the report by opening the attached file to this email.


Thanks,
Vaya Bot
"""

CONST_PMS_NO_DATA_FOUND_WEEKLY_EMAIL_BODY = """
Hi Victor,

No data found for weekly booking report from {from_date} to {to_date}, is now available for your review. You can access the report by opening the attached file to this email.


Thanks,
Vaya Bot
"""

# Vaya Model Comment's
CONST_VAYA_WEEKLY_CALCULATIONS_EMAIL_SUBJECT = "Vaya Model Weekely Calculations Report {from_date} to {to_date}"

KOPIE_VAYA_FILE_NAME = "Kopie_van_Model_Vaya.xlsx"
CONST_VAYA_WEEKLY_CALCULATIONS_EMAIL_BODY = """
Hi Victor,

Vaya model weekly calculations report for {from_date} to {to_date}, is now available for your review. You can access the report by opening the attached file to this email.


Thanks,
Vaya Bot
"""

CONST_LOGIN_EXTRACTION_FAILURE_EMAIL_BODY = """
Hi Team,

We encountered an issue while trying to perform the login or reports data extraction process on Protel PMS at {failure_time}. 

Error Details:
- Failure Reason: {failure_reason}
- Error Description: {error_description}
- Suggested Action: {suggested_action}

Please review and let us know if there have been any changes in the interface or other configurations that might have caused this issue.

We are currently investigating the root cause and will keep you updated.

Thanks,
Vaya Bot
"""
CHARACTERISTICS = "characteristics"
EFFICIENCY_OF_LABOR = "effiency_of_labor_(management)"
TOTAL = "Total"
TOTAAL = "Totaal"
SPLIT = "split"

DTYPE_FLOAT =  "float64"
COMPLEX = "complex"
NO = "no"
YES = "yes"
CHEF_ASSISTANT = "chef-assistant"
DEMAND_FOR_LABOR = "demand_for_labor_(protel)"
PEAK_DEMAND_LABOR = "peak_demand_times_for_labor_(management)"
MEAL_TIMES = "meal_times"
BAR = "bar"
LAUNDARY_TIME = "12.008333333333333"
LAUNDARY_STORAGE = "12.091666666666667"
COOKING_COMPLEX_TOTAL_STR = "12.166666666666666"
BREAKFAST_TARGET_TIME_STR = "12.5"
BREAKFAST_TARGET_BUFFER_STR = "12.333333333333334"
TARGET_KITCHED_CLEANING_TIME_STR = "12.333333333333334"
PEAK_DEMAND_RECEPTIONIST_WITH_IN_PERCENTAGE = 0.9

SPA_AND_WELLNESS = "spa_and_wellness"
HEAD_OF_RECEPTION = "Head of Reception"
REGULAR = "Regular"
RECEPTIONIST_LIST  = ["Receptionists check-in", "Receptionists check-out", "Receptionists regular"]
RECEPTIONISTS = "Receptionists"
HEAD_OF_CLEANING = "Head of Cleaning"
HEAD_OF_RESTAURANT = "Head of Restaurant"
COMMON_AREA_CLEANERS = "Common area cleaners"
ROOM_CLEANERS = "Room cleaners"
ROOM_CLEANER_CHECKS= "Room cleaner between checks"
ROOM_CLEANER_REGULAR = "Room cleaner regular"
LAUNDRY_ATTENDANTS = "Laundry attendants"
LAUNDRY_CHECKS = "Laundry between checks"
CHEF = "Chef" 
CHEF_DINNER ="Chef during diner"
KITCHEN_ASSISTANTS = "Kitchen assistants"
KITCHEN_ASSISTANTS_LIST=["Kitchen assistants during breakfast", "Kitchen assistants during diner"]
WAITERS = "Waiters"
WAITER_LIST = ["Waiters during breakfast","Waiters during diner"]
BARTENTERS = "Bartenders"
BARTENDERS_BARTIME = "Bartenders during bartime"
SPA_THERAPIST = "Spa therapist"
SPA_THERAPIST_MASSAGE_TIME ="Spa therapists during massage time"
MANAGEMENT_TYPE = "management_type"
NO_MANAGERS = "no managers"
RECEPTIONIST_CHECKIN = "reception_check-in"
RECEPTIONIST_CHECKOUT = "reception_check-out"
RECEPTIONIST_CHECKIN_MOBILE = "reception_check-in_(mobile)"
RECEPTIONIST_CHECKOUT_MOBILE = "reception_check-out_(mobile)"
MOBILE_CHECKIN_OUT_ENTRY = "mobile_check-in/out_entry/exit"
HOUSKEEPING_STAYING_GUEST = "housekeeping_(staying_guests)"
HOUSKEEPING_NEW_GUEST = "housekeeping_(new_guests)"
CLEAN_ROOM_ONCE_EVERY_DAY = "clean_room_once_every_x_days"
CLEAN_COMMON_EVERY_DAY = "clean_common_every_x_days"
ROOMS_HOTEL = "rooms_hotel"
TARGET_AVG_WORKHOURS = "target_average_workhours"
M2_GENERAL_SAPCE = "m2_general_space"
HOUSEKEEPING_COMMON_AREAS = "housekeeping_(common_areas)"
TARGET_LAUNDRY_TRANSFER_TIME_ROOM = "target_laundry_transfer_time_per_room"
LAUNDRY_STORAGE = "laundry_storage"
CHEF_TYPE = "chef_type"
MENUE_TYPE = "menu_type"
MOBILE_ORDER_PAY = "mobile_ordering_/paying"
GUEST_TAKE_PREMADE = "%_guests_take_premade"
PREMADE_MEALS_OPRION = "premade_meals_option"
COOKING_COMPLEX = "cooking_(complex)"
TARGET_PREPARATION_TIME = "target_preperation_time"
TARGET_BUFFET_SEFUP = "target_buffet_set-up_and_restocking"
TARGET_KITCHEN_CLEAN_TIME = "target_kitchen_cleaning_time"
COOKING_SIMPLE = "cooking_(simple)"
CULINAIRY_COOKING_COMPLEX = "culinairy_operations_ex_cooking_(complex)"
CULINAIRY_COOKING_SIMPLE = "culinairy_operations_ex_cooking_(simple)"
TABLE_SETTING = "table_setting"
WAITERING_NORMAL = "waitering_(normal)"
WAITERING_MOBILE = "waitering_(mobile)"
DINING_SHIFTS = "Dining Shifts"
DINING_1ST_SHIFT_START = "dining_1stshift_start"
DINING_1ST_SHIFT_END =  "dining_1stshift_end"
DINING_2ND_SHIFT_START = "dining_2ndshift_start"
DINING_2ND_SHIFT_END = "dining_2ndshift_end"
CHECKIN_OUT_TIMES = "Check-in and out times"
CHECKIN_PEAK_START = "check-in peak start"
CHECKIN_PEAK_END = "check-in peak end"
CHECKOUT_PEAK_START="check-out peak start"
CHECKOUT_PEAK_END="check-out peak end"
GUEST_WITHIN_PEAK_HRS = "guests within peak hours"
RESERVATIONS = "Reservations"
NEW_GUESTS = "New guests"
LEAVE_GUESTS = "Leaving guests"
NEW_ROOMS = "New rooms"
CHECKIN_TIME_EARLIEST = "check-in time (earliest)"
CHECKOUT_TIME_LATEST = "check-out time (latest)"
ROOM_CLEAN_TIME_START = "Room cleaning time start"
MEAL_TIMES = "Meal times"
OCCUPANCY_RATE = "Occupancy rate"
BOARDTYPE2 = "Boardtype2"
BOARDTYPE1 = "Boardtype1"
BOARDTYPE3 = "Boardtype3"
MASSAGE_RESERVATIONS = "Massage reservations"
DINING_END = "dining end"
START_PREPARE_DINNER = "start preperation diner"
DINING_START = "dining start"
BREAKFAST_START = "breakfast start"
BREAKFAST_PREPARE = "breakfast preperation"
BREAKFAST_END = "breakfast end"
DINING_SPLIT_SHIFTS = "dining split shifts"
BAR_OPEN = "Bar open"
BAR_CLOSE = "Bar closed"
SPA_WELLNESS =  "Spa and Wellness"
MSASSAGE_DURATION = "Massage duration"
WELLNESS_OPEN = "Wellness open"
WELLNESS_CLOSE = "Wellness closed"
TIME_BETWEEN_SPLIT = "time between splits"

SHEET_NAME = "Sheet1"
HR_MIN = "%H:%M"
NO_CHEF = "no chef"
EXCEL_WRITER_ENGINE = "xlsxwriter"
WEEK = "Week"
KPI_WEEK_AVERGAE = "KPI's (weekly averages}"
BB_GUEST = "BB guests"
HB_GUEST = "HB guests"
FB_GUEST = "FB guests"
DEPARTMENT = "Department"
RECEPTION = "Reception"
CLEANING = "Cleaning"
KITCHEN = "Kitchen"
WAITERING = "Waitering"
OTHER  = "Other"
DATE = "Date"
RECEPTION_JOB = "reception_job" 
RECEPTION_AMOUNT = "reception_amount"
ROOM_CLEANER_JOB ="room_celaner_job"
ROOM_CLEANER_AMOUNT = "room_celaner_amount"
CHEF_JOB = "chef_job"
CHEF_AMOUNT = "chef_amount"
KITCHEN_JOB =  "kitchen_job"
KITCHEN_AMOUNT = "kitchen_amount"
WAITERS_JOB = "waiters_job"
WAITERS_AMOUNT = "waiters_amount"
BARTENDERS_JOB = "bartenders_job"
BARTENDERS_AMOUNT = "bartenders_amount"
SPA_JOB = "spa_job"
SPA_AMOUNT = "spa_amount"