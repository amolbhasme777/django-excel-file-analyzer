HOSTNAME = "localhost"
USERNAME = "root"
PASSWORD = "ngi@123"
PORT = 3306
DATABASE = "vaya_protel_dev"

PROTEL_USERNAME = "terry.peck@vayaresorts.com"
PROTEL_PASSWORD = "Tiger40$"

# PROTEL_USERNAME = "mitchell.howard@vayaresorts.com"
# PROTEL_PASSWORD = "Green35%"