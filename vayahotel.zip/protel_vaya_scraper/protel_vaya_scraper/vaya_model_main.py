import json
import common_constant as const
import logging
import pandas as pd
import queries
import shutil
import zipfile
from vaya_hotel_model.emoployee_model import *
from protel_database_connection import DatabaseConnection
from send_mail import send_mail

logging.basicConfig(level=logging.DEBUG)


class VayaModelDataProcessor:
    def __init__(self):
        try:
            self.db_conn = DatabaseConnection()
        except Exception as connection_error:
            logging.error(
                f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {connection_error}"
            )
    
    @staticmethod
    def fetch_count_obj(cursor, query, property_id):
        cursor.execute(query, (property_id,))
        result = cursor.fetchone()
        return result[const.DEFAULT_VALUE] if result else None
    
    def fetch_data_frame_from_cursor(self, cursor, query):
        """
        The function fetches data from a cursor and returns it as a pandas DataFrame.

        :param cursor: The cursor is an object that allows you to interact with the database. It is used
        to execute SQL queries and fetch data from the database
        :param query: The query parameter is a string that represents the SQL query you want to execute.
        It can be any valid SQL query that retrieves data from a database table
        :return: a pandas DataFrame.
        """

        cursor.execute(query)
        columns = [column[0] for column in cursor.description]
        data = cursor.fetchall()
        return pd.DataFrame(data, columns=columns)
    
    def create_zip_of_xlsx_files(self, directory_path, output_zip_filename, file_to_exclude):
        # List all files in the directory except the file to exclude
        file_list = [file for file in os.listdir(directory_path) if file.endswith(".xlsx") and file != file_to_exclude]
        valid_files = []
        for file in file_list:
            file_path = os.path.join(directory_path, file)
            try:
                # Attempt to read the Excel file into a DataFrame
                df = pd.read_excel(file_path, engine=const.CONST_READ_EXCEL_ENGINE)
                
                # Check if the DataFrame is empty
                if not df.empty:
                    valid_files.append(file)
                else:
                    logging.warning(f"File '{file}' is empty. Skipping from zip file.")
            except Exception as e:
                logging.error(f"Error reading file '{file}': {e}")

        # Check if there are valid files to include in the zip
        if not valid_files:
            logging.warning("No valid files found to include in the zip. Skipping zip file creation.")
            return
        # Create a zip file
        with zipfile.ZipFile(output_zip_filename, 'w') as zipf:
            # Write each .xlsx file to the zip file
            for file in valid_files:
                file_path = os.path.join(directory_path, file)
                zipf.write(file_path, arcname=file)

    def fetch_vaya_model_from_excel(self):
        with open(os.path.join(os.getcwd(),"config.json"), "r") as config_file:
            config = json.load(config_file)
        logger = logging.getLogger(__name__)
        logger.setLevel(logging.INFO)

        # Create a file handler
        handler = logging.FileHandler(const.CONST_VAYA_MODEL_LOG)
        handler.setLevel(logging.INFO)

        # Create a log format
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        handler.setFormatter(formatter)

        # Navigate to the protel_report_files/vaya_model directory
        records_directory_path = os.path.join(os.getcwd(),  const.CONST_VAYA_MODEL_REPORT_FOLDER)

        try:
            # Check if the directory exists
            if os.path.exists(records_directory_path):
                # Use shutil.rmtree to remove the directory and its contents recursively
                shutil.rmtree(records_directory_path)
                logger.info(f"Directory '{records_directory_path}' and its contents have been deleted.")
            else:
                logger.info(f"Directory '{records_directory_path}' does not exist.")
        except Exception as e:
            logger.error(f"An error occurred: {e}")

        # Add the handler to the logger
        logger.addHandler(handler)
        try:
            # Navigate to the protel_report_files/vaya_model directory
            target_dir = os.path.join(os.getcwd(), "protel_report_files")

            # Save the Excel file
            kopie_file_path = os.path.join(target_dir, "Kopie_van_Model_Vaya.xlsx")

            hotel_df = pd.read_excel(kopie_file_path, engine=const.CONST_READ_EXCEL_ENGINE)
            dataframes=extract_tables(hotel_df, logger)
            
            # Create the new directory if it doesn't exist
            os.makedirs(records_directory_path, exist_ok=True)

            # Save the Excel file
            weekly_vaya_model_report = os.path.join(records_directory_path, "weekly_vaya_model_report.xlsx")
            
            cursor = self.db_conn.connection.cursor()
            data_frame_objects = self.fetch_data_frame_from_cursor(
                cursor, queries.GET_WEEKLY_CALCULATION_COUNTS
            )
            
            # Assuming 'property_id' is the column containing distinct IDs for properties
            unique_property_ids = data_frame_objects['property_id'].unique()

            excel_writer = pd.ExcelWriter(weekly_vaya_model_report, engine="xlsxwriter")

            # Loop through each unique property ID
            for property_id in unique_property_ids:
                # Filter data based on the current property_id
                filtered_data = data_frame_objects[data_frame_objects['property_id'] == property_id]
        
                if len(filtered_data) > 0:
                    cursor.execute(queries.GET_WEEKLY_COUNT_DINNER_MEAL_PLAN, (property_id,))
                    dinner_count_objects = cursor.fetchall()
                    
                    object_df = pd.DataFrame(dinner_count_objects, columns=['date_', 'Dinner'])
                    merged_df = pd.merge(filtered_data, object_df, left_on='date_', right_on='date_', how='outer')
                    
                    filtered_data = merged_df.drop_duplicates(subset=['date_'])
                    filtered_data = filtered_data.sort_values(by='date_')
        
                    cursor.execute(queries.GET_WEEKLY_COUNT_BREAKFAST_MEAL_PLAN, (property_id,))
                    breakfast_count_objects = cursor.fetchall()
                    
                    object_df = pd.DataFrame(breakfast_count_objects, columns=['date_', 'Breakfast'])
                    merged_df = pd.merge(filtered_data, object_df, left_on='date_', right_on='date_', how='outer')
                    
                    filtered_data = merged_df.drop_duplicates(subset=['date_'])
                    filtered_data = filtered_data.sort_values(by='date_')
                    filtered_data = filtered_data.fillna(0)
                    
                    room_count_objects = self.fetch_count_obj(
                        cursor, queries.GET_WEEKLY_COUNT_FOR_ROOM, property_id
                    )
                    
                    property_name = self.fetch_count_obj(
                        cursor, queries.GET_PROPERTY_NAME, property_id
                    )
                    

                    # Convert 'rooms_occ_percent' column to numeric and round the values
                    rooms_occ_percent = pd.to_numeric(filtered_data['rooms_occ_percent'], errors='coerce').round(decimals=2)
                    filtered_data['rooms_occ_percent']  = rooms_occ_percent / 100

                    # Rename columns
                    filtered_data.rename(columns=const.CONST_VAYA_MODEL_WEEKLY_CALCULATIONS_COLUMN_NAMES, inplace=True)
                    
                    # Convert 'Guest' column to floating-point numbers and then to integers
                    filtered_data['Guest'] = filtered_data['Guest'].astype(int)
                    
                    filtered_data.drop(columns=['Property Id'], inplace=True)
                    filtered_data = filtered_data.set_index('Reservations').transpose()
                    
                    # Reset the index name
                    filtered_data = filtered_data.rename_axis(None, axis=1)

                    # Reset the index to get 'Reservations' as a column again
                    filtered_data = filtered_data.reset_index()

                    # Rename the columns to match the 'Reservations' values
                    filtered_data.rename(columns={'index': 'Reservations'}, inplace=True)

                    filtered_data = filtered_data.set_index(filtered_data.columns[0], drop=True)
                    # Write the filtered data to a new sheet in the Excel file
                    filtered_data.to_excel(excel_writer, sheet_name=f'Sheet - {property_id}', index=True)
                    
                    labor_demand_df = filtered_data
                    labor_demand_df.fillna(0, inplace=True)
                    characteristics = hotel_characteristics_table(dataframes, logger)
                    labor_management_dfs = efficiency_labor_management(dataframes, logger)
                    peak_demand_df_list = peak_demand(dataframes, labor_demand_df, characteristics, room_count_objects, labor_management_dfs,logger, property_id, property_name, config)
                    intraday_agenda_df_list = intraday_agenda_rounded(dataframes, peak_demand_df_list,logger, property_name, config)
                    employee_model_final_output(labor_demand_df, intraday_agenda_df_list,logger, property_id, property_name, config)
            
            # Save and close the Excel writer
            excel_writer.close()

            # Output zip file name
            output_zip_filename = os.path.join(records_directory_path, config["weekly_vaya_calculations_results"])

            # File to exclude from the zip
            file_to_exclude = const.KOPIE_VAYA_FILE_NAME

            # Create a zip file containing all .xlsx files in the directory (excluding 'file_to_exclude')
            self.create_zip_of_xlsx_files(records_directory_path, output_zip_filename, file_to_exclude)
            
            file_paths = [output_zip_filename]
            
            tommorow_date = datetime.now() + timedelta(days=const.CONST_PMS_START_DATE)
            date_six_days_ago = tommorow_date + timedelta(days=const.CONST_PMS_END_DATE)
            tommorow_date_formatted = tommorow_date.strftime(
                const.CONST_PROTEL_MAIL_DATE_FORMAT
            )
            date_six_days_ago_formatted = date_six_days_ago.strftime(
                const.CONST_PROTEL_MAIL_DATE_FORMAT
            )
            
            # Assuming you have different subjects and bodies
            pms_mail_weekly_calculation_subject = const.CONST_VAYA_WEEKLY_CALCULATIONS_EMAIL_SUBJECT.format(
                to_date=date_six_days_ago_formatted, from_date=tommorow_date_formatted
            )
            pms_mail_weekly_calculation_body = const.CONST_VAYA_WEEKLY_CALCULATIONS_EMAIL_BODY.format(
                to_date=date_six_days_ago_formatted, from_date=tommorow_date_formatted
            )
            
            # Sending files via email
            if all(os.path.exists(path) for path in file_paths):
                send_mail(file_paths, pms_mail_weekly_calculation_subject, pms_mail_weekly_calculation_body)

        except Exception as exp:
            logger.error(f"Unable to read excel file {str(exp)}")
            
if __name__ == "__main__":
    try:
        data_processor = VayaModelDataProcessor()
        data_processor.fetch_vaya_model_from_excel()
    except Exception as error:
        logging.error(
            f"{error}"
        )
    