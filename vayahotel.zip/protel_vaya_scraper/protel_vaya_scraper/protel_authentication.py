import time
from datetime import timedelta, datetime
from . import common_constant as const
from . import protel_config as config
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from protel_vaya_scraper.send_mail import send_failure_email

def protel_authentication(logger):
    """
    Protel website authentication process using login credentials which returns access token.
    If authentication fails, an email notification will be sent with failure details.
    """
    try:
        # Initialize the WebDriver (e.g., Chrome)
        chrome_options = Options()
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--headless")  # Run in headless mode

        driver = webdriver.Chrome(
            service=Service(ChromeDriverManager().install()), options=chrome_options
        )
        # Navigate to the login page
        driver.get(const.CONST_PROTEL_LOGIN_URL)

        # Attempt to find and fill in the username field and click "Continue"
        try:
            username_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, const.CONST_USERNAME_FIELD))
            )
            username_field.send_keys(config.PROTEL_USERNAME)
            driver.find_element(By.XPATH, const.CONST_PROTEL_CONTINUE_BUTTON_XPATH).click()
        except Exception as exp:
            logger.error("Failed to locate username field or continue button.")
            # send_failure_email(
            #     failure_reason="Unable to locate the username field or continue button",
            #     error_description=str(exp),
            #     suggested_action="Please verify if the login page interface has changed or if the element's XPath has been modified."
            # )
            return None

        # Attempt to find and fill in the password field and click "Login"
        try:
            password_field = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.ID, const.CONST_PASSWORD_FIELD))
            )
            password_field.send_keys(config.PROTEL_PASSWORD)
            driver.find_element(By.XPATH, const.CONST_PROTEL_LOGIN_BUTTON_XPATH).click()
        except Exception as exp:
            logger.error("Failed to locate password field or login button.")
            # send_failure_email(
            #     failure_reason="Unable to locate the password field or login button",
            #     error_description=str(exp),
            #     suggested_action="Please verify if the login page interface has changed or if the element's XPath has been modified."
            # )
            return None

        # Ensure OAuth page is loaded completely
        try:
            WebDriverWait(driver, 200).until(
                lambda driver: driver.execute_script('return document.readyState') == 'complete'
            )
        except Exception as exp:
            logger.error("Failed to load the OAuth page completely.")
            # send_failure_email(
            #     failure_reason="Unable to load OAuth page",
            #     error_description=str(exp),
            #     suggested_action="Please check if the login flow has changed or if there are network issues preventing the page load."
            # )
            # return None
        
        time.sleep(2)  # Adding a small delay to ensure that local storage is updated

        # Log current URL and check local storage at this point
        current_url = driver.execute_script("return window.location.href;")
        logger.info(f"Current URL after OAuth: {current_url}")

        # Retrieve access_token from local storage
        try:
            data = driver.execute_script(
                "var ls = window.localStorage, items = {}; "
                "for (var i = 0, k; i < ls.length; ++i) "
                "  items[k = ls.key(i)] = ls.getItem(k); "
                "return items; "
            )

            logger.info(f"Local storage contents: {data}") 

            if "access_token" in data:
                const.AUTH_TOKEN = data["access_token"]
                logger.info("Protel login successful")
                return const.AUTH_TOKEN
            else:
                logger.error("Protel authentication failed: Access token not found.")
                # send_failure_email(
                #     failure_reason="Access token not found in local storage",
                #     error_description="The access token was not found in the local storage after login.",
                #     suggested_action="Please verify if the login process has changed or if the OAuth flow is functioning correctly."
                # )
                return None

        except Exception as exp:
            logger.error("Failed to retrieve access token from local storage.")
            # send_failure_email(
            #     failure_reason="Unable to retrieve access token from local storage",
            #     error_description=str(exp),
            #     suggested_action="Please verify if the local storage is being updated correctly or if there are issues with the page load."
            # )
            return None

    except Exception as exp:
        logger.error(f"Protel authentication process failed: {str(exp)}")
        # send_failure_email(
        #     failure_reason="General failure in authentication process",
        #     error_description=str(exp),
        #     suggested_action="Please check the overall system configuration and interface for any changes."
        # )
        return None