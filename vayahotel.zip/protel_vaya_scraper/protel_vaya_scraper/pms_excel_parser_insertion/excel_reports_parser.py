## Created on: September25th, 2023
## Description: parse and save excel reports
## Author: Amol.Bhasme

import json
import os
import requests
import time
from .. import queries
from protel_vaya_scraper.protel_database_connection import DatabaseConnection
from datetime import datetime, timedelta
from dateutil.parser import parse
from protel_vaya_scraper.protel_authentication import protel_authentication

import pandas as pd
import os
import logging
from xlsx2csv import Xlsx2csv
from .. import common_constant as const
from protel_vaya_scraper.send_mail import send_failure_email


from protel_vaya_scraper.pms_excel_parser_insertion.Insert_DB_Scripts.insert_into_db import (
    insert_journal_data,
    insert_distribution_channel_data,
    insert_distribution_channel_status_data,
    insert_hotel_status_data,
    insert_hotel_status_by_booking_type,
    insert_hotel_status_rooms_data,
)

# Specify the name of the folder you want to create
folder_name = const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER
parsed_excel_reports_folder_path = os.path.join(os.getcwd(), folder_name)

if not os.path.exists(parsed_excel_reports_folder_path):
    os.makedirs(parsed_excel_reports_folder_path)
else:
    logging.info(f"Folder '{folder_name}' already exists at {os.getcwd()}")

def parse_save_invoice_report(excel_file_path, filename, property_id, db_conn, logger, error_logger):
    """
        Parse saved invoice journal by product group xlsx report and insert into database
    """
    # Directory containing your Excel files
    excel_directory = excel_file_path
    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_INVOICE_JPG_SUFFIX
    if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_XLSX_EXTENSION):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename) 
         
        try:
            Xlsx2csv(file_path, outputencoding="utf-8").convert(file_path[:-5] + const.CONST_CSV_EXTENSION)
        except Exception as exp:
            logger.error(f"Invalid xlsx file: {exp}")
            # send_failure_email(
            #     failure_reason="Invalid XLSX file invoice report",
            #     error_description=f"Error during conversion of XLSX to CSV {filename}: {exp}",
            #     suggested_action="Please check the file format or the file's content and try again."
            # )

        filename = os.path.splitext(filename)[0] + const.CONST_CSV_EXTENSION

        if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_CSV_EXTENSION):
            # Extract the date and time from the file name
            date_time = filename.replace(prefix_to_search, "").replace(const.CONST_CSV_EXTENSION, "")
            try:
                file_path = os.path.splitext(file_path)[0] + const.CONST_CSV_EXTENSION
                # Read the Excel file into a pandas DataFrame and skip the header row
                df = pd.read_csv(file_path, header=None, engine="python")

                result_df = pd.DataFrame()
                
                # Define the column indices you want to extract
                column_indices_to_extract = [1, 3, 4, 12, 13, 14, 18, 21, 22, 26, 27, 29, 31, 35, 37]

                # Iterate through the column indices you want to extract
                for col_index in column_indices_to_extract:
                    if col_index < df.shape[1]:
                        # If the column index is valid, copy it to the result DataFrame
                        result_df[df.columns[col_index]] = df.iloc[:, col_index]
                    else:
                        # If the column index is out of bounds, fill the result DataFrame with NaN
                        result_df[str(col_index)] = None
                        
                result_df = result_df.dropna(how="all")

                # Drop rows that don"t have a booking_date
                result_df = result_df.dropna(subset=[1], how="all")
                        
                # Function to check if a row contains any of the specified patterns
                def contains_pattern(row):
                    return any(pattern in str(row) for pattern in const.CONST_PROTEL_INVOICEJPG_PATTERNTODROP)

                # Filter rows to keep
                filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]

                # Use the DataFrame.drop method to drop rows with the specified values
                filtered_df = filtered_df[~filtered_df.isin(const.CONST_PROTEL_INVOICEJPG_VALUESTODROP).all(axis=1)]

                # Reset the index of the DataFrame after dropping rows
                filtered_df.reset_index(drop=True, inplace=True)

                # Drop column with index 13
                filtered_df = filtered_df.drop(df.columns[13], axis=1)

                # Assign the new column names to the DataFrame
                filtered_df.columns = const.CONST_PROTEL_INVOICEJPG_NEWCOLUMNS
                filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

                # Save the modified DataFrame back to the Excel file
                output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

                # Combine the folder path and Excel file name to create the full path
                excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)
                filtered_df.to_excel(excel_file_path, index=False, header=True)
                
                insert_journal_data(excel_file_path, db_conn, logger, error_logger)

                logger.info(const.CONST_DATA_PARSED_SAVED_SUCESS)
            
            except Exception as exp:
                error_logger.error(f"Error in database processing {property_id} {filename}: {str(exp)} ")
                # send_failure_email(
                #     failure_reason="Error in processing the invoice report",
                #     error_description=f"Error during database insertion for {filename}: {exp}",
                #     suggested_action="Please verify the report format and data consistency, and try again."
                # )

def split_dataframe_by_separator(df, separator, property_id,  property_name):
    """
       Split dataframes using seperator distribution channel and merge as single report
    """
    separator_indices = df[df.apply(lambda row: separator in str(row), axis=1)].index.tolist()
    split_dataframes = []

    prev_channel_name = None

    for indice in range(len(separator_indices)):
        start_idx = separator_indices[indice]
        end_idx = separator_indices[indice + 1] if indice + 1 < len(separator_indices) else None

        # Extract channel name from the row above the separator
        channel_name = df.iloc[start_idx - 1, 0] if start_idx > 0 else None

        # Store the channel name for the current split
        prev_channel_name = channel_name if channel_name else prev_channel_name

        # Create a new DataFrame with the channel name and the data between separators
        split_df = df.iloc[start_idx:end_idx].copy()

        # Add the associated channel name as a new column
        split_df[28] = prev_channel_name
        split_df[29] = property_id
        split_df[30] = property_name

        split_dataframes.append(split_df)

    return split_dataframes

def parse_save_dc_report(excel_file_path, filename, separator, property_id, property_name, db_conn, logger, error_logger):
    """
        Parse saved distribution channel xlsx report data and insert into database
    """
    excel_directory = excel_file_path
    prefix_to_search = const.CONST_PROTEL_DC_SUFFIX

    output_dataframes = []  # List to store DataFrames from all sheets
 
    if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_XLSX_EXTENSION):
        file_path = os.path.join(excel_directory, filename)
        try:
            Xlsx2csv(file_path, outputencoding="utf-8").convert(file_path[:-5] + const.CONST_CSV_EXTENSION)
        except Exception as exp:
            logger.error(f"Invalid xlsx file: {exp}")
            # send_failure_email(
            #     failure_reason="Invalid XLSX file in distribution channel",
            #     error_description=f"Error during conversion of XLSX to CSV  {filename}: {exp}",
            #     suggested_action="Please check the file format or the file's content and try again."
            # )

        filename = os.path.splitext(filename)[0] + const.CONST_CSV_EXTENSION

        if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_CSV_EXTENSION):
            # Extract the date and time from the file name
            date_time = filename.replace(prefix_to_search, "").replace(const.CONST_CSV_EXTENSION, "")
            try:
                file_path = os.path.splitext(file_path)[0] + const.CONST_CSV_EXTENSION
                # Read the Excel file into a pandas DataFrame and skip the header row
                df = pd.read_csv(file_path, header=None, engine="python")
            
                tables = split_dataframe_by_separator(df, separator, property_id, property_name)

                for idx, table in enumerate(tables):
                    result_df = pd.DataFrame()
                    column_indices_to_extract = [0, 2, 7, 14, 16, 17, 19, 22, 25, 27, 28, 29, 30]

                    for col_index in column_indices_to_extract:
                        if col_index < table.shape[1]:
                            result_df[table.columns[col_index]] = table.iloc[:, col_index]
                        else:
                            result_df[str(col_index)] = None
            
                    def contains_pattern(row):
                        return any(pattern in str(row) for pattern in const.CONST_PROTEL_DC_PATERN_DROP)

                    filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]
                    column_name_mapping = {
                        0: const.CONST_RESERVATION_ID,
                        2: "booker",
                        7: "room_id",
                        14: "arrival",
                        16: "departure",
                        17: "room_nights",
                        19: "logis",
                        22: "extras",
                        25: "fandb",
                        27: "total_price",
                        28: "booking_channel",
                        29: "property_id",
                        30: "property_name",
                        
                    }
                    filtered_df = filtered_df.rename(columns=column_name_mapping)
                    output_dataframes.append(filtered_df)

            except Exception as exp:
                error_logger.error(f"Error in database processing {property_id} {filename}: {str(exp)}")
                # send_failure_email(
                #     failure_reason="Error in processing the distribution channel report",
                #     error_description=f"Error during database insertion for {filename}: {exp}",
                #     suggested_action="Please verify the report format and data consistency, and try again."
                # )
    # Concatenate all DataFrames into a single DataFrame
    try:
        merged_df = pd.concat(output_dataframes)
        output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX
        excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)
        merged_df.to_excel(excel_file_path, index=False, header=True)

        # Call the insert_distribution_channel_data function
        insert_distribution_channel_data(excel_file_path, db_conn, logger, error_logger)

        logger.info(const.CONST_DATA_PARSED_SAVED_SUCESS)
    except Exception as exp:
        logger.error(f"Error in data parsing or empty data: {exp} ")
        # send_failure_email(
        #     failure_reason="Error in parsing or empty data in distribution channel",
        #     error_description=f"Failed to process the distribution channel data for {filename}: {exp}",
        #     suggested_action="Please verify if the report contains valid data and ensure proper formatting."
        # )


def parse_save_dcs_report(excel_file_path, filename, property_id, db_conn, logger, error_logger):
    """
        Parse saved distribution channel statistics xlsx report and insert into database
    """
    # Directory containing your Excel files
    excel_directory = excel_file_path

    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_DC_STATS_SUFFIX
    
    if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_XLSX_EXTENSION):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)
        
        try:
            Xlsx2csv(file_path, outputencoding="utf-8").convert(file_path[:-5] + const.CONST_CSV_EXTENSION)
        except Exception as exp:
            logger.error(f"Invalid xlsx file: {exp}")
            # send_failure_email(
            #     failure_reason="Invalid XLSX file distribution channel statistics report",
            #     error_description=f"Error during conversion of XLSX to CSV {filename}: {exp}",
            #     suggested_action="Please check the file format or the file's content and try again."
            # )

        filename = os.path.splitext(filename)[0] + const.CONST_CSV_EXTENSION

        if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_CSV_EXTENSION):
            # Extract the date and time from the file name
            date_time = filename.replace(prefix_to_search, "").replace(const.CONST_CSV_EXTENSION, "")
            try:
                file_path = os.path.splitext(file_path)[0] + const.CONST_CSV_EXTENSION
                # Read the Excel file into a pandas DataFrame and skip the header row
                df = pd.read_csv(file_path, header=None, engine="python")
                
                # # Initialize a DataFrame to store the extracted columns
                result_df = pd.DataFrame()

                # Define the column indices you want to extract
                column_indices_to_extract = [0, 2, 4, 5, 6, 8, 13, 18, 20, 21, 22, 25, 26, 32, 34, 36, 37, 39, 40]  ## [A, C, E, F, G, I, N, S, U, V, W, Z, AA, AG, AI, AK, AL, AN, AO]

                # Iterate through the column indices you want to extract
                for col_index in column_indices_to_extract:
                    if col_index < df.shape[1]:
                        # If the column index is valid, copy it to the result DataFrame
                        result_df[df.columns[col_index]] = df.iloc[:, col_index]
                    else:
                        # If the column index is out of bounds, fill the result DataFrame with NaN
                        result_df[str(col_index)] = None

                # Drop empty rows (rows with all NaN values)
                result_df = result_df.dropna(how="all")
                
                # Function to check if a row contains any of the specified patterns
                def contains_pattern(row):
                    return any(pattern in str(row) for pattern in const.CONST_PROTEL_DCS_PATERN_DROP)

                # Filter rows to keep
                filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]

                # Assign new column names and Define the new column names
                new_column_names = const.CONST_PROTEL_DCS_NEW_COLUMNS

                # # Assign the new column names to the DataFrame
                filtered_df.columns = new_column_names
            
                filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id
                filtered_df["date_"] = const.CONST_END_DATE
            
                # Save the modified DataFrame back to the Excel file
                output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

                # Combine the folder path and Excel file name to create the full path
                excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)

                filtered_df.to_excel(excel_file_path, index=False, header=True)

                # Call the insert_distribution_channel_status_data function
                insert_distribution_channel_status_data(excel_file_path, db_conn, logger, error_logger)
    
                logger.info(const.CONST_DATA_PARSED_SAVED_SUCESS)
            
            except Exception as exp:
                error_logger.error(f"Error in database processing {property_id} {filename}: {str(exp)}")
                # send_failure_email(
                # failure_reason="Error in parsing or empty data in distribution channel statistics report",
                # error_description=f"Failed to process the distribution channel statistics data for {filename}: {exp}",
                # suggested_action="Please verify if the report contains valid data and ensure proper formatting."
                # )


def parse_save_hs_report(excel_file_path,filename, property_id, db_conn, logger, error_logger):
    """
        Parse saved house status xlsx report data and insert into database
    """
    # Directory containing your Excel files
    excel_directory = excel_file_path

    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_HS_SUFFIX
    
    if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_XLSX_EXTENSION):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)

        try:
            Xlsx2csv(file_path, outputencoding="utf-8").convert(file_path[:-5] + const.CONST_CSV_EXTENSION)
        except Exception as exp:
            logger.error(f"Invalid xlsx file: {exp}")
            # send_failure_email(
            #     failure_reason="Invalid XLSX file in hotel status",
            #     error_description=f"Error during conversion of XLSX to CSV {filename}: {exp}",
            #     suggested_action="Please check the file format or the file's content and try again."
            # )

        filename = os.path.splitext(filename)[0] + const.CONST_CSV_EXTENSION

        if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_CSV_EXTENSION):
            # Extract the date and time from the file name
            date_time = filename.replace(prefix_to_search, "").replace(const.CONST_CSV_EXTENSION, "")
            try:
                file_path = os.path.splitext(file_path)[0] + const.CONST_CSV_EXTENSION
                # Read the Excel file into a pandas DataFrame and skip the header row
                df = pd.read_csv(file_path, header=None, engine="python")

                # # Initialize a DataFrame to store the extracted columns
                result_df = pd.DataFrame()
                # Define the column indices you want to extract
                column_indices_to_extract = [
                    0,
                    2,
                    5,
                    6,
                    9,
                    13,
                    21,
                    22,
                    28,
                    29,
                    33,
                    34,
                    38,
                    39,
                    42,
                    44,
                    48,
                    49,
                ]
                # Iterate through the column indices you want to extract
                for col_index in column_indices_to_extract:
                    if col_index < df.shape[1]:
                        # If the column index is valid, copy it to the result DataFrame
                        result_df[df.columns[col_index]] = df.iloc[:, col_index]
                    else:
                        # If the column index is out of bounds, fill the result DataFrame with NaN
                        result_df[str(col_index)] = None
             
                # Define the patterns for the rows to drop
                patterns_to_drop = const.CONST_PROTEL_HS_PATERN_DROP

                # Function to check if a row contains any of the specified patterns
                def contains_pattern(row):
                    return any(pattern in str(row) for pattern in patterns_to_drop)

                # Filter rows to keep
                filtered_df = result_df[~result_df.apply(lambda row: contains_pattern(row), axis=1)]
                # Drop empty rows (all NaN values)
                filtered_df = filtered_df.dropna(how="all")


                # Reset index for clean output
                filtered_df.reset_index(drop=True, inplace=True)
                # filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]
                #### Assign new column names
                # filtered_df = result_df[
                #     ~result_df.iloc[:, 0].isin([None, 'Datum', 'NaN'])  # Check first column for NaN or 'Datum'
                # ]
                # filtered_df.reset_index(drop=True, inplace=True)
                ### Define the new column names
                new_column_names = const.CONST_PROTEL_HS_NEW_COLUMNS
                # Assign the new column names to the DataFrame
                filtered_df.columns = new_column_names
                # Split by comma, take the second part (after the comma), and strip any leading/trailing whitespace
                filtered_df["date_"] = filtered_df["date_"].str.split(",", expand=True)[1].str.strip()
                # Strip leading spaces and then convert the "Date" column to the desired format
                filtered_df["date_"] = pd.to_datetime(
                    filtered_df["date_"].str.strip(), format="%d.%m.%Y"
                ).dt.strftime("%Y-%m-%d")
                filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

                # Save the modified DataFrame back to the Excel file
                output_file_path = (
                    prefix_to_search
                    + date_time
                    + const.CONST_PROTEL_FILTERED_FILE_SUFFIX
                )

                # Combine the folder path and Excel file name to create the full path
                excel_file_path = os.path.join(
                    parsed_excel_reports_folder_path, output_file_path
                )

                filtered_df.to_excel(excel_file_path, index=False, header=True)

                # Call the insert_hotel_status_data function
                insert_hotel_status_data(excel_file_path, db_conn, logger, error_logger)
                logger.info(const.CONST_DATA_PARSED_SAVED_SUCESS)

            except Exception as exp:
                error_logger.error(f"Error in database processing {property_id} {filename}: {str(exp)}") 
                # send_failure_email(
                # failure_reason="Error in parsing or empty data in hotel status report",
                # error_description=f"Failed to process the hotel status data for {filename}: {exp}",
                # suggested_action="Please verify if the report contains valid data and ensure proper formatting."
                # )

def parse_save_hsbt_report(excel_file_path, filename, property_id, db_conn, logger,error_logger):
    """
        Parse saved house status by booking type xlsx report data and insert into database
    """
    # Directory containing your Excel files
    excel_directory = excel_file_path

    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_HSBT_SUFFIX

    if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_XLSX_EXTENSION):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)
        
        # Extract the date and time from the file name
        try:
            Xlsx2csv(file_path, outputencoding="utf-8").convert(file_path[:-5] + const.CONST_CSV_EXTENSION)
        except Exception as exp:
            logger.error(f"Invalid xlsx file: {exp}")
            # send_failure_email(
            #     failure_reason="Invalid XLSX file in hotel status booking type report",
            #     error_description=f"Error during conversion of XLSX to CSV {filename}: {exp}",
            #     suggested_action="Please check the file format or the file's content and try again."
            # )

        filename = os.path.splitext(filename)[0] + const.CONST_CSV_EXTENSION

        if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_CSV_EXTENSION):
            # Extract the date and time from the file name
            date_time = filename.replace(prefix_to_search, "").replace(const.CONST_CSV_EXTENSION, "")
            try:
                file_path = os.path.splitext(file_path)[0] + const.CONST_CSV_EXTENSION
                # Read the Excel file into a pandas DataFrame and skip the header row
                df = pd.read_csv(file_path, header=None, engine="python")


                # Drop columns with all None values
                df = df.dropna(axis=1, how="all")

                # Define the patterns for the rows to drop
                patterns_to_drop = const.CONST_PROTEL_HSBT_PATERN_DROP

                # Function to check if a row contains any of the specified patterns
                def contains_pattern(row):
                    return any(pattern in str(row) for pattern in patterns_to_drop)

                # Filter rows to keep
                filtered_df = df[~df.apply(contains_pattern, axis=1)]

                # Create an empty list to store the formatted data
                formatted_data = []

                # Initialize variables to keep track of the current date
                current_date = None

                # Iterate through the rows in the original DataFrame
                for index, row in filtered_df.iterrows():
                    if not pd.isna(row.iloc[0]):
                        current_date = row.iloc[0]
                    elif current_date:
                        # Filter out None values in the row
                        filtered_row = [str(cell) if not pd.isna(cell) else "0" for cell in row[1:]]
                        # Append the current date to the beginning of the filtered row
                        formatted_data.append([current_date] + filtered_row)

                # Create a DataFrame from the formatted data
                formatted_df = pd.DataFrame(formatted_data, columns=["Date"] + df.columns[1:].tolist())

                # Specify the column indices you want to drop
                columns_to_drop = [2, 3, 5, 7, 8, 11, 13, 16, 18]

                # Drop the specified columns
                formatted_df.drop(formatted_df.columns[columns_to_drop], axis=1, inplace=True)
                column_name_mapping = {
                    2: "Logis",
                    5: "FandB",
                    7: "Extras",
                    10: "Total",
                    14: "Room",
                    16: "Comp_room",
                    19: "House_use_room",
                    21: "OoR_rooms",
                    23: "Rooms_overall",
                }

                # Split by comma, take the second part (after the comma), and strip any leading/trailing whitespace
                formatted_df["Date"] = formatted_df["Date"].str.split(",", expand=True)[1].str.strip()

                # Strip leading spaces and then convert the "Date" column to the desired format
                formatted_df["Date"] = pd.to_datetime(formatted_df["Date"].str.strip(), format="%d.%m.%Y").dt.strftime("%Y-%m-%d")

                # Rename the columns using the mapping dictionary
                formatted_df = formatted_df.rename(columns=column_name_mapping)
                formatted_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

                # Save the modified DataFrame back to the Excel file
                output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

                # Combine the folder path and Excel file name to create the full path
                excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)

                formatted_df.to_excel(excel_file_path, index=False, header=True)

                # Call the insert_hotel_status_by_booking_type function
                insert_hotel_status_by_booking_type(excel_file_path, db_conn, logger, error_logger)

                # Delete the original Excel file
                #os.remove(file_path)
                logger.info(const.CONST_DATA_PARSED_SAVED_SUCESS)
            
            except Exception as exp:
                error_logger.error(f"Error in database processing {property_id} {filename}: {str(exp)}")
                # send_failure_email(
                # failure_reason="Failed to Insert DCS Data into Database",
                # error_description=f"Error occurred while processing and inserting data from {filename} for property {property_id}: {exp}",
                # suggested_action="Please check the file format or the file's content and try again."
                # )

def parse_save_hsr_report(excel_file_path, filename, property_id, db_conn, logger, error_logger):
    """
        Parse saved house status by room report data and insert into database
    """
    excel_directory = excel_file_path
    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_HSBR_SUFFIX
    if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_XLSX_EXTENSION):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)

        try:
            Xlsx2csv(file_path, outputencoding="utf-8").convert(file_path[:-5] + const.CONST_CSV_EXTENSION)
        except Exception as exp:
            logger.error(f"Invalid xlsx file: {exp}")
            # send_failure_email(
            #     failure_reason="Invalid XLSX file in hotel status wth rooms report",
            #     error_description=f"Error during conversion of XLSX to CSV {filename}: {exp}",
            #     suggested_action="Please check the file format or the file's content and try again."
            # )

        filename = os.path.splitext(filename)[0] + const.CONST_CSV_EXTENSION

        if filename.startswith(prefix_to_search) and filename.endswith(const.CONST_CSV_EXTENSION):
            # Extract the date and time from the file name
            date_time = filename.replace(prefix_to_search, "").replace(const.CONST_CSV_EXTENSION, "")
            try:
                file_path = os.path.splitext(file_path)[0] + const.CONST_CSV_EXTENSION
                # Read the Excel file into a pandas DataFrame and skip the header row
                df = pd.read_csv(file_path, header=None, engine="python")

                # # Initialize a DataFrame to store the extracted columns
                result_df = pd.DataFrame()

                # Define the column indices you want to extract
                column_indices_to_extract = [
                    0,
                    1,
                    2,
                    3,
                    4,
                    9,
                    12,
                    14,
                    16,
                    20,
                    23,
                    25,
                    26,
                    28,
                    29,
                    31,
                    33,
                ]  ## [A, B, C, D, E, J, M, O, Q, U, X, Z, AA, AC, AD, AF, AH]

                # Iterate through the column indices you want to extract
                for col_index in column_indices_to_extract:
                    if col_index < df.shape[1]:
                        # If the column index is valid, copy it to the result DataFrame
                        result_df[df.columns[col_index]] = df.iloc[:, col_index]
                    else:
                        # If the column index is out of bounds, fill the result DataFrame with NaN
                        result_df[str(col_index)] = None

                # Drop empty rows (rows with all NaN values)
                result_df = result_df.dropna(how="all")

                # Define the patterns for the rows to drop
                patterns_to_drop = const.CONST_PROTEL_HSBR_PATERN_DROP

                # Function to check if a row contains any of the specified patterns
                def contains_pattern(row):
                    return any(pattern in str(row) for pattern in patterns_to_drop)

                # Filter rows to keep
                filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]

                column_name_mapping = {
                    0: "room_type",
                    1: "room_available",
                    2: "room_available_percent",
                    3: "room_occ",
                    4: "room_occ_percent",
                    9: "arrival_count",
                    12: "arrival_per",
                    14: "leave_count",
                    16: "leave_per",
                    20: "In_house_count",
                    23: "In_house_percent",
                    25: "logis",
                    26: "fandb",
                    28: "extras",
                    29: "total",
                    31: "misc",
                    33: "misc_percent",
                }

                # Rename the columns using the mapping dictionary
                filtered_df = filtered_df.rename(columns=column_name_mapping)
                filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

                # Save the modified DataFrame back to the Excel file
                output_file_path = (
                    prefix_to_search
                    + date_time
                    + const.CONST_PROTEL_FILTERED_FILE_SUFFIX
                )

                # Combine the folder path and Excel file name to create the full path
                excel_file_path = os.path.join(
                    parsed_excel_reports_folder_path, output_file_path
                )

                filtered_df.to_excel(excel_file_path, index=False, header=True)

                # Call the insert_hotel_status_data function
                insert_hotel_status_rooms_data(excel_file_path, db_conn, logger, error_logger)

                logger.info(const.CONST_DATA_PARSED_SAVED_SUCESS)

            except Exception as exp:
                error_logger.error(f"Error in database processing {property_id} {filename}: {str(exp)}")   
                # send_failure_email(
                # failure_reason="Error in parsing or empty data in hotel status by rooms report",
                # error_description=f"Failed to process the hotel status by rooms data for {filename}: {exp}",
                # suggested_action="Please verify if the report contains valid data and ensure proper formatting."
                # )

def parse_download_file(logger, error_logger, db_conn, filename, property_id, property_name, file_data ):
        """
        Download reports and dump into folder.
        Report parsed and store data into database using parse methods

        Args:
            response (_type_): _description_
        """     
        
        if file_data is not None and filename.startswith(const.CONST_PROTEL_DC_STATS_SUFFIX):
            local_path = os.path.join(
                os.getcwd(), const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_STATS_FOLDER
            )
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(const.CONST_PROTEL_DOWNLOAD_SAVE_LOG.format(filename=filename))
            parse_save_dcs_report(
                local_path, filename, property_id, db_conn, logger,error_logger
            )

        if file_data is not None and filename.startswith(const.CONST_PROTEL_HS_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_HS_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(const.CONST_PROTEL_DOWNLOAD_SAVE_LOG.format(filename=filename))
            parse_save_hs_report(
                local_path, filename, property_id, db_conn, logger, error_logger
            )

        if file_data is not None and filename.startswith(const.CONST_PROTEL_HSBT_SUFFIX):
            local_path = os.path.join(
                os.getcwd(), const.CONST_PROTEL_REPORT_HSBT_FOLDER
            )
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(const.CONST_PROTEL_DOWNLOAD_SAVE_LOG.format(filename=filename))
            parse_save_hsbt_report(
                local_path, filename, property_id, db_conn, logger, error_logger
            )

        if file_data is not None and filename.startswith(const.CONST_PROTEL_HSBR_SUFFIX):
            local_path = os.path.join(
                os.getcwd(), const.CONST_PROTEL_REPORT_HSBR_FOLDER
            )
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(const.CONST_PROTEL_DOWNLOAD_SAVE_LOG.format(filename=filename))
            parse_save_hsr_report(
                local_path, filename, property_id, db_conn, logger, error_logger
            )
            
        if file_data is not None and filename.startswith(const.CONST_PROTEL_DC_SUFFIX):
            local_path = os.path.join(
                os.getcwd(), const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_FOLDER
            )
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(const.CONST_PROTEL_DOWNLOAD_SAVE_LOG.format(filename=filename))

            parse_save_dc_report(
                local_path,
                filename,
                const.CONST_PROTEL_DC_SEPERATOR,
                property_id,
                property_name,
                db_conn,
                logger,
                error_logger
            )
        # Invoce data skip
        if const.DOWNLOAD_PARSE_INVOICE and file_data is not None and filename.startswith(const.CONST_PROTEL_INVOICE_JPG_SUFFIX):
            local_path = os.path.join(
                os.getcwd(), const.CONST_PROTEL_REPORT_INVOICE_FOLDER
            )
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(const.CONST_PROTEL_DOWNLOAD_SAVE_LOG.format(filename=filename))

            parse_save_invoice_report(
                local_path, filename, property_id, db_conn, logger,error_logger
            )
            
def parse_reservation_details(logger, error_logger, db_conn, headers, start_date, end_date, resveration_period_details, report_definition_details, global_hotel_id, property_id, property_name):
        """
        Parse reservation details using reservation states and hotel ids
        Also parse room plan data through API

        """
        cursor = db_conn.connection.cursor()
        headers[const.CONST_PROTEL_GLOBALHOTELID] = global_hotel_id
        headers[const.CONST_PROTEL_HOTELID] = property_id
        loop_property_name = property_name
        loop_property_id = property_id

        flt_item_group_ids_options = []
        flt_type_channel_options = []
        flt_room_options = []
        flt_category_hs_options = []
        flt_category_hsbr_options = []
        flt_state_options = []
        flt_category_hsbt_options = []
        dist_channel_list = []
        channel_item_name = None
        channel_report_definition_id = None
        channel_stats_name = None
        channel_stats_report_definition_id = None
        house_sate_name = None
        house_sate_report_definition_id = None
        house_sate_by_room_name = None
        house_sate_by_room_report_definition_id = None
        house_sate_btype_name = None
        house_sate_btype_report_definition_id = None
        property_id = None
        print_task_ids = []
        
        # Get the current date
        current_date = datetime.now().date()
        # Calculate the end date by adding 6 days to the current date
        end_date = current_date + timedelta(days=7)
        # Format the end_date as a string in the required format
        formatted_end_date = end_date.strftime('%Y-%m-%d')  # Adjust the format as needed
            
        if "data" in report_definition_details:
            if const.DOWNLOAD_PARSE_INVOICE:
                rechnung_data = next(
                    (
                        item
                        for item in report_definition_details["data"]
                        if item.get("groupName") == const.CONST_PROTEL_INVOICE_SECTION
                    ),
                    None,
                )
                keywords_to_match = const.CONST_PROTEL_REPORT_INVOICE_FILTER
                flt_item_ids_options = {
                    keywords_to_match[0]: [],
                    keywords_to_match[1]: [],
                    keywords_to_match[2]: [],
                }

            reservierung_data = next(
                (
                    item
                    for item in report_definition_details["data"]
                    if item.get("groupName") == const.CONST_PROTEL_RESERVATION_SECTION
                ),
                None,
            )
            import pdb

            if (
                reservierung_data
                and const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST in reservierung_data
            ):
                channel_items = [
                    item
                    for item in reservierung_data[
                        const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST
                    ]
                    if item.get(const.CONST_NAME) == const.CONST_PROTEL_CHANNELS
                ]

                channel_item_name = channel_items[0].get(const.CONST_NAME)
                channel_report_definition_id = channel_items[0].get(
                    const.CONST_PROTEL_REPORT_DEFINITIONID_ID
                )

                for group in channel_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if (
                            component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                            == const.CONST_FLTTYPE
                        ):
                            options = (
                                component.get(const.CONST_PARAMETERS)
                                .get(const.CONST_OPTIONS)
                                .get(const.CONST_OPTION)
                            )
                            for option in options:
                                flt_type_channel_options.append(option.get("value"))
                                dist_channel_list.append(option.get("label"))

                channel_stats_items = [
                    item
                    for item in reservierung_data[
                        const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST
                    ]
                    if item.get(const.CONST_NAME) == const.CONST_PROTEL_DC_STATS_CHANNEL
                ]

                channel_stats_name = channel_stats_items[0].get(const.CONST_NAME)
                channel_stats_report_definition_id = channel_stats_items[0].get(
                    const.CONST_PROTEL_REPORT_DEFINITIONID_ID
                )

                house_sate_items = [
                    item
                    for item in reservierung_data[
                        const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST
                    ]
                    if item.get(const.CONST_NAME) == const.CONST_PROTEL_HOUSESTATE
                ]

                house_sate_name = house_sate_items[0].get(const.CONST_NAME)
                house_sate_report_definition_id = house_sate_items[0].get(
                    const.CONST_PROTEL_REPORT_DEFINITIONID_ID
                )

                for group in house_sate_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if (
                            component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                            == const.CONST_FLTROOM
                        ):
                            options = (
                                component.get(const.CONST_PARAMETERS)
                                .get(const.CONST_OPTIONS)
                                .get(const.CONST_OPTION)
                            )
                            for option in options:
                                flt_room_options.append(option.get("value"))

                        if (
                            component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                            == const.CONST_FLTSTATEIDS
                        ):
                            options = (
                                component.get(const.CONST_PARAMETERS)
                                .get(const.CONST_OPTIONS)
                                .get(const.CONST_OPTION)
                            )
                            for option in options:
                                if option.get('label') == const.CONST_FILTER_HOUSE_RESERVATION_STATUS:
                                    flt_state_options.append(option.get("value"))

                        if (
                            component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                            == const.CONST_FLITCATEGORY
                        ):
                            options = (
                                component.get(const.CONST_PARAMETERS)
                                .get(const.CONST_OPTIONS)
                                .get(const.CONST_OPTION)
                            )
                            for option in options:
                                flt_category_hs_options.append(option.get("value"))

                house_sate_by_room_items = [
                    item
                    for item in reservierung_data[
                        const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST
                    ]
                    if item.get(const.CONST_NAME) == const.CONST_PROTEL_HSBR
                ]

                house_sate_by_room_name = house_sate_by_room_items[0].get(
                    const.CONST_NAME
                )
                house_sate_by_room_report_definition_id = house_sate_by_room_items[
                    0
                ].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)

                for group in house_sate_by_room_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if (
                            component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                            == const.CONST_FLITCATEGORY
                        ):
                            options = (
                                component.get(const.CONST_PARAMETERS)
                                .get(const.CONST_OPTIONS)
                                .get(const.CONST_OPTION)
                            )
                            for option in options:
                                flt_category_hsbr_options.append(option.get("value"))

                house_sate_bookingtype_items = [
                    item
                    for item in reservierung_data[
                        const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST
                    ]
                    if item.get(const.CONST_NAME) == const.CONST_PROTEL_HSBT
                ]

                house_sate_btype_name = house_sate_bookingtype_items[0].get(
                    const.CONST_NAME
                )
                house_sate_btype_report_definition_id = house_sate_bookingtype_items[
                    0
                ].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)

                for group in house_sate_bookingtype_items[0].get(
                    const.CONST_DISPLAYGROUP
                ):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if (
                            component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                            == const.CONST_FLITCATEGORY
                        ):
                            options = (
                                component.get(const.CONST_PARAMETERS)
                                .get(const.CONST_OPTIONS)
                                .get(const.CONST_OPTION)
                            )
                            for option in options:
                                flt_category_hsbt_options.append(option.get("value"))

            else:
                logger.error(
                    f"No data found for groupName: {const.CONST_PROTEL_RESERVATION_SECTION}"
                )
                
            flt_type_channel_options = ",".join(map(str, flt_type_channel_options))
            flt_room_options = ",".join(map(str, flt_room_options))
            flt_category_hs_options = ",".join(map(str, flt_category_hs_options))
            flt_category_hsbr_options = ",".join(map(str, flt_category_hsbr_options))
            flt_state_options = ",".join(map(str, flt_state_options))
            flt_category_hsbt_options = ",".join(map(str, flt_category_hsbt_options))
            pdb.set_trace()
            channel_payload = {
                const.CONST_NAME: channel_item_name,
                "reportDefinitionId": channel_report_definition_id,
                "params": "timeMode=2;validFrom={start};validTo={end};fltType={fltYpe}".format(
                    start=start_date,
                    end=end_date,
                    fltYpe=flt_type_channel_options,
                ),
            }
            channel_payload = json.dumps(channel_payload)
            
            while True:
                channel_task_data = requests.post(
                    url=const.CONST_PROTEL_PRINT_REPORT_API_URL,
                    headers=headers,
                    data=channel_payload,
                )
                if channel_task_data.status_code == const.CONST_STATUS_CODE:
                    channel_task_data = channel_task_data.json()
                    print_task_ids.append(channel_task_data["data"][const.CONST_TASKID])
                    break
                elif channel_task_data.status_code == 500:
                    error_logger.error(f"Distribution channel task id not generated {channel_task_data.status_code} : {loop_property_id}")
                    break
                else:
                    error_logger.error(f"Distribution channel task id not generated Re-authenticate {channel_task_data.status_code} : {loop_property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
    
            channel_stats_payload = {
                const.CONST_NAME: channel_stats_name,
                "reportDefinitionId": channel_stats_report_definition_id,
                "params": "validTo={end};state=1;onlyRevenueRelevant=0;fltGross=0".format(
                    end=end_date
                ),
            }
            channel_stats_payload = json.dumps(channel_stats_payload)
                
            while True:
                channel_stats_task_data = requests.post(
                    url=const.CONST_PROTEL_PRINT_REPORT_API_URL,
                    headers=headers,
                    data=channel_stats_payload,
                )

                if channel_stats_task_data.status_code == const.CONST_STATUS_CODE:
                    channel_stats_task_data = channel_stats_task_data.json()
                    print_task_ids.append(
                        channel_stats_task_data["data"][const.CONST_TASKID]
                    )
                    break
                elif channel_stats_task_data.status_code == 500:
                    error_logger.error(f"Distribution channel stats task id not generated {channel_stats_task_data.status_code} : {loop_property_id}")
                    break
                else:
                    error_logger.error(f"Distribution channel stats task id not generated Re-authenticate {channel_stats_task_data.status_code} : {loop_property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
                        
            house_state_payload = {
                const.CONST_NAME: house_sate_name,
                "reportDefinitionId": house_sate_report_definition_id,
                "params": "validFrom={start};validTo={end};group=none;reportType=0;fltRoom={fltroom_options};fltCategory={filtCategory_options};fltStateIDs={fltstate_ids};fltIgnoreFlag=0;fltBrutto=0;fltOOO=1;fltPseudo=0".format(
                    start=start_date,
                    end=formatted_end_date,
                    fltroom_options=flt_room_options,
                    filtCategory_options=flt_category_hs_options,
                    fltstate_ids=flt_state_options,
                ),
            }
            house_state_payload = json.dumps(house_state_payload)
            
            while True:
                hs_task_data = requests.post(
                    url=const.CONST_PROTEL_PRINT_REPORT_API_URL,
                    headers=headers,
                    data=house_state_payload,
                )
                if hs_task_data.status_code == const.CONST_STATUS_CODE:
                    hs_task_data = hs_task_data.json()
                    print_task_ids.append(hs_task_data["data"][const.CONST_TASKID])
                    break
                elif hs_task_data.status_code == 500:
                    error_logger.error(f"Hotel status report task id not generated {hs_task_data.status_code} : {loop_property_id}")
                    break
                else:
                    error_logger.error(f"Hotel status report task id not genreated Re-authenticate {hs_task_data.status_code} : {loop_property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"

            house_state_rooms_payload = {
                const.CONST_NAME: house_sate_by_room_name,
                "reportDefinitionId": house_sate_by_room_report_definition_id,
                "params": "validFrom={start};validTo={end};fltCategory={fltcategory_options};reportMode=0;fltIgnoreFlag=0;fltBrutto=0".format(
                    start=start_date,
                    end=end_date,
                    fltcategory_options=flt_category_hsbr_options,
                ),
            }
            house_state_rooms_payload = json.dumps(house_state_rooms_payload)
            
            while True:   
                hsbr_task_data = requests.post(
                    url=const.CONST_PROTEL_PRINT_REPORT_API_URL,
                    headers=headers,
                    data=house_state_rooms_payload,
                )

                if hsbr_task_data.status_code == const.CONST_STATUS_CODE:
                    hsbr_task_data = hsbr_task_data.json()
                    print_task_ids.append(hsbr_task_data["data"][const.CONST_TASKID])
                    break
                elif hsbr_task_data.status_code == 500:
                    error_logger.error(f"Hotel status rooms report task id not generated {hsbr_task_data.status_code } : {loop_property_id}")
                    break
                else:
                    error_logger.error(f"Hotel status rooms report task id not generated Re-authenticate {hsbr_task_data.status_code } : {loop_property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
                
            house_state_btype_payload = {
                const.CONST_NAME: house_sate_btype_name,
                "reportDefinitionId": house_sate_btype_report_definition_id,
                "params": "validFrom={start};validTo={end};reportType=0;fltCategory={fltcategory_options};fltIgnoreFlag=0;fltBrutto=0".format(
                    start=start_date,
                    end=end_date,
                    fltcategory_options=flt_category_hsbt_options,
                ),
            }
            house_state_btype_payload = json.dumps(house_state_btype_payload)
            
            while True:
                hsbt_task_data = requests.post(
                    url=const.CONST_PROTEL_PRINT_REPORT_API_URL,
                    headers=headers,
                    data=house_state_btype_payload,
                )
                if hsbt_task_data.status_code == const.CONST_STATUS_CODE:
                    hsbt_task_data = hsbt_task_data.json()
                    print_task_ids.append(hsbt_task_data["data"][const.CONST_TASKID])
                    break
                elif hsbt_task_data.status_code == 500: 
                    error_logger.error(
                        f"Hotel status booking type report task id not generated {hsbt_task_data.status_code} :{loop_property_id}"
                    )
                    break
                else:
                    error_logger.error(
                        f"Hotel status booking type report task id not generated Re-authenticate {hsbt_task_data.status_code} :{loop_property_id}"
                    )
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"               
                        
            # Invoce data skip flag
            if const.DOWNLOAD_PARSE_INVOICE:
                journal_item_name = None
                journal_report_definition_id = None
                if (
                    rechnung_data
                    and const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST in rechnung_data
                ):
                    journal_items = [
                        item
                        for item in rechnung_data[
                            const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST
                        ]
                        if item.get(const.CONST_NAME)
                        == const.CONST_PROTEL_INVOICE_REPORT_SECTION
                    ]

                    journal_item_name = journal_items[0].get(const.CONST_NAME)
                    journal_report_definition_id = journal_items[0].get(
                        const.CONST_PROTEL_REPORT_DEFINITIONID_ID
                    )

                    for group in journal_items[0].get(const.CONST_DISPLAYGROUP):
                        for component in group.get(const.CONST_INPUTCOMPONENTS):
                            if (
                                component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                                == const.CONST_FLTITEMGROUPIDS
                            ):
                                options = (
                                    component.get(const.CONST_PARAMETERS)
                                    .get(const.CONST_OPTIONS)
                                    .get(const.CONST_OPTION)
                                )
                                for option in options:
                                    flt_item_group_ids_options.append(option.get("value"))

                            elif (
                                component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)
                                == const.CONST_FLTITEMIDS
                            ):
                                options = (
                                    component.get(const.CONST_PARAMETERS)
                                    .get(const.CONST_OPTIONS)
                                    .get(const.CONST_OPTION)
                                )
                                for option in options:
                                    label = option["label"]
                                    for word in keywords_to_match:
                                        if word in label.split()[0]:
                                            flt_item_ids_options[word].append(
                                                int(option["value"])
                                            )
                                            break  # Stop searching for other matches for this word

                else:
                    logger.error(
                        f"No data found for groupName: {const.CONST_PROTEL_INVOICE_SECTION}"
                    )

                flt_item_ids = [
                    flt_item_ids_options[keywords_to_match[0]][0] if flt_item_ids_options[keywords_to_match[0]] else None,
                    flt_item_ids_options[keywords_to_match[1]][0] if flt_item_ids_options[keywords_to_match[1]] else None,
                    flt_item_ids_options[keywords_to_match[2]][0] if flt_item_ids_options[keywords_to_match[2]] else None,
                ]
                
                filtered_flt_item_ids = [str(item) for item in flt_item_ids if item is not None]
                flt_item_group_str = ",".join(map(str, flt_item_group_ids_options))
                flt_item_group_ids_str = ",".join(map(str, filtered_flt_item_ids))
                
                journal_payload = {
                    const.CONST_NAME: journal_item_name,
                    "reportDefinitionId": journal_report_definition_id,
                    "params": "validFrom={start};validTo={end};fltIgnoreFlag=0;fltItemGroupIDs={flt_item_group_ids};fltItemIDs={flt_item_ids_list}".format(
                        start=start_date,
                        end=formatted_end_date,
                        flt_item_group_ids=flt_item_group_str,
                        flt_item_ids_list=flt_item_group_ids_str,
                    ),
                }
                journal_payload = json.dumps(journal_payload)
                
                while True:
                    journal_task_data = requests.post(
                        url=const.CONST_PROTEL_PRINT_REPORT_API_URL,
                        headers=headers,
                        data=journal_payload,
                    )
                    if journal_task_data.status_code == const.CONST_STATUS_CODE:
                        journal_task_data = journal_task_data.json()
                        print_task_ids.append(journal_task_data["data"][const.CONST_TASKID])
                        break
                    elif journal_task_data.status_code == 500:
                        logger.error(f"Invoice report task id not generated {journal_task_data.status_code} : {loop_property_id}")
                        break
                    else:
                        logger.error(f"Invoice report task id not generated Re-authenticate {journal_task_data.status_code} : {loop_property_id}")         
                        auth_data = protel_authentication(logger)
                        if auth_data is not None:
                            headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"

               
        else:
            logger.error("No data found for reservation definition details")
             
        if (
            resveration_period_details
            and resveration_period_details["response"]["content"] is not None
        ):
            room_id = None
            for res_detail in resveration_period_details["response"]["content"]:
                # Booker profile
                booker_id = res_detail[const.CONST_BOKERID]
                reservation_id = res_detail[const.CONST_RESERVATIONID]
                booker_name = res_detail[const.CONST_BOOKERNAME]

                # Booked property
                property_id = loop_property_id
                arrival_date = res_detail[const.CONST_ARRIVALDATE]
                departure_date = res_detail[const.CONST_DEPARTUREDATE]
                room_type = None
                persons = res_detail[const.CONST_GUESTCOUNT]
                res_status = res_detail[const.CONST_RESSTATENAME]
                country = res_detail[const.CONST_COUNTRY]
                dist_channel = res_detail[const.CONST_CHANNEL]
                booked_on = res_detail[const.CONST_RESERVATIONDATE]
                rate_code = res_detail[const.CONST_RATENAME]
                comm_chan = res_detail[const.CONST_HEARREASON]
                travel_reason = res_detail[const.CONST_COMEREASON]
                market_code = res_detail[const.CONST_MARKETCODE]

                arrival_day_obj = datetime.strptime(arrival_date, const.CONST_PROTEL_DATE_FORMAT)
                arrival_day = arrival_day_obj.strftime("%A")
                departure_day_obj = datetime.strptime(
                    departure_date,  const.CONST_PROTEL_DATE_FORMAT
                )
                departure_day = departure_day_obj.strftime("%A")
                creation_day_obj = datetime.strptime(booked_on, const.CONST_PROTEL_DATE_FORMAT)
                creation_day = creation_day_obj.strftime("%A")
                leadtime = (arrival_day_obj - creation_day_obj).days
                room_code = None
                created_by = const.CONST_PROTEL_CREATED_BY
                room_id = res_detail[const.CONST_CATEGORYID]
                cancel_on = None

                # guest profiles
                guest_id = res_detail[const.CONST_GUESTID]
                guests_name = res_detail[const.CONST_GUESTNAMES]
                adults = res_detail[const.CONST_AGEGROUPADULT]

                room_type = None
                room_code = None
                
                while True:
                    room_type_data = requests.get(
                        url=const.CONST_PROTEL_ROOMTYPE_API_URL, headers=headers
                    )
                    if room_type_data.status_code == const.CONST_STATUS_CODE:
                        roomtypes = room_type_data.json()
                        if roomtypes["data"] is not None:
                            matching_dict = None
                            # Iterate through the list of dictionaries
                            for dictionary in roomtypes["data"]:
                                if dictionary.get("id") == room_id:
                                    matching_dict = dictionary
                                    room_type = matching_dict["value"]["type"]
                                    room_code = matching_dict["value"]["code"]
                        break

                    elif room_type_data.status_code == 500 :
                        error_logger.error(f"Room type API failed {room_type_data.status_code} : {loop_property_id}")
                        break
                    else:
                        error_logger.error(f"Room type API failed Re-authenticate {room_type_data.status_code} : {loop_property_id} ")
                        auth_data = protel_authentication(logger)
                        if auth_data is not None:
                            headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
        
                try:
                    cursor.execute(
                        queries.INSERT_PROTEL_BOOKER_PROFILE,
                        (
                            booker_id,
                            property_id,
                            reservation_id,
                            booker_name,
                            created_by,
                        ),
                    )
                    db_conn.connection.commit()
                except Exception as excp:
                    logger.error("Booker profile already exist %s", excp)

                guest_api_url = const.CONST_PROTEL_GUEST_PROFILE_API_URL.format(
                    guest_id=guest_id
                )
                                   
                guest_names_list = guests_name.split(",")
                names = []
                for i, name in enumerate(guest_names_list, start=1):
                    names.append(name)
                    
                while True:
                    guest_data = requests.get(url=guest_api_url, headers=headers)
                    if guest_data.status_code == const.CONST_STATUS_CODE:
                        guest_data = guest_data.json()
                        if guest_data is not None and "data" in guest_data:
                            birthday = guest_data["data"]["birthday"]
                            age = guest_data["data"]["age"]

                            street = None
                            zip = None
                            city = None
                            if len(guest_data["data"]["addresses"]) > 0:
                                street = guest_data["data"]["addresses"][0]["street1"]
                                zip = guest_data["data"]["addresses"][0]["zip"]
                                city = guest_data["data"]["addresses"][0]["city"]

                            placeholders = ", ".join(["%s"] * len(names))
                            column_names = ", ".join(
                                [f"name{item+1}" for item in range(len(names))]
                            )
                            split_names = [name.split() for name in names]
                            first_names = [
                                split[0] if split else "" for split in split_names
                            ]
                            last_names = [
                                " ".join(split[1:]) if len(split) > 1 else ""
                                for split in split_names
                            ]

                            # Create placeholders for first names and last names based on the number of names
                            first_name_placeholders = ", ".join(["%s"] * len(first_names))
                            last_name_placeholders = ", ".join(["%s"] * len(last_names))

                            # Create column names for first names and last names
                            first_name_columns = ", ".join(
                                [f"first_name{item+1}" for item in range(len(first_names))]
                            )
                            last_name_columns = ", ".join(
                                [f"last_name{item+1}" for item in range(len(last_names))]
                            )

                            try:
                                guest_profile_query = (
                                    queries.INSERT_PROTEL_GUESTS_PROFILES.format(
                                        column_names=column_names,
                                        first_name_columns=first_name_columns,
                                        last_name_columns=last_name_columns,
                                        placeholders=placeholders,
                                        first_name_placeholders=first_name_placeholders,
                                        last_name_placeholders=last_name_placeholders,
                                    )
                                )

                                cursor.execute(
                                    guest_profile_query,
                                    (
                                        guest_id,
                                        property_id,
                                        reservation_id,
                                        booker_id,
                                        guests_name,
                                        *names,
                                        *first_names,
                                        *last_names,
                                        birthday,
                                        age,
                                        leadtime,
                                        adults,
                                        street,
                                        city,
                                        zip,
                                        const.CONST_PROTEL_CREATED_BY,
                                    ),
                                )
                                db_conn.connection.commit()
                            except Exception as excep:
                                logger.error("Guest profile already exist %s", excep)
                        break
                    elif guest_data.status_code == 500:
                        error_logger.error(f"Guest profile API failed {guest_data.status_code} : {loop_property_id}")
                        break
                    else:
                        error_logger.error(f"Guest profile API failed Re-authenticate {guest_data.status_code} : {loop_property_id}")
                        auth_data = protel_authentication(logger)
                        if auth_data is not None:
                            headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"

                date_arrival = parse(arrival_date).date()
                arrival_date_string = date_arrival.strftime('%Y-%m-%d')
                date_departure = parse(departure_date).date()
                departure_date_string = date_departure.strftime('%Y-%m-%d')
                
                cursor.execute(queries.GET_BOOKED_PROPERTY_DETAILS,(reservation_id, property_id))
                existing_reservation = cursor.fetchone()
                if existing_reservation:
                    reservation_id = existing_reservation[0]
                    cursor.execute(queries.UPDATE_BOOKED_PROPERTY_DEATILS, (arrival_date,departure_date,persons,booker_name,country,dist_channel,rate_code,comm_chan, market_code,room_type,res_status,travel_reason, booked_on, room_code, arrival_day, departure_day, creation_day, creation_day_obj, const.CONST_PROTEL_CREATED_BY, reservation_id, property_id,))
                    logger.info("Booked property already exist %s", reservation_id)
                else:
                    cursor.execute(
                        queries.INSERT_PROTEL_BOOKED_PROPERTY,
                        (
                            property_id,
                            reservation_id,
                            arrival_date,
                            departure_date,
                            room_type,
                            persons,
                            res_status,
                            booker_name,
                            country,
                            booked_on,
                            dist_channel,
                            rate_code,
                            comm_chan,
                            travel_reason,
                            market_code,
                            arrival_day,
                            departure_day,
                            creation_day,
                            room_code,
                            const.CONST_PROTEL_CREATED_BY,
                        ),
                    )
                    logger.info("Booked property data inserted successfully.")
                db_conn.connection.commit()
 
        for task_id in print_task_ids:
            while True:             
                generate_report_task = requests.get(
                    url=const.CONST_PROTEL_REPORT_TASK_DOWNLOAD.format(task_id),
                    headers=headers,
                )

                if generate_report_task.status_code == const.CONST_STATUS_CODE:
                    generate_report = generate_report_task.json()

                    if (
                        generate_report.get("data")
                        and generate_report["data"].get("result")
                        and "vfspath" in generate_report["data"]["result"]
                    ):
                        filename = os.path.basename(
                            generate_report["data"]["result"]["vfspath"]
                        )
                        filetoken = generate_report["data"]["result"]["token"]
                        url = const.CONST_PROTEL_REPORT_DOWNLOAD_API_URL.format(
                            filetoken=filetoken
                        )
                        
                        file_data = requests.get(
                        url=url, headers=headers
                        )
                                             
                        if file_data.status_code == const.CONST_STATUS_CODE:
                            file_data = file_data.content
                            # parse and download file to store data into database 
                            parse_download_file(logger,error_logger, db_conn, filename, loop_property_id, loop_property_name, file_data)
                        else:
                            file_data = None
                            logger.error("file data is not found")
                        break
                    else:
                        logger.info(f"Generate report task data not found, waiting and retrying: {loop_property_id}")
                elif generate_report_task.status_code == 500:
                    error_logger.info(f"Generate report task API failed status {generate_report_task.status_code} : {loop_property_id}")
                    break
                else:
                    error_logger.error(f"Generate report API failed Re-authenticate {generate_report_task.status_code} : {loop_property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
                        
def parse_meal_plan_details(logger,error_logger, db_conn, headers, start_date, end_date, rates_ids, categories_ids, mealcodes_ids, reservation_states_ids, global_hotel_id, property_id, property_name):
    """
    Parse meal plan details using meal plan filter ids, hotel id and global hotel id 
    
    """  
    cursor = db_conn.connection.cursor()
    headers[const.CONST_PROTEL_GLOBALHOTELID] = global_hotel_id
    headers[const.CONST_PROTEL_HOTELID] = property_id
    
    rates_ids = ",".join(map(str, rates_ids))
    categories_ids = ",".join(map(str, categories_ids))
    mealcodes_ids = ",".join(map(str, mealcodes_ids))
    reservation_states_ids = ",".join(map(str, reservation_states_ids))
    
    # Get the current date
    current_date = datetime.now().date()

    # Calculate the end date by adding 6 days to the current date
    end_date = current_date + timedelta(days=7)

    # Format the end_date as a string in the required format
    formatted_end_date = end_date.strftime('%Y-%m-%d') 
   
    while True:    
        meal_plan_details = requests.get(url=const.CONST_PROTEL_MEAL_PLAN_DETAIL_API_URL.format(rates_ids = rates_ids, mealcodes_ids=mealcodes_ids,categories_ids=categories_ids, reservation_states_ids = reservation_states_ids, start_date= start_date, end_date=formatted_end_date), headers=headers,)
        if meal_plan_details.status_code == const.CONST_STATUS_CODE:
            meal_plan_details = meal_plan_details.json()               
            # Extracting column conditions
            column_conditions = meal_plan_details.get("data", {}).get("columnDefinitions", [])
            # Extracting content data
            content_data = meal_plan_details.get("data", {}).get("content", [])
            # Filter columns based on german_to_english_mapping
            filtered_data = [
                    {
                        const.german_to_english_mapping.get(column["text"].strip(), column["text"].strip()): entry.get(
                            column["dataIndex"], None
                        )
                        for column in column_conditions
                        if column["text"].strip() in const.german_to_english_mapping 
                    }
                    for entry in content_data
                ]
            df = pd.DataFrame(filtered_data)
            if not df.empty:
                df.sort_values(by=const.CONST_DATE.lower(), inplace=True)

                # Optional: Reset the index after sorting
                df.reset_index(drop=True, inplace=True)
                df[const.CONST_PROTEL_PROPERTY_ID]=property_id
                
                # Iterate through each row in the DataFrame
                for _, row in df.iterrows():
                    # Assuming 'column1' is the primary key or unique identifier
                    data = dict(row)
                    data = {key: value if not pd.isna(value) else None for key, value in data.items()}
                    # Call the update_or_create functionion
                    if "halfboard" not in data:
                        data["halfboard"]=None
                    if "breakfast" not in row:
                        data["breakfast"]=None
                        
                    cursor.execute(queries.GET_MEAL_PLAN_EXIST_QUERY, (data[const.CONST_DATE.lower()],data["room"],data[const.CONST_RESERVATION_ID], data[const.CONST_PROTEL_PROPERTY_ID],))
                    existing_record = cursor.fetchone()[0]
                    
                    if existing_record == 0:
                        columns = ', '.join(data.keys())
                        values = ', '.join(['%s' for _ in data.values()])
                        insert_query = queries.INSERT_MEAL_PLAN.format(column_lst=columns, value_lst=values)
                        cursor.execute(insert_query, tuple(data.values()))
                        logger.info(f"Meal plan new row inserted {data[const.CONST_RESERVATION_ID]} : { data[const.CONST_PROTEL_PROPERTY_ID]}")
                    else:
                        cursor.execute(queries.UPDATE_MEAL_PLAN_QUERY, (data['reservation_status'],data["room"],data["persons"],data[const.CONST_BOOKER],data["halfboard"],data["breakfast"],data[const.CONST_DATE.lower()],data[const.CONST_RESERVATION_ID],data[const.CONST_PROTEL_PROPERTY_ID], ))
                        logger.info(f"Meal plan updated row {data[const.CONST_RESERVATION_ID]} : { data[const.CONST_PROTEL_PROPERTY_ID]}")
                db_conn.connection.commit()
              
            else:
                logger.error(f"Meal plan data not found {df.info()} : {property_id}")
            break
        elif meal_plan_details.status_code == 500:
            error_logger.error(f"{const.CONST_MEAL_PLAN_API_FAILED} {meal_plan_details.status_code}: {property_id}")
            break   
        else:
            error_logger.error(f"{const.CONST_MEAL_PLAN_API_FAILED} Re-authenticate {meal_plan_details.status_code} : {property_id}")
            auth_data = protel_authentication(logger)
            if auth_data is not None:
                headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"        