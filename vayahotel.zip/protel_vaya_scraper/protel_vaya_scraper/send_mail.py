import importlib.util
import logging
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from scrapy.utils.project import get_project_settings
from datetime import timedelta, datetime

# Accessing settings
settings = get_project_settings()

# Accessing settings without using strings
common_constant_path = settings.get("COMMON_CONSTANT_PATH")
common_constant_file_name = settings.get("COMMON_CONSTANT_FILE_NAME")


def import_module_from_file(file_name, module_name):
    """
    The function imports a module from a file using the file name and module name.

    :param file_name: The name of the file that you want to import from. This should include the file
    extension (e.g., "myfile.py")
    :param module_name: The name of the module you want to import from the file. This is the name that
    you will use to reference the imported module in your code
    :return: the imported module.
    """
    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    file_path = os.path.join(parent_dir, file_name)
    spec = importlib.util.spec_from_file_location(module_name, file_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


# Importing common_constant module
const = import_module_from_file(common_constant_path, common_constant_file_name)

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


def send_mail(excel_file_paths, pms_mail_subject, pms_mail_body):
    """
    The `send_mail` function sends an email with an attached Excel file using the provided email
    details.

    :param excel_file_paths: The path to the Excel file that you want to attach to the email
    :param email_details: The email_details parameter is a tuple that contains the subject and body of
    the email
    """

    try:
        # Set up the email
        msg = MIMEMultipart()
        msg["Subject"] = pms_mail_subject
        msg["From"] = const.CONST_SENDER_MAIL
        msg["To"] = const.CONST_RECIPIENT_MAIL
        msg["Cc"] = const.CONST_RECIPIENT_CC_MAIL

        # Create the email message body
        email_body = pms_mail_body
        msg.attach(MIMEText(email_body, const.CONST_PLAIN))

        if excel_file_paths:
            # Attach the Excel files
            for excel_file_path in excel_file_paths:
                # Attach the PMS booking data report (assuming it's an Excel file)
                file_name = os.path.basename(excel_file_path)
                with open(excel_file_path, const.CONST_FILE_READ_AND_BINARY_MODE) as file:
                    part = MIMEBase(const.CONST_APPLICATION, const.CONST_OCTET_STREAM)
                    part.set_payload(file.read())
                    encoders.encode_base64(part)
                    part.add_header(
                        const.CONST_DISPLAY_CONTENT,
                        const.CONST_ATTACHMENT,
                        filename=file_name,
                    )
                    msg.attach(part)

        # Connect to the SMTP server
        with smtplib.SMTP(
            const.CONST_SMTP_MAIL_ID, const.CONST_MAIL_PORT_NUMBER
        ) as server:
            server.starttls()

            # Log in to the email account
            server.login(const.CONST_SENDER_MAIL, const.CONST_SENDER_MAIL_PASSWORD)

            # Send the email
            server.send_message(msg)
        logging.info(const.CONST_MAIL_SUCCESFULLY_SENT_MESSAGE)

    except Exception as excep:
        logging.error(f"{const.CONST_MAIL_NOT_SENT_MESSAGE} {excep}")


def send_failure_email(failure_reason, error_description, suggested_action):
    failure_body = const.CONST_LOGIN_EXTRACTION_FAILURE_EMAIL_BODY.format(
        failure_time=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        failure_reason=failure_reason,
        error_description=error_description,
        suggested_action=suggested_action
    )
    send_mail([], "Protel PMS Data Extraction Failure Notification", failure_body)