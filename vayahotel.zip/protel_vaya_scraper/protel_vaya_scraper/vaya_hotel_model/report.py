from reportlab.lib.pagesizes import letter, landscape
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Spacer, Image, PageBreak, Paragraph
from reportlab.lib import colors
import pandas as pd
from reportlab.lib.units import inch
import matplotlib.pyplot as plt
from io import BytesIO
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus.flowables import HRFlowable
from datetime import datetime
import os
import numpy as np


def generate_pdf_report(excel_file_path, output_file_path, report_file_name):
    data = pd.read_excel(excel_file_path)

    kpi_table = data.iloc[:1, :].fillna('')
    department_table= data.iloc[2:, :].fillna('')

    department_table.columns = department_table.iloc[0]
    department_table = department_table.iloc[1:]

    print(department_table.columns[1:])
    date_columns = department_table.columns[1:]

    # Convert date objects to weekday names
    date_objects = [date for date in date_columns if isinstance(date, datetime)]
    weekday_names = [date.strftime('%A') for date in date_objects]
    department_table.replace('', np.nan, inplace=True)
    department_table = department_table.dropna(axis=1, how='all')
    department_table.columns = department_table.columns[:1].tolist() + weekday_names
    
    # Create a PDF document
    pdf_filename = os.path.join(output_file_path, report_file_name)
    doc = SimpleDocTemplate(pdf_filename, pagesize=landscape(letter))

    # Create a list to store flowable elements (tables and graphs)
    elements = []

    style = [
        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),  # Header background color
        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),  # Header text color
        ('ALIGN', (0, 0), (-1, -1), 'CENTER'),  # Center alignment
        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),  # Header font
        ('BOTTOMPADDING', (0, 0), (-1, 0), 2),  # Header padding (reduce padding)
        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),  # Row background color
        ('GRID', (0, 0), (-1, -1), 1, colors.black),  # Grid lines
        ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),  # Row font
        ('FONTSIZE', (0, 0), (-1, -1), 8),  # Font size (reduce font size)
        ('ALIGN', (0, 1), (-1, -1), 'CENTER'),  # Row alignment
        ('BOTTOMPADDING', (0, 1), (-1, -1), 2),  # Row padding (reduce padding)
    ]
    # Add a heading with style
    styles = getSampleStyleSheet()
    heading_style = styles['Title']
    heading_text = "Vaya Hotel Employee Model KPIs and Charts Report"
    heading = Paragraph(heading_text, heading_style)
    elements.append(heading)
    elements.append(Spacer(1, 12))  # Add space after heading

    # Add a separator line
    separator = HRFlowable(width="100%", thickness=1, color=colors.black)
    elements.append(separator)
    elements.append(Spacer(1, 12))  # Add space after separatoror
    # Create Table 1
    kpi_table = pd.DataFrame(kpi_table)

    kpi_table = kpi_table.T.rename(columns={0: "Values"})

    kpi_table = kpi_table.reset_index()
    kpi_table.columns = ["KPI's (weekly averages)", "Values"]
    kpi_table.dropna(subset=["Values"])
    kpi_table = kpi_table.drop(0)
    kpi_table_data = [list(kpi_table.columns)] + kpi_table.values.tolist()
    # Create Table 2
    department_table_data = [list(department_table.columns)] + department_table.values.tolist()
    department_table = Table(department_table_data, colWidths=[2 * inch, 1* inch])
    department_table.setStyle(TableStyle(style))

    # Create a table for Table 1 and the image side by side
    kpi_table = Table(kpi_table_data, colWidths=[2 * inch, 2* inch])
    kpi_table.setStyle(TableStyle(style))
    kpi_table_and_image_data = [[kpi_table,Image('vaya.png', height=140, width=140)]]

    # Create the combined table
    combined_table = Table(kpi_table_and_image_data, colWidths=[5 * inch, 4 * inch])

    # Add the combined table to the PDF document
    elements.append(combined_table)
    elements.append(Spacer(1, 12))  # Add a page break to separate Table 2
    elements.append(department_table)
    elements.append(PageBreak())  # Add a space between charts

    kpi_table_labels = [row[0] for row in kpi_table_data[2:]]
    kpi_table_values = [float(row[1]) if isinstance(row[1], (int, float)) else 0.0 for row in kpi_table_data[2:]]

    plt.figure(figsize=(20, 5))
    plt.subplot(1, 3, 1)
    plt.bar(kpi_table_labels, kpi_table_values, alpha=0.5, color="g")
    bars = plt.bar(kpi_table_labels, kpi_table_values, alpha=0.5, color="g")
    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width() / 4.0, yval, f"{yval:.0f}", va="bottom")
    plt.xlabel('KPI')
    plt.ylabel('Values')
    plt.title('KPIs (Weekly Averages)')
    plt.xticks(rotation=45, ha='right')

    plt.xlabel('KPI')
    plt.ylabel('Values')
    plt.title('KPIs (Weekly Averages)')
    elements.append(Spacer(1, 12))  # Add a page break to separate Table 2

    # Save the chart to a BytesIO buffer
    buffer = BytesIO()
    plt.savefig(buffer, format="png", dpi=80, bbox_inches="tight")
    plt.close()

    # Create an Image element from the buffer and add it to the PDF
    buffer.seek(0)
    chart_image = Image(buffer)
    elements.append(chart_image)

    # Create charts based on time series data and insert them into the PDF
    time_series_data = department_table_data[1:]  # Exclude the header row

    for row in time_series_data:
        department = row[0]
        values = row[1:]

        # Convert time values (e.g., '28:00') to hours for plotting
        values = [(int(val.split(':')[0]) + int(val.split(':')[1]) / 60) for val in values]
        
        # Create a new page for each chart
        elements.append(PageBreak())

        # Create a Line chart
        plt.figure(figsize=(6, 3))
        plt.plot(department_table_data[0][1:], values, marker='o', linestyle='-', color='b', label='Line Chart')

        # Add values as text labels on the plot
        for i, value in enumerate(values):
            x_value = department_table_data[0][1:][i]
            plt.annotate(
                f"{value:.0f}",
                (x_value, values[i]),
                textcoords="offset points",
                xytext=(0, 10),
            )
        plt.xlabel('Date')
        plt.ylabel('Hours')
        plt.title(f'{department} Work Hours (Line Chart)')
        plt.legend()

        # Save the Line chart to a BytesIO buffer
        buffer_line = BytesIO()
        plt.savefig(buffer_line, format="png", dpi=80, bbox_inches="tight")
        plt.close()

        # Create an Image element from the Line chart buffer and add it to the PDF
        buffer.seek(0)
        chart_image_line = Image(buffer_line)
        elements.append(chart_image_line)
        elements.append(Spacer(1, 12))  # Add a space between charts

    # Build the PDF document
    doc.build(elements)

    print(f"Report generated successfully as {report_file_name}")
