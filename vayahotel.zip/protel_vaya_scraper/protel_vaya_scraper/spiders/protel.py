import json
import logging
import os
import requests
import scrapy
import shutil
import time
from .. import common_constant as const
from .. import queries
from protel_vaya_scraper.protel_database_connection import DatabaseConnection
from datetime import datetime, timedelta
from dateutil.parser import parse
from protel_vaya_scraper.pms_excel_parser_insertion.excel_reports_parser import (
    parse_reservation_details,
    parse_meal_plan_details
)
from protel_vaya_scraper.protel_authentication import protel_authentication

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Create a file handler for general logs
handler_info = logging.FileHandler(const.CONST_PROTEL_OUTPUT_LOG)
handler_info.setLevel(logging.INFO)

# Create a log format
formatter = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
handler_info.setFormatter(formatter)

# Add the handler to the logger
logger.addHandler(handler_info)

error_logger = logging.getLogger(__name__ + ".errors")
error_logger.setLevel(logging.ERROR)

handler_error = logging.FileHandler(const.CONST_PROTEL_ERROR_LOG)
handler_error.setLevel(logging.ERROR)

handler_error.setFormatter(formatter)
error_logger.addHandler(handler_error)
import pdb

class ProtelSpider(scrapy.Spider):
    """
    Protel spider class to crawl protel website data through APIs and store into database
    Also parse excel reports downloaded from reports API

    """
    name = const.CONST_PROTEL_SPIDER_NAME
    start_urls = [const.CONST_PROTEL_PMS_API_URL]

    def __init__(self, name=None, **kwargs):
        """
        The function initializes an object with a database connection, occupancy value, and start time.

        :param name: The `name` parameter is used to specify the name of the object being initialized.
        It is an optional parameter and its default value is `None`
        """
        self.db_conn = DatabaseConnection()
        self.cursor = self.db_conn.connection.cursor()
        os.remove(const.CONST_PROTEL_OUTPUT_LOG)
        os.remove(const.CONST_PROTEL_ERROR_LOG)
        auth_data = protel_authentication(logger)
        if auth_data is not None:
            self.headers = {
                const.CONST_AUTHORIZATION: f"Bearer {const.AUTH_TOKEN}",
                const.CONST_VAYA_CONTENT_TYPE: const.CONST_VAYA_APPLICATION_JSON,
            }
                
        current_date = datetime.now()
        start_date = current_date - timedelta(days=const.CONST_PMS_START_DATE)
        start_date_str = start_date.strftime(const.CONST_PROTEL_FORMAT_DATE)
        self.start_date = start_date_str
        self.end_date = current_date.strftime(const.CONST_PROTEL_FORMAT_DATE)
        const.CONST_END_DATE = self.end_date
        super().__init__(name, **kwargs)
        
    def handle_httpstatus(self, failure):
        # Handle HTTP status codes here
        response = failure.value.response
        if response and response.status in [401, 403]:
            # Retry the request if the status code indicates a server error
            error_logger.warning(f"Retrying request {response.url} due to HTTP status {response.status}")
            auth_data = protel_authentication(logger)
            if auth_data is not None:
                self.headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
            
            return scrapy.Request(response.url, headers=self.headers, callback=self.parse_hotel_details, errback=self.handle_httpstatus,  dont_filter = True)


    def start_requests(self): 
        """ Start first scrap request"""
        
        folders_to_delete = [
            const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_FOLDER if const.DOWNLOAD_PARSE_INVOICE else None,
            const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_STATS_FOLDER,
            const.CONST_PROTEL_REPORT_HS_FOLDER,
            const.CONST_PROTEL_REPORT_HSBT_FOLDER,
            const.CONST_PROTEL_REPORT_HSBR_FOLDER,
            const.CONST_PROTEL_MERGED_REPORT_FOLDER,
        ]

        # Filter out the None values if download_parse is False
        folders_to_delete = [folder for folder in folders_to_delete if folder is not None]


        # Delete the specified folders
        for folder in folders_to_delete:
            if os.path.exists(folder):
                try:
                    shutil.rmtree(folder)
                    logger.info(f"Deleted folder: {folder}")
                except Exception as e:
                    logger.error(f"Failed to delete folder {folder}: {str(e)}")
            else:
                logger.info(f"Folder not found: {folder}")

        if os.path.exists(const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER):
            try:
                # Delete the contents of the folder, but not the folder itself
                for filename in os.listdir(
                    const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER
                ):
                    file_path = os.path.join(
                        const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER, filename
                    )
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)

                logger.info(
                    f"Cleared contents of folder: {const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER}"
                )
            except Exception as exp:
                self.logger.error(
                    f"Failed to clear contents of folder {const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER}: {str(exp)}"
                )
        else:
            logger.info(
                f"Folder not found: {const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER}"
            )
            
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.headers, callback=self.parse_hotel_details, errback=self.handle_httpstatus,  dont_filter = True)
            
    def parse_hotel_details(self, response):
        """
        Parse hotel details with there reservation states through APIs

        """
        hotel_data = response.json()                 
        properties_lists = list(    
            map(lambda chain: chain["properties"], hotel_data["chains"])
        )
        all_properties = [
            property for properties in properties_lists for property in properties
        ]

        property_id = None
        global_hotel_id = None
        property_name = None

        for property_item in all_properties:
            self.headers[const.CONST_PROTEL_GLOBALHOTELID] = property_item["id"]
            self.headers[const.CONST_PROTEL_HOTELID] = property_item["externalId"]
            property_id = property_item["externalId"]
            global_hotel_id = property_item["id"]
            property_name = property_item[const.CONST_NAME]
            created_by = const.CONST_PROTEL_CREATED_BY
            
            while True:    
                report_definition_data = requests.get(
                    url=const.CONST_PROTEL_REPORT_DEFINITION_API_URL,
                    headers=self.headers,
                )
                if report_definition_data.status_code == const.CONST_STATUS_CODE:
                    report_definition_details = report_definition_data.json()
                    break
                elif report_definition_data.status_code == 500:
                    error_logger.error(f"{const.CONST_REPORT_DEFINATION_API_FAILED} {report_definition_data.status_code}: {property_id}")
                    break   
                else:
                    error_logger.error(f"{const.CONST_REPORT_DEFINATION_API_FAILED} Re-authenticate {report_definition_data.status_code} : {property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        self.headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
                            
            try:
                self.cursor.execute(
                    queries.INSERT_PROTEL_HOETEL_DETAILS,
                    (property_id, global_hotel_id, property_name, created_by),
                )
                self.db_conn.connection.commit()

            except Exception as excep:
                logger.error(f"Hotel details data already exist: {excep}")
                
                
            while True:    
                meal_plan_filter_ids = requests.get(
                    url=const.CONST_PROTEL_MEAL_PLAN_API_URL,
                    headers=self.headers,
                )
                if meal_plan_filter_ids.status_code == const.CONST_STATUS_CODE:
                    meal_plan_ids = meal_plan_filter_ids.json()
                    if const.CONST_DATA in meal_plan_ids and const.CONST_FILTER_OBJ in meal_plan_ids[const.CONST_DATA]:       
                    # Extracting IDs from filterObjects
                        rates_ids = [
                            rate[const.CONST_ID]
                            for rate in meal_plan_ids[const.CONST_DATA][const.CONST_FILTER_OBJ]['rates']
                        ]
                        categories_ids = [
                            category[const.CONST_ID]
                            for category in meal_plan_ids[const.CONST_DATA][const.CONST_FILTER_OBJ]['categories']
                        ]
                        
                        # Check if 'mealcodes' key exists in the dictionary before attempting to access it
                        mealcodes_ids = [
                            meals[const.CONST_ID]
                            for meals in meal_plan_ids[const.CONST_DATA][const.CONST_FILTER_OBJ].get('mealcodes', [])
                        ]

                        reservationStates_ids = [
                            state[const.CONST_ID]
                            for state in meal_plan_ids[const.CONST_DATA][const.CONST_FILTER_OBJ]['reservationStates']
                            if state['name'] in const.CONST_FILTER_RESERVATION_STATUS
                        ]

                        parse_meal_plan_details(logger, error_logger, self.db_conn, self.headers, self.start_date, self.end_date, rates_ids, categories_ids, mealcodes_ids, reservationStates_ids, global_hotel_id, property_id, property_name )    
                        break
                elif meal_plan_filter_ids.status_code == 500:
                    logger.error(f"{const.CONST_MEAL_PLAN_API_FAILED} {meal_plan_filter_ids.status_code}: {property_id}")
                    break   
                else:
                    logger.error(f"{const.CONST_MEAL_PLAN_API_FAILED} Re-authenticate {meal_plan_filter_ids.status_code} : {property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        self.headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
                        
            while True:  
                reservation_states = requests.get(
                    url=const.CONST_PROTEL_RESERVATION_STATES_API_URL, headers=self.headers
                )
                
                if reservation_states.status_code == const.CONST_STATUS_CODE:
                    data = reservation_states.json()
                    states = [entry[const.CONST_ID] for entry in data[const.CONST_DATA]]
                    payload = {
                        const.CONST_FILTER: {
                            const.CONST_ONLY_WITH_CONFIDENTIAL_RATE: False,
                            const.CONST_DAY_USE: False,
                            const.CONST_RESERVATION_STATE: states,
                        },
                        const.CONST_LIST_TYPE: const.CONST_RESERVATION_BY_CREATTION,
                        const.CONST_VALID_FROM: self.start_date,
                        const.CONST_VALID_TO: self.end_date,
                        const.CONST_LIST_BASE: const.CONST_ELEMENT,
                        const.CONST_PAGING: {const.CONST_SIZE: const.CONST_SIZE_NUMBER, const.CONST_PAGE: const.DEFAULT_VALUE},
                    }

                    request_payload = json.dumps(payload)
                    while True:
                        resveration_period_details = requests.post(
                            url=const.CONST_PROTEL_RESERVATION_PERIOD_API_URL, headers=self.headers, data=request_payload
                        )                
                        if resveration_period_details.status_code == const.CONST_STATUS_CODE:
                            resveration_period_details = resveration_period_details.json()
                            parse_reservation_details(logger, error_logger, self.db_conn, self.headers, self.start_date, self.end_date, resveration_period_details,report_definition_details,global_hotel_id,property_id, property_name)
                            break
                        elif resveration_period_details.status_code == 500:
                            error_logger.error(f"Reservation details API failed {resveration_period_details.status_code}:{property_id}")
                            break
                        else:
                            error_logger.error(f"Reservation details API failed Re-authenticate {resveration_period_details.status_code} : {property_id}")
                            auth_data = protel_authentication(logger)
                            if auth_data is not None:
                                self.headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"
                            
                    break          
                elif reservation_states.status_code == 500:
                    error_logger.error(f"Reservation states API failed {reservation_states.status_code} : {property_id}")
                    break
                else:
                    error_logger.error(f"Reservation states API failed Re-authenticate {reservation_states.status_code}: {property_id}")
                    auth_data = protel_authentication(logger)
                    if auth_data is not None:
                        self.headers[const.CONST_AUTHORIZATION] = f"Bearer {const.AUTH_TOKEN}"