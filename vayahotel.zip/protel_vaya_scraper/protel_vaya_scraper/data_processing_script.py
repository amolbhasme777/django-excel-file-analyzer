import common_constant as const
import logging
import os
import pandas as pd
import queries
from datetime import datetime, timedelta
from protel_database_connection import DatabaseConnection
from send_mail import send_mail
from protel_vaya_scraper.excel_to_google_sheet import create_google_sheet

logging.basicConfig(level=logging.DEBUG)

class DataProcessor:
    def __init__(self):
        try:
            self.db_conn = DatabaseConnection()
        except Exception as connection_error:
            logging.error(
                f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {connection_error}"
            )

    def fetch_data_frame_from_cursor(self, cursor, query):
        """
        The function fetches data from a cursor and returns it as a pandas DataFrame.

        :param cursor: The cursor is an object that allows you to interact with the database. It is used
        to execute SQL queries and fetch data from the database
        :param query: The query parameter is a string that represents the SQL query you want to execute.
        It can be any valid SQL query that retrieves data from a database table
        :return: a pandas DataFrame.
        """

        cursor.execute(query)
        columns = [column[0] for column in cursor.description]
        data = cursor.fetchall()
        return pd.DataFrame(data, columns=columns)

    def generate_excel_file(
        self, data_frame, directory_path, file_prefix, current_timestamp
    ):
        """
        The function generates an Excel file from a DataFrame and saves it to a specified directory with
        a given file prefix and current_timestamp.

        :param data_frame: A pandas DataFrame containing the data to be saved in the Excel file
        :param directory_path: The directory path where the Excel file will be saved
        :param file_prefix: The file_prefix parameter is a string that represents the prefix to be added
        to the generated Excel file's name. It is used to differentiate the file from others and provide
        a meaningful name
        :param current_timestamp: The current_timestamp parameter is a string that represents the current date and time.
        It is used to create a unique name for the Excel file by appending it to the file prefix
        :return: the file path of the generated Excel file.
        """

        if not os.path.exists(directory_path):
            os.makedirs(directory_path)

        excel_file_path = os.path.join(
            directory_path, f"{file_prefix}_{current_timestamp}.xlsx"
        )
        data_frame.to_excel(
            excel_file_path,
            sheet_name=const.CONST_SHEET1,
            index=False,
            engine=const.CONST_READ_EXCEL_ENGINE,
        )
        return excel_file_path

    def fetch_data(self):
        """
        The function fetches data from a database, generates an Excel report, sends it via email, and
        handles any exceptions.
        """
        try:
            cursor = self.db_conn.connection.cursor()
            
            data_frame_room_type_object = self.fetch_data_frame_from_cursor(
                cursor, queries.ROOM_TYPE_WISE_PROTEL_REPORT_QUERY
            )
            generation_query_df = self.fetch_data_frame_from_cursor(
                cursor, queries.GET_DISTINCT_HOTELS_AND_ROOM_TYPES
            )

            # Initialize an empty List to store the appended data
            appended_data = []

            # Get the yersterday date
            yersterday_date = datetime.now() - timedelta(
                days=const.CONST_PMS_START_DATE
            )

            # Format the date as "Month Day, Year"
            yersterday_date_str = yersterday_date.strftime(
                const.EXCEL_RECORD_DATE_FORMAT
            )

            # Iterate over distinct_columns_df and perform required calculations
            for _, row in generation_query_df.iterrows():
                hotel_id = row[const.CONST_HOTEL_ID]
                hotel = row[const.CONST_HOTEL]
                room_type = row[const.CONST_ROOM_TYPE]

                # Check if the current hotel_id and room_type exist in generation_query_df
                filtered_data = data_frame_room_type_object[
                    (data_frame_room_type_object[const.CONST_HOTEL_ID] == hotel_id)
                    & (data_frame_room_type_object[const.CONST_ROOM_TYPE] == room_type)
                ]

                # If no data exists for the current hotel_id and room_type, create a new row with default values
                if filtered_data.empty:
                    new_row = {
                        const.CONST_HOTEL_ID: hotel_id,
                        const.CONST_HOTEL: hotel,
                        const.CONST_DATE: yersterday_date_str,
                        const.CONST_ROOM_TYPE: room_type,
                        const.CONST_BOOKING: const.DEFAULT_VALUE,
                        const.CONST_PMS_LOGIS: const.DEFAULT_VALUE,
                        const.CONST_F_AND_D: const.DEFAULT_VALUE,
                        const.CONST_EXTRAS.capitalize(): const.DEFAULT_VALUE,
                        const.CONST_TOTAL_PRICE: const.DEFAULT_VALUE,
                    }
                    appended_data.append(new_row)
                else:
                    # If data exists, append the filtered data to the appended_data list
                    for _, data_row in filtered_data.iterrows():
                        if data_row.to_dict():
                            appended_data.append(data_row.to_dict())

            # Convert the list of dictionaries to a DataFrame
            appended_data_df = pd.DataFrame(appended_data)

            # Generate timestamps
            timestamp = datetime.now().strftime(const.CONST_PROTEL_EXCEL_DATE_FORMAT)

            # Define directory paths
            directory_path = os.path.join(
                os.getcwd(), const.CONST_PROTEL_MERGED_REPORT_FOLDER
            )

            excel_filter_report_file = self.generate_excel_file(
                appended_data_df,
                directory_path,
                const.CONST_PMS_FILTER_BOOKINGS_BY_ROOM_TYPE,
                timestamp,
            )

            file_paths = [excel_filter_report_file]

            # Assuming you have different subjects and bodies
            pms_mail_subject = const.CONST_PMS_EMAIL_SUBJECT.format(
                date=yersterday_date_str
            )
            pms_mail_body = const.CONST_PMS_EMAIL_BODY.format(
                report_date=yersterday_date_str
            )

            # Sending files via email
            if all(os.path.exists(path) for path in file_paths):
                create_google_sheet(file_paths, logging, pms_mail_body)
                # send_mail(file_paths, pms_mail_subject, pms_mail_body)


            data_frame_object = self.fetch_data_frame_from_cursor(
                cursor, queries.WEEKEND_REPORT_DATA_QUERY
            )

            today_date = datetime.now()
            date_six_days_ago = today_date - timedelta(days=const.CONST_PMS_END_DATE)
            today_date_formatted = today_date.strftime(
                const.CONST_PROTEL_MAIL_DATE_FORMAT
            )
            date_six_days_ago_formatted = date_six_days_ago.strftime(
                const.CONST_PROTEL_MAIL_DATE_FORMAT
            )
            pms_mail_subject = const.CONST_PMS_WEEKLY_EMAIL_SUBJECT.format(
                to_date=today_date_formatted, from_date=date_six_days_ago_formatted
            )

            # Check if the fetched data is empty
            if data_frame_object.empty:
                pms_mail_body = const.CONST_PMS_NO_DATA_FOUND_WEEKLY_EMAIL_BODY.format(
                    to_date=today_date_formatted,
                    from_date=date_six_days_ago_formatted,
                )
                # send_mail(None, pms_mail_subject, pms_mail_body)
            else:
                current_timestamp = datetime.now().strftime(
                    const.CONST_PROTEL_EXCEL_DATE_FORMAT
                )

                directory_path = os.path.join(
                    os.getcwd(), const.CONST_PROTEL_MERGED_REPORT_FOLDER
                )

                excel_report_file = self.generate_excel_file(
                    data_frame_object,
                    directory_path,
                    const.CONST_PMS_WEEKLY_BOOKINGS,
                    current_timestamp,
                )

                file_paths = [excel_report_file]

                pms_mail_body = const.CONST_PMS_WEEKLY_EMAIL_BODY.format(
                    to_date=today_date_formatted,
                    from_date=date_six_days_ago_formatted,
                )

                # Sending files via email
                if all(os.path.exists(path) for path in file_paths):
                    create_google_sheet(file_paths, logging, pms_mail_body)
                    # send_mail(file_paths, pms_mail_subject, pms_mail_body)

            if hasattr(self, const.CONST_CURSOR):
                cursor.close()
            if hasattr(self, const.CONST_CONNECTION):
                self.db_conn.close()

        except Exception as exp:
            logging.error(f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {exp}")


if __name__ == "__main__":
    try:
        data_processor = DataProcessor()
        data_processor.fetch_data()
    except Exception as connection_error:
        logging.error(
            f"{const.CONST_ERROR_WHILE_CONNECTING_TO_MARIADB} {connection_error}"
        )
