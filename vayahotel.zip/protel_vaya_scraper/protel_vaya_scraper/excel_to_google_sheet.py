import gspread
import pandas as pd
import os
from google.oauth2.service_account import Credentials
from . import common_constant as const


def create_google_sheet(excel_file_paths, logger, pms_body):
    """Convert PMS excel report to google sheet ans share with client emails

    Args:
        excel_file_paths : Excel report folder path
        logger :  logger object to generate logs
        pms_body : pms mail message body 
    """
    try:
        credentials = Credentials.from_service_account_file(
            os.path.join(os.getcwd(), const.GOOGLE_API_CREDS),
            scopes=const.GOOGLE_API_SCOPES
        )

        gc = gspread.authorize(credentials)

        if excel_file_paths:
            # Attach the Excel files
            for excel_file_path in excel_file_paths:
                # Attach the PMS booking data report (assuming it's an Excel file)
                file_name = os.path.basename(excel_file_path)
                spreadsheet = gc.create(file_name)
                df = pd.read_excel(excel_file_path)
                
                if 'birthday_1' in df.columns.tolist():
                    df['birthday_1'] = pd.to_datetime(df['birthday_1'], errors='coerce')
                    
                if 'Date' in df.columns.tolist():
                    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
                    
                # Convert specified datetime columns to strings using apply
                datetime_columns = df.select_dtypes(include='datetime64').columns
                df[datetime_columns] = df[datetime_columns].apply(lambda x: x.dt.strftime('%Y-%m-%d'))
                df.replace([float('inf'), float('nan')], None, inplace=True)
                df = df.round(6)

                # Get the first worksheet of the newly created spreadsheet
                worksheet = spreadsheet.get_worksheet(0)

                # Append dataframe data to the worksheetc
                worksheet.update([df.columns.values.tolist()] + df.values.tolist())

                # Share the spreadsheet (replace 'editor@example.com' with the email you want to share with)
                for email in const.EMAIL_LIST:
                    spreadsheet.share(email, perm_type='user', role='writer', email_message=pms_body)
    
                logger.info(f"Spreadsheet created and shared: {spreadsheet.url}")
    except Exception as exp:
        logger.info(f"Unable to create new sheet: {exp}")