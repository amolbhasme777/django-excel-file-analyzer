steps to run python script

#Go to path Vaya_Workforce_Model/

#install resquirements.txt file using following command

pip install -r requirements.txt

#run command 

python main.py

#its run all script and store excel file results into model_results folder

#config.json
config.json file contains excel file names and input file name which are contains into same folder.