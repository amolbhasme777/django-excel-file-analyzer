from vaya_hotel_model.emoployee_model import *
import os
import common_constants as const

import warnings
import logging

# Suppress all warnings

import os
import json

def main():
    with open(os.path.join(os.getcwd(),"config.json"), "r") as config_file:
        config = json.load(config_file)
    
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    # Create a file handler
    handler = logging.FileHandler(config["log_file_name"])
    handler.setLevel(logging.INFO)

    # Create a log format
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    handler.setFormatter(formatter)

    # Add the handler to the logger
    logger.addHandler(handler)
    try:
        file_path = os.path.join(os.getcwd(), config["input_file_name"])
        hotel_df = pd.read_excel(file_path, engine=const.CONST_EXCEL_ENGINE)
        dataframes=extract_tables(hotel_df, logger)
        characteristics=hotel_characteristics_table(dataframes, logger)
        labor_management_dfs = efficiency_labor_management(dataframes, logger)
        peak_demand_df_list = peak_demand(dataframes, characteristics, labor_management_dfs,logger, config)
        intraday_agenda_df_list= intraday_agenda_rounded(dataframes, peak_demand_df_list,logger, config)
        employee_model_final_output(peak_demand_df_list, intraday_agenda_df_list,logger, config)
   
    except Exception as e:
        logger.error(f"Unable to read excel file {str(e)}")

if __name__ == "__main__":
    main()