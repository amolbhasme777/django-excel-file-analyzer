CONST_ARRIVAL_DATE = "arrivaldate"
CONST_OFFER_PER_PERSON = "offer_per_person"
CONST_TITLE = "Residence Saalbach-Logies"
CONST_X_LABEL = "Room Type"
CONST_Y_LABEL = "Price Package"
CONST_MARKER = "o"
CONST_ROTATION = 45
CONST_ROOM_LABEL = "Room Descirption"
CONST_FIVE = 5
CONST_ONE = 1
CONST_NINTY = 90
CONST_ZERO = 0
CONST_TWELVE = 12
CONST_TEN = 10
CONST_LEFT = "left"
CONST_FILE_PATH = "Vaya Properties data.xlsx"
CONST_ROOM_TYPE = "room_type"
CONST_MIN_PRICE = "min_price"
CONST_A = "a"
CONST_OPENPYXL = "openpyxl"
CONST_LABEL = "label"
CONST_PRICE_PACKAGE = "Price Package"
CONST_ROOM_DES = "room_description"
CONST_CREATED_ON = "created_on"
COLUMN_NAME = [
    "arrivaldate",
    "room_type",
    "room_description",
    "max_date",
    "min_price",
]
CONST_SEVEN = 7
CONST_PIVOT_DATA = "pivot_data.csv"
CONST_CMAP = "YlGnBu"
CONST_FMT = ".0f"
CONST_ZERO = 0
CONST_ONE = 1
CONST_TWO = 2
CONST_ZERO_SEVEN = 0.773
CONST_YEAR_THREE = 2023
CONST_NINE = 9
CONST_YEAR_FOUR = 2024
CONST_FOUR = 4
CONST_THIRTY = 30
