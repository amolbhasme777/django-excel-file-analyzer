import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
from database_connection import DatabaseConnection
import queries
import datetime
import numpy as np
import common_constant as const


class DataProcessor:
    def __init__(self):
        self.db_conn = DatabaseConnection()

    def fetch_data_from_db(self):
        data = pd.read_sql_query(queries.GET_ROOM_DATA_SUNWEB, self.db_conn.connection)
        return data

    def group_data(self, data):
        grouped_data = data.groupby(
            [const.CONST_ARRIVAL_DATE, const.CONST_ROOM_TYPE, const.CONST_ROOM_DES]
        )

        group_info = []

        for group_label, group_df in grouped_data:
            max_date = group_df[const.CONST_CREATED_ON].max()
            if not pd.isnull(max_date):
                min_price = min(group_df[const.CONST_MIN_PRICE])
                group_info.append(
                    [
                        group_label[const.CONST_ZERO],
                        group_label[const.CONST_ONE],
                        group_label[const.CONST_TWO],
                        max_date,
                        min_price,
                    ]
                )

        column_names = const.COLUMN_NAME
        grouped_df = pd.DataFrame(group_info, columns=column_names)

        return grouped_df

    def fetch_room_data(self):
        room_data = pd.read_sql_query(queries.GET_ROOM_DATA, self.db_conn.connection)
        return room_data[[const.CONST_ROOM_TYPE, const.CONST_ROOM_DES]]

    def generate_saturday_dates(self, start_date, end_date):
        saturday_dates = []
        current_date = start_date
        while current_date <= end_date:
            if current_date.weekday() == const.CONST_FIVE:
                saturday_dates.append(current_date)
            current_date += datetime.timedelta(days=const.CONST_ONE)
        return saturday_dates

    def process_data(self, data, start_date, end_date):
        start_date = datetime.date(
            const.CONST_YEAR_THREE, const.CONST_NINE, const.CONST_TWO
        )
        end_date = datetime.date(
            const.CONST_YEAR_FOUR, const.CONST_FOUR, const.CONST_THIRTY
        )
        saturday_dates = self.generate_saturday_dates(start_date, end_date)

        all_saturdays_df = pd.DataFrame(
            saturday_dates, columns=[const.CONST_ARRIVAL_DATE]
        )

        merged_data = pd.merge(
            all_saturdays_df, data, on=const.CONST_ARRIVAL_DATE, how=const.CONST_LEFT
        )

        merged_data = merged_data.fillna(const.CONST_ZERO)

        grouped_data = self.group_data(merged_data)

        pivot_data = grouped_data.pivot_table(
            index=const.CONST_ARRIVAL_DATE,
            columns=const.CONST_ROOM_TYPE,
            values=const.CONST_MIN_PRICE,
        )

        pivot_data = pivot_data.fillna(const.CONST_ZERO)
        pivot_data = pivot_data.iloc[:, 1:]
        pivot_data = pivot_data / const.CONST_SEVEN
        pivot_data = round(pivot_data)

        return pivot_data

    def save_data_to_excel(self, pivot_data, room_data, excel_file_path):
        df = pd.DataFrame(room_data)
        pivot_data.to_csv(const.CONST_PIVOT_DATA, index=True)
        df1 = pd.read_csv(const.CONST_PIVOT_DATA)
        blank_column = pd.DataFrame({"": [""] * len(df1)})
        df1["."] = blank_column
        df1[const.CONST_X_LABEL] = df[const.CONST_ROOM_TYPE]
        df1[const.CONST_ROOM_LABEL] = df[const.CONST_ROOM_DES]

        df1.to_csv(const.CONST_PIVOT_DATA, index=True)
        with pd.ExcelWriter(
            excel_file_path, engine=const.CONST_OPENPYXL, mode=const.CONST_A
        ) as writer:
            df1.to_excel(writer, sheet_name=const.CONST_TITLE, index=True)

    def plot_heatmap(self, pivot_data, title, x_label, y_label):
        plt.figure(figsize=(const.CONST_TWELVE, const.CONST_TEN))
        sns.heatmap(
            pivot_data,
            cmap=const.CONST_CMAP,
            annot=True,
            fmt=const.CONST_FMT,
            cbar_kws={const.CONST_LABEL: const.CONST_PRICE_PACKAGE},
        )
        plt.title(title)
        plt.xlabel(x_label)
        plt.ylabel(y_label)
        plt.xticks(rotation=const.CONST_NINTY)
        plt.yticks(rotation=const.CONST_ZERO)
        plt.subplots_adjust(bottom=const.CONST_ZERO_SEVEN)
        plt.tight_layout()
        plt.show()

    def close_db_connection(self):
        self.db_conn.close()


def main():
    try:
        data_processor = DataProcessor()

        data = data_processor.fetch_data_from_db()
        room_data = data_processor.fetch_room_data()

        start_date = datetime.date(
            const.CONST_YEAR_THREE, const.CONST_NINE, const.CONST_TWO
        )
        end_date = datetime.date(
            const.CONST_YEAR_FOUR, const.CONST_FOUR, const.CONST_THIRTY
        )

        pivot_data = data_processor.process_data(data, start_date, end_date)

        existing_excel_file_path = const.CONST_FILE_PATH
        data_processor.save_data_to_excel(
            pivot_data, room_data, existing_excel_file_path
        )

        data_processor.plot_heatmap(
            pivot_data,
            title=const.CONST_TITLE,
            x_label=const.CONST_X_LABEL,
            y_label=const.CONST_Y_LABEL,
        )

    except Exception as e:
        print(f"An error occurred: {str(e)}")

    finally:
        data_processor.close_db_connection()


if __name__ == "__main__":
    main()
