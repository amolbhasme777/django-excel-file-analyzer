GET_ROOM_DATA_SUNWEB = """SELECT 
    arrivaldate, 
    room_type, 
    room_description, 
    price_package AS min_price,
	created_on
FROM 
    offer
WHERE 
    property_id = 68 and meal_code = 'Logies';
    """

GET_ROOM_DATA = """
    SELECT DISTINCT
        room_type, 
        room_description
    FROM 
        offer
    WHERE 
        property_id = 68 and meal_code = 'Logies';
"""
