import logging
import mysql.connector
from mysql.connector import Error
import config


class DatabaseConnection:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        try:
            HOSTNAME = config.HOSTNAME
            USERNAME = config.USERNAME
            PASSWORD = config.PASSWORD
            DATABASE = config.DATABASE
            self.connection = mysql.connector.connect(
                host=HOSTNAME, user=USERNAME, password=PASSWORD, database=DATABASE
            )
        except Error as connection_error:
            logging.error(f"Error while connecting to MySQL: {connection_error}")

    def close(self):
        if self.connection is not None:
            self.connection.close()
