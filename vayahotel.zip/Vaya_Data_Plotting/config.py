HOSTNAME = "35.221.25.10"
USERNAME = "produser"
PASSWORD = "root@123"
DATABASE = "providers"
