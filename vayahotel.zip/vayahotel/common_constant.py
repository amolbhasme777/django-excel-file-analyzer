####################### Vaya Hotel Constant ###########################
import numpy as np

CONST_VAYA_SPIDER_NAME = 'vayahotel'
CONST_VAYA_BASE_URL = 'https://www.vayaresorts.com/'
CONST_VAYA_NAME = 'Vaya'
CONST_VAYA_PROVIDER_URL = 'https://www.vayaresorts.com/'
CONST_VAYA_URL = 'url'
CONST_VAYA_DESCRIPTION = 'Service at the highest level, excellent locations in the premier resorts throughout Austria. Typical VAYA design with the highest quality furnishing and the use of wood, glass and leather characterize the VAYA Resorts.'
CONST_VAYA_CREATED_BY = 'Himanshu'
PROVIDER = 'provider'
CONST_VAYA_DICT_KEY_PROPERTY = 'property'
CONST_VAYA_DATE_FORMAT = '%Y-%m-%d'
CONST_VAYA_ONE = 1
CONST_VAYA_URL_VAYA = 'urlvaya'
CONST_VAYA_MAPPED_PROPERTY_CODE = 'mapped_property_code'
CONST_VAYA_PROPERTY_URL = 'property_url'
CONST_VAYA_API_OFFERS = 'https://hbe-api.kognitiv.com/offers'
CONST_VAYA_CHANNEL_ID = 'ibe'
CONST_VAYA_CURRENCY_CODE = 'EUR'
CONST_VAYA_LANGUAGE = 'en'
CONST_VAYA_IP_ADDRESS = '255.255.255.255'
CONST_VAYA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
CONST_VAYA_PRICE_DISPLAY_MODE = 'stay'
CONST_VAYA_PRICE_CAL_MODE = 'asInPricelist'
CONST_VAYA_SORT_ORDER = 'PriceAsc'
CONST_VAYA_CONTENT_TYPE = 'Content-Type'
CONST_VAYA_APPLICATION_JSON = 'application/json'
CONST_VAYA_METHOD_POST = 'POST'
CONST_VAYA_PROPERTY_CODE = 'property_code'
CONST_VAYA_OCCUPANCY = 2
CONST_VAYA_DURATION = 8
CONST_VAYA_ROOM_OFFERS = 'roomOffers'
CONST_VAYA_PACKAGES_OFFERS = 'packagesOffers'
CONST_VAYA_CODE = 'code'
CONST_VAYA_OCCUPANCY_DICT = {'adults': 2, 'children': []}
CONST_VAYA_RETURN_URL_TEMPLATE = 'https://vaya-fieberbrunn-booking.vayaresorts.com/payment'
CONST_VAYA_METADATA = 'metadata'
CONST_VAYA_TITLE = 'title'
CONST_VAYA_RATES = 'rates'
CONST_VAYA_SHOPPING_CART_PRICE = 'shoppingCartPrice'
CONST_VAYA_EXTRA_INFO = 'extraInfo'
CONST_VAYA_MEAL_PLAN = 'mealPlan'
CONST_VAYA_ROOM_TYPE = 'room_type'
CONST_VAYA_ROOM_DES = 'room_description'
CONST_MEAL_PLAN_CODE = 'meal_plan_code'
CONST_VAYA_TOTALS = 'totals'
CONST_VAYA_USER_TOTALS = 'userTotal'
CONST_VAYA_FILENAME = 'vayahotel.log'
CONST_VAYA_PACKAGE_API = 'https://hbe-api.kognitiv.com/packages'
CONST_VAYA_PROPERTY = 'https://hbe-api.kognitiv.com/channels/ibe/property/'
CONST_VAYA_SHOPPING_CART_URL = '/shopping-cart/offers'
CONST_VAYA_CITY = 'city'
CONST_VAYA_COUNTRY = 'country'
CONST_VAYA_ADDRESS = 'address'
CONST_VAYA_STATE = 'state'
CONST_VAYA_FIVE = 5
CONST_VAYA_SIX = 6
CONST_VAYA_YEAR = 2024
CONST_VAYA_TWENTY_FOUR = 24
CONST_VAYA_CHECK_IN = 'checkin'
CONST_VAYA_CHECK_OUT = 'checkout'
CONST_VAYA_FREE_CANCELLATION_DEADLINE = 'freeCancellationDeadline'
CONST_VAYA_NON_REFUNDABLE = 'nonRefundable'
CONST_VAYA_ON_REQUEST = 'onRequest'
CONST_VAYA_WITHOUT_PAYEMENT = 'withoutPayment'
CONST_VAYA_DETAILS = 'details'
CONST_VAYA_POLICIES = 'policies'
CONST_VAYA_CANCELLATION = 'cancellations'
CONST_VAYA_GUARANTEES = 'guarantees'
CONST_VAYA_TAXES = 'taxes'
CONST_VAYA_PETS = 'pets'

################################# Pipeline ########################################

CONST_PIPELINE_PROVIDER = 'provider'
CONST_PIPELINE_PROVIDER_DESCRIPTION = 'provider_description'
CONST_PIPELINE_PROVIDER_URL = 'provider_url'
CONST_PIPELINE_CREATED_BY = 'Himanshu'
CONST_PIPELINE_MODIFIED_BY = 'Himanshu'
CONST_PIPLEINE_CITY_NL = 'city'
CONST_PIPLEINE_CITY_SLUG = 'city_slug'
CONST_PIPLEINE_REGION_NL = 'region'
CONST_PIPLEINE_REGION_SLUG = 'region_slug'
CONST_PIPLEINE_COUNTRY_NL = 'country'
CONST_PIPLEINE_COUNTRY_SLUG = 'country_slug'
CONST_PIPELINE_PROPERTY_NL = 'property_name'
CONST_PIPELINE_PROPERTY_SLUG = 'property_slug'
CONST_PIPELINE_PROPERTY_URL = 'property_url'
CONST_PIPELINE_PROPERTY_DESCRIPTION = 'property_description'
CONST_PIPELINE_PROPERTY_URL = 'property_url'
CONST_PIPELINE_PORPERTY_ACCOMDATION_TYPE = 'accomodation_type'
CONST_PIPELINE_PROPERTY_ADDRESS = 'address'
CONST_PIPELINE_OFFER_PER_PERSON = 'offer_per_person'
CONST_PIPELINE_PRICE_PACKAGE = 'price_package'
CONST_PIPELINE_OFFER_BRAND = 'offer_brand'
CONST_PIPELINE_PACKAGE = 'package'
CONST_PIPELINE_MEAL_CODE = 'meal_code'
CONST_PIPELINE_MEAL_CODE_LABEL = 'meal_code_label'
CONST_PIPELINE_DURATION = 'duration'
CONST_PIPELINE_OCCUPANCY = 'occupancy'
CONST_PIPELINE_DEPARTURE_DATE = 'departuredate'
CONST_PIPELINE_ARRIVAL_DATE = 'arrivaldate'
CONST_PIPELINE_DEPARTURE_AIRPORT_CODE = 'departure_airport_code'
CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL = 'departure_airport_label'
CONST_PIPELINE_PACKAGE_PROVIDER = 'package_provider'
CONST_PIPELINE_FLIGHTID_INBOUND = 'flightId_inbound'
CONST_PIPELINE_DEPARTURE_DATE_TIME_INBOUND = 'departure_date_time_inbound'
CONST_PIPELINE_DEPARTURE_AIRPORT_CODE_INBOUND = 'departure_airport_code_inbound'
CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL_INBOUND = 'departure_airport_label_inbound'
CONST_PIPELINE_DEPARTURE_AIRPORT_TIMEZONE_INBOUND = 'departure_airport_timezone_inbound'
CONST_PIPELINE_ARRIVAL_DATE_TIME_INBOUND = 'arrival_date_time_inbound'
CONST_PIPELINE_ARRIVAL_AIRPORT_CODE_INBOUND = 'arrival_airport_code_inbound'
CONST_PIPELINE_ARRIVAL_AIRPORT_LABEL_INBOUND = 'arrival_airport_label_inbound'
CONST_PIPELINE_ARRIVAL_AIRPORT_TIMEZONE_INBOUND = 'arrival_airport_timezone_inbound'
CONST_PIPELINE_FLIGHT_CLASS_CODE_INBOUND = 'flight_class_code_inbound'
CONST_PIPELINE_FLIGHT_CLASS_LABEL_INBOUND = 'flight_class_label_inbound'
CONST_PIPELINE_CARRIER_CODE_INBOUND = 'carrier_code_inbound'
CONST_PIPELINE_CARRIER_LABEL_INBOUND = 'carrier_label_inbound'
CONST_PIPELINE_FLIGHT_NUMBER_INBOUND = 'flight_number_inbound'
CONST_PIPELINE_DURATION_MINUTES_INBOUND = 'duration_minutes_inbound'
CONST_PIPELINE_DEPARTURE_DATETIME_OUTBOUND = 'departure_datetime_outbound'
CONST_PIPELINE_DEPARTURE_AIRPORT_CODE_OUTBOUND = 'departure_airport_code_outbound'
CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL_OUTBOUND = 'departure_airport_label_outbound'
CONST_PIPELINE_DEPARTURE_AIRPORT_TIMEZONE_OUTBOUND = 'departure_airport_timezone_outbound'
CONST_PIPELINE_ARRIVAL_DATE_TIME_OUTBOUND = 'arrival_date_time_outbound'
CONST_PIPELINE_ARRIVAL_AIRPORT_CODE_OUTBOUND = 'arrival_airport_code_outbound'
CONST_PIPELINE_ARRIVAL_AIRPORT_LABEL_OUTBOUND = 'arrival_airport_label_outbound'
CONST_PIPELINE_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND = 'arrival_airport_timezone_outbound'
CONST_PIPELINE_FLIGHT_CLASS_CODE_OUTBOUND = 'flight_class_code_outbound'
CONST_PIPELINE_FLIGHT_CLASS_LABEL_OUTBOUND = 'flight_class_label_outbound'
CONST_PIPELINE_CARRIER_CODE_OUTBOUND = 'carrier_code_outbound'
CONST_PIPELINE_CARRIER_LABEL_OUTBOUND = 'carrier_label_outbound'
CONST_PIPELINE_FLIGHT_NUMBER_OUTBOUND = 'flight_number_outbound'
CONST_PIPELINE_DURATION_MINUTES_OUTBOUND = 'duration_minutes_outbound'
CONST_PIPELINE_ROOM_TYPE = 'room_type'
CONST_PIPELINE_ROOM_DESCRIPTION = 'room_description'
CONST_PIPELINE_MAPPED_PROPERTY_CODE = 'mapped_property_code'
CONST_PIPELINE_PROPERTY = 'property'
CONST_PIPELINE_FREE_CANCELLATION_DEADLINE = 'free_cancellation_deadline'
CONST_PIPELINE_NON_REFUNDABLE = 'non_refundable'
CONST_PIPELINE_ON_REQUEST = 'on_request'
CONST_PIPELINE_WITHOUT_PAYEMENT = 'without_payment'
CONST_PIPELINE_CANCELLATION = 'cancellations'
CONST_PIPELINE_GUARANTEES = 'guarantees'
CONST_PIEPLINE_TAXES = 'taxes'
CONST_PIPELINE_PETS = 'pets'
CONST_PIPELINE_PROPERTY_CODE = 'property_code'


#######################  Sunweb Constants #######################
CONST_SUNWEB_NAME = 'sunweb'
CONST_SUNWEB_PROVIDER_NAME = 'sunweb'
CONST_SUNWEB_HOMEPAGE_URL = 'https://www.sunweb.nl'
CONST_SUNWEB_SERACHPAGE_URL = 'https://www.sunweb.nl/vakantie/zoeken?Participants%5B0%5D%5B0%5D=1993-03-20&Participants%5B0%5D%5B1%5D=1993-03-20&ParticipantsDistribution=1%7C2&Country%5B0%5D=12&Duration%5B0%5D=8-11&TransportType=Flight'
CONST_SUNWEB_SERACHPAGE_AUSTRIA_URL = 'https://www.sunweb.nl/vakantie/zoeken?Participants%5B0%5D%5B0%5D=1993-03-20&Participants%5B0%5D%5B1%5D=1993-03-20&ParticipantsDistribution=1%7C2&Country%5B0%5D=2&Duration%5B0%5D=8-11&TransportType=SelfDrive'
CONST_SUNWEB_SERACHPAGE_AUSTRIA_WINTERSPORT_URL = 'https://www.sunweb.nl/wintersport/zoeken?Participants%5B0%5D%5B0%5D=1993-03-20&Participants%5B0%5D%5B1%5D=1993-03-20&Participants%5B0%5D%5B2%5D=1993-03-20&ParticipantsDistribution=1%7C2%7C3&Country%5B0%5D=2&Duration%5B0%5D=8-10&TransportType=SelfDrive'
CONST_SEARCH_API_URL = 'https://api.sunweb.nl/api/sitecore/SearchApi/GetSearchResponse'
CONST_SUUWEB_DES = 'Sunweb Travel Booking Site'
CONST_SUNWEB_CREATED_BY = 'Himanshu'
CONST_SUNWEB_CONTEXTITEMID_XPATH = '//*[@id="acco-live-search-contextItemId"]/@value'
CONST_SUNWEB_LIMIT = '50'
CONST_SUNWEB_PAYLOAD_DURATION = '8-11'
CONST_SUNWEB_PARTICIPANTS  ='1993-03-20'
CONST_SUNWEB_COUNTRY = '2'
CONST_SUNWEB_PARTICIPANTS_DISTRIBUTION =  '1|2'
CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE = 'SelfDrive'
CONST_SUNWEB_TRANSPORT_TYPE_FLIGHT = 'Flight'
CONST_RES_ARRIVAL_AIRPORT_ID = 'arrivalAirportId'
CONST_RES_RAW = 'raw'
CONST_RES_ARRIVAL_DATE = 'arrivalDate'
CONST_RES_DEPT_AIRPORT_ID  = 'departureAirportId'
CONST_SUNWEB_PROPERTY_NAME = 'name'
CONST_SUNWEB_COUNTRY_NAME = 'countryName'
CONST_SUNWEB_REGION_NAME = 'regionName'
CONST_SUNWEB_CITY_NAME = 'cityName'
CONST_SUNWEB_URL = 'url'
CONST_SUNWEB_CALLTOACTION = 'callToAction'
CONST_SUNWEB_PRICE = 'price'
CONST_SUNWEB_INFO = 'acmInformation'
CONST_SUNWEB_MEAL_PLAN_CODE = 'mealplanCode'
CONST_SUNWEB_HOTEL_URL = 'urlsunweb_hotel'
CONST_SUNWEB_APARTMENT_URL = 'urlsunweb_apartment'
CONST_SUNWEB_FILTER_CONTEXTITEMID_XPATH = 'acco-live-search-contextItemId'
CONST_SUNWEB_FILTER_API = 'https://api.sunweb.nl/api/sitecore/SharedFilters/GetFiltersApi'
CONST_SUNWEB_DURATION_PRICE_API = 'https://api.sunweb.nl/api/sitecore/BookingGate/GetPricesGroupedByDurationApi'
CONST_SUNWEB_DURATION_WINTERSPORT_PRICE_API = 'https://api.sunweb.nl/api/sitecore/PriceTable/GetPriceTableApi'
CONST_SUNWEB_ROOM_SELECTOR_API = 'https://api.sunweb.nl/api/sitecore/BookingGate/GetRoomSelectorApi'
CONST_SUNWEB_ARRIVAL_DATE = 'arrivaldate'
CONST_SUNWEB_OFFER_BRAND = 'offer_brand'
CONST_SUNWEB_OFFER_PER_PERSON = 'offer_per_person'
CONST_SUNWEB_PRICE_PACKAGE = 'price_package'
CONST_SUNWEB_PACKAGE = 'package'
CONST_SUNWEB_MEAL_CODE = 'meal_code'
CONST_SUNWEB_MEAL_CODE_LABEL = 'meal_code_label'
CONST_SUNWEB_DURATION = 'duration'
CONST_SUNWEB_OCCUPANCY = 'occupancy'
CONST_SUNWEB_DEPT_DATE = 'departuredate'
CONST_SUNWEB_DEPT_AIRPORT_CODE = 'departure_airport_code'
CONST_SUNWEB_DEPT_AIRPORT_LABEL = 'departure_airport_label'
CONST_SUNWEB_PACKAGE_PROVIDER = 'package_provider'
CONST_SUNWEB_FLIGHT_ID_INBOUND = 'flightId_inbound'
CONST_SUNWEB_DEPT_DATE_TIME_INBOUND = 'departure_date_time_inbound'
CONST_SUNWEB_DEPT_AIRPORT_CODE_INBOUND = 'departure_airport_code_inbound'
CONST_SUNWEB_AIRPORT_LABEL_INBOUND = 'departure_airport_label_inbound'
CONST_SUNWEB_AIRPORT_TIMEZONE_INBOUND = 'departure_airport_timezone_inbound'
CONST_SUNWEB_ARRIVAL_DATE_TIME_INBOUND = 'arrival_date_time_inbound'
CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_INBOUND = 'arrival_airport_label_inbound'
CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_INBOUND = 'arrival_airport_code_inbound'
CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_INBOUND = 'arrival_airport_timezone_inbound'
CONST_SUNWEB_FLIGHT_CLASS_CODE_INBOUND = 'flight_class_code_inbound'
CONST_SUNWEB_FLIGHT_CLASS_LABEL_INBOUND = 'flight_class_label_inbound'
CONST_SUNWEB_CARRIER_CODE_INBOUND = 'carrier_code_inbound'
CONST_SUNWEB_CARRIER_LABEL_INBOUND = 'carrier_label_inbound'
CONST_SUNWEB_FLIGHT_NUMBER_INBOUND = 'flight_number_inbound'
CONST_SUNWEB_DURATIONS_MINUTES_INBOUND = 'duration_minutes_inbound'
CONST_SUNWEB_DEPT_DATE_TIME_OUTBOUND = 'departure_datetime_outbound'
CONST_SUNWEB_DEPT_AIRPORT_CODE_OUTBOUND = 'departure_airport_code_outbound'
CONST_SUNWEB_DEPT_AIRPORT_LABEL_OUTBOUND = 'departure_airport_label_outbound'
CONST_SUNWEB_DEPT_AIRPORT_TIMEZONE_OUTBOUND = 'departure_airport_timezone_outbound'
CONST_SUNWEB_ARRIVALDATE_TIME_OUTBOUND = 'arrival_date_time_outbound'
CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_OUTBOUND = 'arrival_airport_code_outbound'
CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_OUTBOUND = 'arrival_airport_label_outbound'
CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND = 'arrival_airport_timezone_outbound'
CONST_SUNWEB_FLIGHT_CLASS_CODE_OUTBOUND = 'flight_class_code_outbound'
CONST_SUNWEB_FLIGHT_CLASS_LABEL_OUTBOUND = 'flight_class_label_outbound'
CONST_SUNWEB_CARRIER_CODE_OUTBOUND = 'carrier_code_outbound'
CONST_SUNWEB_CARRIER_LABLE_OUTBOUND = 'carrier_label_outbound'
CONST_SUNWEB_FLIGHT_NUMBER_OUTBOUND = 'flight_number_outbound'
CONST_SUNWEB_DURATION_MINUTES_OUTBOUND = 'duration_minutes_outbound'
CONST_SUNWEB_ROOM_TYPE = 'room_type'
CONST_SUNWEB_ROOM_DESCRIPTION = 'room_description'
CONST_SUNWEB_FREE_CANCELLATION_DEADLINE = 'free_cancellation_deadline'
CONST_SUNWEB_NON_REFUNDABLE = 'nonRefundable'
CONST_SUNWEB_ON_REQUEST = 'onRequest'
CONST_SUNWEB_WITHOUT_PAYEMENT = 'withoutPayment'
CONST_SUNWEB_CANCELLATION = 'cancellations'
CONST_SUNWEB_GUARANTEES = 'guarantees'
CONST_SUNWEB_TAXES = 'taxes'
CONST_SUNWEB_PETS = 'pets'
CONST_SUNWEB_PROPERTY = 'property'
CONST_SUNWEB_MAPPED_PROPERTY_CODE = 'mapped_property_code'
CONST_SUNWEB_OFFSET = 'offset'
CONST_SUNWEB_RESULTS = 'results'
CONST_SUNWEB_ID = 'id'
CONST_SUNWEB_AVERAGE_PRICE = 'averagePrice'
CONST_SUNWEB_SLASH = '/'
CONST_SUNWEB_VALUE = 'value'
CONST_SUNWEB_MONTHS = 'months'
CONST_SUNWEB_MEALPLANS = 'mealplans'
CONST_SUNWEB_TEXT = 'text'
CONST_SUNWEB_ACCOMMODATION = 'Accommodation'
CONST_SUNWEB_MONTH = 'month'
CONST_SUNWEB_API_FOR_FINAL_PRICE = 'https://api.sunweb.nl/api/sitecore/SelfdriveSelector/GetSelfdriveSelectorApi'
CONST_SUNWEB_TOTAL_PRICE = 'totalPrice'
CONST_SUNWEB_AVERAGE_PRICE = 'averagePrice'
CONST_SUNWEB_EURO = "€ "
CONST_SUNWEB_COMMA = ","
CONST_SUNWEB_FULL_STOP = "."
CONST_SUNWEB_DURATION_RANGE_VALUE = '8-11'
CONST_SUNWEB_DURATION_VALUE_PAYLOAD = '8,9,10,11'
CONST_SUNWEB_DUARTION_VALUE_FOR_FINAL_PRICE_PAYLOAD = '8'
CONST_SUNWEB_NAME_VARIABLE = 'name'
CONST_SUNWEB_ROOM_ID = 'id'
CONST_SUNWEB_PACKAGES = 'packages'
CONST_SUNWEB_ROOMS = 'rooms'
CONST_SUNWEB_DATA = 'data'
CONST_SUNWEB_DEPATURE_DATE = 'departureDate'
CONST_SUNWEB_PRICES = 'prices'
CONST_SUNWEB_NAME_V2 = 'sunwebv2'
CONST_SUNWEB_FLIGHT_SELECTOR_API = 'https://api.sunweb.nl/api/sitecore/FlightSelector/GetFlightSelectorApi'
CONST_RES_PRICE_DIFF = 'priceDiff'
CONST_SUNWEB_FORMATTED_ONLY_NUMBER = 'formattedOnlyNumber'
CONST_RES_INBOUND_FLIGHT_ID = 'inboundFlightId'
CONST_SUNWEB_PREFIX = 'https://www.sunweb.nl/wintersport'
CONST_SUNWEB_PREFIX1 = 'https://www.sunweb.nl/'

#Protel constants
CONST_PROTEL_LOGIN_URL = "https://app.protel.net/login"
CONST_PROTEL_PMS_API_URL ="https://cloudservices.protel.net/phr-gw/api/properties/pms/login?pmsTypesFilter=PROTELAIR"
CONST_PROTEL_RESERVATION_STATES_API_URL= "https://app.protel.net/app-backend/api/3/system/reservationStates?format=json"
CONST_PROTEL_RESERVATION_PERIOD_API_URL="https://app.protel.net/reservationservice/api/v1/reservations/period"
CONST_PROTEL_ROOM_PLAN_API_URL = "https://app.protel.net/app-backend/api/ng/v1/roomPlan?format=json&start={start}&end={end}"
CONST_PROTEL_REPORT_DEFINITION_API_URL = "https://app.protel.net/app-backend/api/ext/reportdefinitions?node=root"
CONST_PROTEL_PRINT_REPORT_API_URL = "https://app.protel.net/app-backend/api/ext/reports/printReportAsTask/XLSX"
CONST_PROTEL_REPORT_TASK_DOWNLOAD = "https://app.protel.net/app-backend/api/ng/v1/tasks/task/{}"
CONST_PROTEL_REPORT_DOWNLOAD_API_URL = "https://app.protel.net/app-backend/VFSServlet?token={filetoken}"
CONST_PROTEL_ROOMTYPE_API_URL = "https://app.protel.net/app-backend/api/ng/v1/system/roomTypes?type=all&format=json"
CONST_PROTEL_GUEST_PROFILE_API_URL = "https://app.protel.net/app-backend/api/ng/v1/guests/guest/{guest_id}?format=json"

CONST_PROTEL_REPORT_INVOICE_FILTER = ["Halbpension", "Frühstück","Logis"]
CONST_PROTEL_OUTPUT_LOG = "protel.log"
CONST_PROTEL_CREATED_BY = "protel"
CONST_START_DATE = "2023-09-01"
CONST_END_DATE = "2023-09-28"
CONST_USERNAME_FIELD = "usernameUserInput"
CONST_PASSWORD_FIELD = "password"


CONST_PROTEL_REPORT_INVOICE_FOLDER = "protel_report_files\invoice"
CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_FOLDER = "protel_report_files\distributed_channel"
CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_STATS_FOLDER = "protel_report_files\distributed_channel_stats"
CONST_PROTEL_REPORT_HS_FOLDER = "protel_report_files\hotel_status"
CONST_PROTEL_REPORT_HSBT_FOLDER = "protel_report_files\hotel_status_book_type"
CONST_PROTEL_REPORT_HSBR_FOLDER = "protel_report_files\hotel_status_room_type"

#Suffixes
CONST_PROTEL_HSBT_SUFFIX ="HouseStateByBookingType_"
CONST_PROTEL_HS_SUFFIX = "HouseState_"
CONST_PROTEL_HSBR_SUFFIX = "HouseStateSortedByRooms_"
CONST_PROTEL_DC_STATS_SUFFIX = "ReservationCodeAnalysisChannel_"
CONST_PROTEL_DC_SUFFIX = "Channels_"
CONST_PROTEL_INVOICE_JPG_SUFFIX = "JournalItem_"

CONST_AUTHORIZATION= "Authorization"

CONST_PROTEL_GLOBALHOTELID = "globalHotelId"
CONST_PROTEL_HOTELID = "hotelId"
CONST_PROTEL_SPIDER_NAME = "protel"

CONST_PROTEL_PROPERTY_ID = "property_id"
CONST_PROTEL_PROPERTY_NAME = "property_name"
CONST_PROTEL_REPORT_DEFINITION_DETAILS = "report_definition_details"

CONST_PROTEL_INVOICE_SECTION = "Rechnung"
CONST_PROTEL_RESERVATION_SECTION = "Reservierung"
CONST_PROTEL_CHANNELS = "Channels"
CONST_PROTEL_DC_STATS_CHANNEL = "ReservationCodeAnalysisChannel"
CONST_PROTEL_HOUSESTATE = "HouseState"
CONST_PROTEL_INVOICE_REPORT_SECTION = "JournalItem"
CONST_PROTEL_REPORT_DEFINITION_EXTLIST = "reportDefinitionExtList"
CONST_PROTEL_REPORT_DEFINITIONID_ID = "reportDefinitionId"

CONST_PROTEL_FILENAME = "filename"
CONST_PROTEL_DC_SEPERATOR = "Zimmer"
CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER = "parsed_excel_reports"

CONST_PROTEL_INVOICEJPG_PATTERNTODROP = ["Zeitraum:", "Systemdatum:", "Warengruppe:", "Artikel:", "Summe (Artikel):", "Summe (Gruppe):", "Gesamtsumme:",]
CONST_PROTEL_INVOICEJPG_VALUESTODROP = [np.nan, "Benutzer:", "VAYA Fieberbrunn, 6391 Fieberbrunn", "Buchungsd", "Rechnung", "Res.", "Buchungstext", "E-Preis", 
                                "Summe", "Zimmer", "Gast", "Anreise", "Abreise"]
CONST_PROTEL_INVOICEJPG_NEWCOLUMNS = ["booking_date", "invoice_id", "invoice", "reservation_id", "nights", "booking_text", "e_price", "total", 
                                    "misc", "room_id", "room_type", "guest", "arrival", "departure"]

CONST_PROTEL_DC_PATERN_DROP = [
                    "NaN", "Parameter:", "Zeitraum::", "Systemdatum:", "Reservierung",
                ]
CONST_PROTEL_DCS_PATERN_DROP =  [
                "NaN", "Parameter:", "Reportdatum:", "Umsatz", "Status", "SystemID:", "Total", "Systemdatum:", 
            ]
CONST_PROTEL_DCS_NEW_COLUMNS = ["booking_channel", "nights_rooms_day", "guests_day", "total_sales_day", "sales_rooms_day", "logis_day", "logis_rooms_day",
            "nights_rooms_month", "guests_month", "total_sales_month", "sales_rooms_month", "logis_month", "logis_rooms_month",
            "nights_rooms_year", "guests_year", "total_sales_year", "sales_rooms_year", "logis_year", "logis_rooms_year"]

CONST_PROTEL_HS_PATERN_DROP = [
                "NaN", "Auswertungszeitraum:", "Gruppierung", "Type", "Filter", "Umsatz", "OOO Zimmer", "Pseudozimmer", "Status", "Total / Seite", "Total", "Systemdatum:", 
            ]

CONST_PROTEL_HS_NEW_COLUMNS = ["date_", "rooms_free", "rooms_free_percent",
                                "rooms_occ", "rooms_occ_percent",
                                "beds_percentage", "arrival_rooms_count",
                                "arrival_persons_count", "leave_rooms_count",
                                "leave_persons_count","inhouse_beds", "inhouse_persons",
                                "logis", "fandb", "extras", "total", "misc_count", "misc_percent"]

CONST_PROTEL_HSBT_PATERN_DROP = [
                "Datum", "Total", "Druckdatum:", "Auswertungszeitraum:", "Systemdatum:",
            ]
CONST_PROTEL_HSBR_PATERN_DROP = [
                "NaN", "Systemdatum:", "frei", "Total / Seite", "Total", "Ohne" 
            ]

CONST_PROTEL_FILTERED_FILE_SUFFIX = "_filtered.xlsx"
CONST_PROTEL_MERGED_REPORT_FOLDER = "protel_report_files\protel_merged_report"


CONST_NAME ="name"
CONST_DISPLAYGROUP = "displayGroups"
CONST_PARAMETERS = "parameters"
CONST_INPUTCOMPONENTS = "inputComponents"
CONST_OPTIONS = "options"
CONST_OPTION = "option"
CONST_FLTTYPE = "fltType"
CONST_FLTROOM = "fltRoom" 
CONST_FLTSTATEIDS ="fltStateIDs"
CONST_FLITCATEGORY = "fltCategory"
CONST_FLTITEMGROUPIDS ="fltItemGroupIDs"
CONST_FLTITEMIDS = "fltItemIDs"
CONST_TASKID = "taskID"
CONST_BOKERID = "bookerID"
CONST_RESERVATIONID = "reservationID"
CONST_BOOKERNAME = "bookerName"
CONST_ARRIVALDATE = "arrivalDate"
CONST_DEPARTUREDATE = "departureDate"
CONST_GUESTCOUNT = "guestCount"
CONST_RESSTATENAME = "resStateName"
CONST_COUNTRY ="country"
CONST_CHANNEL = "channel"
CONST_RESERVATIONDATE = "reservationCreationDate"
CONST_RATENAME = "rateName"
CONST_HEARREASON = "hearReason"
CONST_COMEREASON = "comeReason"
CONST_MARKETCODE = "marketCode"
CONST_CATEGORYID = "categoryID"
CONST_GUESTID = "guestID"
CONST_GUESTNAMES = "guestNames"
CONST_AGEGROUPADULT = "ageGroup_Adult"

#constant Fields
CONST_BOOKER ="booker"
CONST_ROOM_ID ="room_id" 
CONST_ARRIVAL = "arrival"
CONST_DEPARTURE = "departure"
CONST_ROOM_NIGHTS ="room_nights"
CONST_LOGIS = "logis"
CONST_EXTRAS = "extras"
CONST_FANDB ="fandb"
CONST_TOTAL_PRICE = "total_price"
CONST_DATE_ = "date_"
CONST_NIGHT_ROOMS_DAY ="nights_rooms_day"
CONST_GUESTS_DAY ="guests_day"
CONST_TOTAL_SALES_DAY = "total_sales_day"
CONST_SALES_ROOMS_DAY ="sales_rooms_day" 
CONST_LOGIS_DAY = "logis_day"
CONST_LOGIS_ROOMS_DAY = "logis_rooms_day"
CONST_NIGHTS_ROOMS_MONTH = "nights_rooms_month"
CONST_GUESTS_MONTH = "guests_month"
CONST_TOTAL_SALES_MONTH = "total_sales_month"
CONST_SALES_ROOMS_MONTH = "sales_rooms_month"
CONST_LOGIS_MONTH = "logis_month"
CONST_LOGIS_ROOMS_MONTH = "logis_rooms_month"
CONST_NIGHTS_ROOMS_YEAR = "nights_rooms_year"
CONST_GUESTS_YEAR = "guests_year"
CONST_TOTAL_SALES_YEAR ="total_sales_year"
CONST_SALES_ROOMS_YEAR ="sales_rooms_year"
CONST_LOGIS_YEAR = "logis_year"
CONST_LOGIS_ROOMS_YEAR = "logis_rooms_year"
CONST_ROOMS_FREE ="rooms_free"
CONST_ROOMS_FREE_PERCENTAGE ="rooms_free_percent"
CONST_ROOMS_OCC = "rooms_occ"
CONST_ROOMS_OCC_PERCENTAGE ="rooms_occ_percent"
CONST_BEDS_PERCENTAGE = "beds_percentage"
CONST_ARRIVAL_ROOMS_COUNT = "arrival_rooms_count"
CONST_ARRIVAL_PERSONS_COUNT = "arrival_persons_count"
CONST_LEAVE_ROOMS_COUNT = "leave_rooms_count"	
CONST_LEAVE_PERSONS_COUNT = "leave_persons_count"
CONST_INHOUSE_BEDS = "inhouse_beds"
CONST_INHOUSE_PERSONS ="inhouse_persons"
CONST_TOTAL ="total"
CONST_MISC_COUNT="misc_count"
CONST_MISC_PERCENTAGE = "misc_percent"

CONST_READ_EXCEL_ENGINE = "openpyxl"


#fields
CONST_RESERVATION_ID = "reservation_id"
CONST_BOOKING_CHANNEL = "booking_channel"

CONST_PROTEL_CONTINUE_BUTTON_XPATH = "//input[@type='submit' and @onclick='submitIdentifier()' and @value='Continue']"
CONST_PROTEL_LOGIN_BUTTON_XPATH = "//button[@data-testid='login-page-continue-login-button']"


#PMS Email constants
CONST_SENDER_MAIL = "rotlistngi@gmail.com"
CONST_SENDER_MAIL_PASSWORD = "wuzh qeyw cjnf fabj"
CONST_RECIPIENT_MAIL = "victor.roos@rotrip.nl"
CONST_PMS_EMAIL_SUBJECT = "Protel PMS Booking Data Report"


CONST_PMS_EMAIL_BODY="""
Hi Victor,

Please find attached the Property Management System (PMS) booking data report.


Sincerely,
rotlistngi
Nextgen Invent Corporation
"""

