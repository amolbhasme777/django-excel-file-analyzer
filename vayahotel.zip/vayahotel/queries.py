INSERT_PROVIDER_QUERY = """
            INSERT INTO provider (
            provider,
            provider_description,
            provider_url,
            created_by,
            modified_by
        ) VALUES (
            %s,%s,%s,%s,%s
        )
    """

GET_LOCATION_QUERY = """
        SELECT location_id
        FROM location
        WHERE city_nl = %s AND region_nl = %s AND country_nl = %s
        LIMIT 1
    """

INSERT_LOCATION_QUERY = """
        INSERT INTO location (
            city_en,
            city_nl,
            city_slug,
            region_en,
            region_nl,
            region_slug,
            country_en,
            country_nl,
            country_slug,
            created_by,
            modified_by
        ) VALUES (
            %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s
        )
    """

INSERT_PROPERTY_QUERY = '''
        INSERT INTO property (
            provider_id,
            location_id,
            mapped_property_code,
            property_name_en,
            property_name_nl,
            property_slug,
            property_description,
            property_code,
            property_url,
            accomodation_type,
            address,
            created_by,
            modified_by,
            is_mapped
        )  VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
    '''

INSERT_OFFER_QUERY = '''
        INSERT INTO offer (
            property_id,
            mapped_property_code,
            offer_per_person,
            price_package,
            offer_brand,
            package,
            meal_code,
            meal_code_label,
            duration,
            occupancy,
            arrivaldate,
            free_cancellation_deadline,
            non_refundable,
            on_request,
            without_payment,
            cancellations,
            guarantees,
            taxes,
            pets,
            departure_airport_code,
            departure_airport_label,
            package_provider,
            flightId_inbound,
            departure_date_time_inbound,
            departure_airport_code_inbound,
            departure_airport_label_inbound,
            departure_airport_timezone_inbound,
            arrival_date_time_inbound,
            arrival_airport_code_inbound,
            arrival_airport_label_inbound,
            arrival_airport_timezone_inbound,
            flight_class_code_inbound,
            flight_class_label_inbound,
            carrier_code_inbound,
            carrier_label_inbound,
            flight_number_inbound,
            duration_minutes_inbound,
            departure_datetime_outbound,
            departure_airport_code_outbound,
            departure_airport_label_outbound,
            departure_airport_timezone_outbound,
            arrival_date_time_outbound,
            arrival_airport_code_outbound,
            arrival_airport_label_outbound,
            arrival_airport_timezone_outbound,
            flight_class_code_outbound,
            flight_class_label_outbound,
            carrier_code_outbound,
            carrier_label_outbound,
            flight_number_outbound,
            duration_minutes_outbound,
            room_type,
            room_description,
            is_active,
            modified_by,
            created_by
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s
        )
    '''

INSERT_OFFER_HISTORY_QUERY = '''
        INSERT INTO offer_history (
            property_id,
            mapped_property_code,
            offer_per_person,
            price_package,
            offer_brand,
            package,
            meal_code,
            meal_code_label,
            duration,
            occupancy,
            arrivaldate,
            free_cancellation_deadline,
            non_refundable,
            on_request,
            without_payment,
            cancellations,
            guarantees,
            taxes,
            pets,
            departure_airport_code,
            departure_airport_label,
            package_provider,
            flightId_inbound,
            departure_date_time_inbound,
            departure_airport_code_inbound,
            departure_airport_label_inbound,
            departure_airport_timezone_inbound,
            arrival_date_time_inbound,
            arrival_airport_code_inbound,
            arrival_airport_label_inbound,
            arrival_airport_timezone_inbound,
            flight_class_code_inbound,
            flight_class_label_inbound,
            carrier_code_inbound,
            carrier_label_inbound,
            flight_number_inbound,
            duration_minutes_inbound,
            departure_datetime_outbound,
            departure_airport_code_outbound,
            departure_airport_label_outbound,
            departure_airport_timezone_outbound,
            arrival_date_time_outbound,
            arrival_airport_code_outbound,
            arrival_airport_label_outbound,
            arrival_airport_timezone_outbound,
            flight_class_code_outbound,
            flight_class_label_outbound,
            carrier_code_outbound,
            carrier_label_outbound,
            flight_number_outbound,
            duration_minutes_outbound,
            room_type,
            room_description,
            is_active,
            modified_by,
            created_by
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s
        )
    '''
GET_PROVIDER_QUERY = "SELECT provider_id FROM provider WHERE provider = %s"

GET_PROPERTY_ID_FROM_PROPERTY_URL = "SELECT property_id FROM property WHERE property_url = %s"

GET_PROPERTY_QUERY = """
        SELECT property_id
        FROM property
        WHERE property_name_nl = %s AND property_url = %s
        
    """

GET_VAYA_PROPERTIES_URL = 'SELECT urlvaya, mapped_property_code FROM property_url_global'

GET_SUNWEB_PROPERTIES_URL = 'SELECT urlsunweb_hotel, urlsunweb_apartment, mapped_property_code FROM property_url_global'

INSERT_CRAWLER_QUERY = "INSERT INTO crawler (start_time, end_time, provider_id) VALUES (%s, %s, %s)"

GET_OFFER_ID = '''SELECT offer_id FROM offer
                WHERE property_id = %s
                    AND mapped_property_code = %s
                    AND offer_per_person = %s
                    AND price_package = %s
                    AND occupancy = %s
                    AND room_type = %s
                    AND room_description = %s
                    AND duration = %s
                    AND arrivaldate = %s
                    and (meal_code = %s or meal_code Is Null)
                    and (flightId_inbound = %s or flightId_inbound Is Null)
                    and (departure_date_time_inbound = %s or departure_date_time_inbound Is NUll)
                    and (arrival_date_time_inbound = %s or arrival_date_time_inbound Is Null)
                    and (arrival_date_time_outbound = %s or arrival_date_time_outbound Is Null)
                    and (departure_datetime_outbound = %s or departure_datetime_outbound Is Null);
                    '''
#Protel Queries
INSERT_PROTEL_HOETEL_DETAILS = "INSERT INTO hotel_details (property_id, global_hotel_id, property_name, created_by) VALUES (%s, %s, %s,%s)"
INSERT_PROTEL_BOOKED_PROPERTY = """
        INSERT INTO booked_property (
            property_id,
            reservation_id,
            arrival,
            departure,
            RT,
            persons,
            res_status,
            booker_name,
            country,
            booked_on,
            distribution_channel,
            rate_code,
            comm_chan,
            travel_reason,
            market_code,
            arrival_day,
            departure_day,
            creation_day,
            RC,
            created_by
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s
        )
    """
INSERT_PROTEL_BOOKER_PROFILE = "INSERT INTO booker_profile (booker_id, property_id, reservation_id, booker_name, created_by) VALUES (%s, %s, %s, %s,%s)"
GET_BOOKED_PROPERTY_DETAILS = "SELECT reservation_id FROM booked_property WHERE reservation_id= %s AND res_status= %s "
INSERT_PROTEL_GUESTS_PROFILES= """
        INSERT INTO guests_profile (
            guest_id,
            reservation_id,
            booker_id,
            guests_name,
            name1,
            name2,
            first_name1,
            last_name1,
            birthday_1,
            age_1,
            street1_1,
            city_1,
            zip_1,   
            created_by
        ) VALUES (
            %s, %s, %s, %s, %s, %s, %s, %s, %s,
            %s, %s, %s, %s, %s
        )
    """
INSERT_PROTEL_GUESTS_PROFILES= """
                            INSERT INTO guests_profile (guest_id, property_id, reservation_id, booker_id, guests_name, {column_names}, {first_name_columns}, {last_name_columns}, birthday_1, age_1, leadtime, adults, street1_1, city_1, zip_1, created_by)
                            VALUES (%s, %s, %s, %s, %s, {placeholders}, {first_name_placeholders}, {last_name_placeholders}, %s, %s, %s, %s, %s, %s, %s, %s)
                        """     
GET_PROTEL_DC_DATA = "SELECT COUNT(*) FROM dist_channel WHERE reservation_id = %s"
INSERT_PROTEL_DC_DATA = """
                INSERT INTO dist_channel (property_id, property_name, reservation_id, booking_channel, booker, room_no, arrival, departure, room_nights, logis, extras, fandb, total_price)
                VALUES (%s, %s,  %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """      
INSERT_PROTEL_DC_HISTORY_DATA =   """
                INSERT INTO dist_channel_history (property_id, property_name, reservation_id, booking_channel, booker, room_no, arrival, departure, room_nights, logis, extras, fandb, total_price)
                VALUES (%s, %s,  %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """       
INSERT_PROTEL_DC_STATS_DATA ="""
                INSERT INTO dist_channel_stats (
                    property_id,
                    booking_channel,
                    date_,
                    nights_rooms_day,
                    guests_day, 
                    total_sales_day,
                    sales_rooms_day,
                    logis_day,
                    logis_rooms_day,
                    nights_rooms_month,
                    guests_month,
                    total_sales_month, 
                    sales_rooms_month,
                    logis_month,
                    logis_rooms_month,
                    nights_rooms_year,
                    guests_year,
                    total_sales_year,
                    sales_rooms_year, 
                    logis_year, 
                    logis_rooms_year)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """           
INSERT_PROTEL_DC_STATS_HISTORY_DATA ="""
                INSERT INTO dist_channel_stats_history (
                    property_id,
                    booking_channel,
                    date_,
                    nights_rooms_day,
                    guests_day, 
                    total_sales_day,
                    sales_rooms_day,
                    logis_day,
                    logis_rooms_day,
                    nights_rooms_month,
                    guests_month,
                    total_sales_month, 
                    sales_rooms_month,
                    logis_month,
                    logis_rooms_month,
                    nights_rooms_year,
                    guests_year,
                    total_sales_year,
                    sales_rooms_year, 
                    logis_year, 
                    logis_rooms_year)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
INSERT_PROTEL_HS_DATA = """
                INSERT INTO hotel_status (
                    property_id,
                    date_,	
                    rooms_free,
                    rooms_free_percent,	
                    rooms_occ,	
                    rooms_occ_percent,	
                    beds_percentage,
                    arrival_rooms_count,
                    arrival_persons_count,	
                    leave_rooms_count,	
                    leave_persons_count,
                    inhouse_beds,	
                    inhouse_persons,
                    logies,	
                    fandb,	
                    extras,	
                    total,
                    misc_count,	
                    misc_percent)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
INSERT_PROTEL_HS_HISTORY_DATA =  """
                INSERT INTO hotel_status_history (
                    property_id,
                    date_,	
                    rooms_free,
                    rooms_free_percent,	
                    rooms_occ,	
                    rooms_occ_percent,	
                    beds_percentage,
                    arrival_rooms_count,
                    arrival_persons_count,	
                    leave_rooms_count,	
                    leave_persons_count,
                    inhouse_beds,	
                    inhouse_persons,
                    logies,	
                    fandb,	
                    extras,	
                    total,
                    misc_count,	
                    misc_percent)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """ 
INSERT_PROTEL_HSBT_DATA = """
                INSERT INTO hotel_status_booking_type (
                    property_id,
                    date_,
                    Logis,
                    FandB,
                    Extras,
                    Total,
                    Room,
                    Comp_room,
                    House_use_room,
                    OoR_rooms,
                    Rooms_overall)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """         
CHECK_DUPLICATE_PROTEL_HSBT_DATA="""
            SELECT COUNT(*) FROM hotel_status_booking_type
            WHERE
                property_id = %s
                AND date_ = %s
                AND Logis = %s
                AND FandB = %s
                AND Extras = %s
                AND Total = %s
                AND Room = %s
                AND Comp_room = %s
                AND House_use_room = %s
                AND OoR_rooms = %s
                AND Rooms_overall = %s
        """  
INSERT_PROTEL_HSBT_HISTORY_DATA ="""
                INSERT INTO hotel_status_booking_type_history (
                    property_id,
                    date_,
                    Logis,
                    FandB,
                    Extras,
                    Total,
                    Room,
                    Comp_room,
                    House_use_room,
                    OoR_rooms,
                    Rooms_overall)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
INSERT_PROTEL_HSBR_DATA = """
                INSERT INTO hotel_status_rooms (
                    property_id,
                    room_type,
                    room_available,
                    room_available_percent,
                    room_occ,
                    room_occ_percent,
                    arrival_count,
                    arrival_per,
                    leave_count,
                    leave_per,
                    In_house_count,
                    In_house_percent,
                    logies,
                    fandb,
                    extras,
                    total,
                    misc,
                    misc_percent)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """              
CHECK_DUPLICATE_PROTEL_HSBR_DATA = """
                    SELECT COUNT(*) FROM hotel_status_rooms
                    WHERE
                        property_id = %s
                        AND room_type = %s
                        AND room_available = %s
                        AND room_available_percent = %s
                        AND room_occ = %s
                        AND room_occ_percent = %s
                        AND arrival_count = %s
                        AND arrival_per = %s
                        AND leave_count = %s
                        AND leave_per = %s
                        AND In_house_count = %s
                        AND In_house_percent = %s
                        AND logies = %s
                        AND fandb = %s
                        AND extras = %s
                        AND total = %s
                        AND misc = %s
                        AND misc_percent = %s
                """
INSERT_PROTEL_HSBR_HISTORY_DATA ="""
                INSERT INTO hotel_status_rooms_history (
                    property_id,
                    room_type,
                    room_available,
                    room_available_percent,
                    room_occ,
                    room_occ_percent,
                    arrival_count,
                    arrival_per,
                    leave_count,
                    leave_per,
                    In_house_count,
                    In_house_percent,
                    logies,
                    fandb,
                    extras,
                    total,
                    misc,
                    misc_percent)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """            
INSERT_PROTEL_INVOICE_JPG_DATA =  """
                INSERT INTO invoice_jpg (property_id, booking_date,  invoice_id, invoice, reservation_id, room_nights, booking_text, e_price, total, misc, room_id, room_type, guest, arrival, departure)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """           
INSERT_PROTEL_INVOICE_JPG_HISTORY_DATA = """
                INSERT INTO invoice_jpg_history (property_id, booking_date,  invoice_id, invoice, reservation_id, room_nights, booking_text, e_price, total, misc, room_id, room_type, guest, arrival, departure)
                VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
CHECK_DUPLICATE_PROTEL_INVOICE_JPG_DATA ="""
    SELECT COUNT(*) FROM invoice_jpg
    WHERE
        property_id = %s
        AND booking_date = %s
        AND invoice_id = %s
        AND invoice = %s
        AND reservation_id = %s
        AND room_nights = %s
        AND booking_text = %s
        AND e_price = %s
        AND total = %s
        AND misc = %s
        AND room_id = %s
        AND room_type = %s
        AND guest = %s
        AND arrival = %s
        AND departure = %s
"""        
CHECK_DUPLICATE_PROTEL_DCS_DATA = """
    SELECT COUNT(*) FROM dist_channel_stats
    WHERE
        property_id = %s
        AND booking_channel = %s
        AND date_ = %s
        AND nights_rooms_day = %s
        AND guests_day = %s
        AND total_sales_day = %s
        AND sales_rooms_day = %s
        AND logis_day = %s
        AND logis_rooms_day = %s
        AND nights_rooms_month = %s
        AND guests_month = %s
        AND total_sales_month = %s
        AND sales_rooms_month = %s
        AND logis_month = %s
        AND logis_rooms_month = %s
        AND nights_rooms_year = %s
        AND guests_year = %s
        AND total_sales_year = %s
        AND sales_rooms_year = %s
        AND logis_year = %s
        AND logis_rooms_year = %s
"""
CHECK_DUPLICATE_PROTEL_HS_DATA = """
    SELECT COUNT(*) FROM hotel_status
    WHERE
        property_id = %s
        AND date_ = %s
        AND rooms_free = %s
        AND rooms_free_percent = %s
        AND rooms_occ = %s
        AND rooms_occ_percent = %s
        AND beds_percentage = %s
        AND arrival_rooms_count = %s
        AND arrival_persons_count = %s
        AND leave_rooms_count = %s
        AND leave_persons_count = %s
        AND inhouse_beds = %s
        AND inhouse_persons = %s
        AND logies = %s
        AND fandb = %s
        AND extras = %s
        AND total = %s
        AND misc_count = %s
        AND misc_percent = %s
"""
PROTEL_REPORT_GENERATION_QUERY = """Select hotel_d.property_name as "Hotel",
gp.guests_name as "Guest Name(s)",
book_prop.reservation_id as "Res. No.",
book_prop.arrival as "Arrival",
book_prop.departure as "Departure",
dc.room_nights as "Room Nights",
dc.room_no as "Room",
book_prop.RT as "RT",
book_prop.RC as "RC",
book_prop.persons as "Persons" ,
book_prop.res_status as "Res. status",
book_prop.booker_name as "Booker",
book_prop.country as "Country",
book_prop.booked_on as "Created On",
book_prop.distribution_channel as "Distribution Channel",
book_prop.rate_code as "Rate code",
book_prop.comm_chan as "Comm. Chan.",
book_prop.travel_reason as "Travel reason",
book_prop.market_code as "Market code	",
book_prop.cancelled_on as "Cancelled on",
gp.name1 as "Name1",
gp.name2 as "Name2",
gp.name3 as "Name3",
gp.name4 as "Name4",
gp.name5 as "Name5",
gp.name6 as "Name6",
gp.name7 as "Name7",
gp.name8 as "Name8",
gp.name9 as "Name9",
gp.name10 as "Name10",
gp.name11 as "Name11",
gp.name12 as "Name12",
gp.name13 as "Name13",
gp.name14 as "Name14",
gp.name15 as "Name15",
gp.last_name1	as "Last name1",
gp.first_name1	as "First name1",
gp.last_name2	as "Last name2",
gp.first_name2	as "First name2",
gp.last_name3	as "Last name3",
gp.first_name3 as "First name3",
gp.last_name4	as "Last name4",
gp.first_name4	as "First name4",
gp.last_name5	as "Last name5",
gp.first_name5	as "First name5",
gp.last_name6	as "Last name6",
gp.first_name6	as "First name6",
gp.last_name7	as "Last name7",
gp.first_name7	as "First name7",
gp.last_name8	as "Last name8",
gp.first_name8	as "First name8",
gp.last_name9	as "Last name9",
gp.first_name9	as "First name9",
gp.last_name10	as "Last name10",
gp.first_name10 as "First name10",
gp.last_name11	as "Last name11",
gp.first_name11 as "First name11",
gp.last_name12	as "Last name12",
gp.first_name12 as "First name12",
gp.last_name13	as "Last name13",
gp.first_name13 as "First name13",
gp.last_name14	as "Last name14",
gp.first_name14  as "First name14",
gp.last_name15	as "Last name15",
gp.first_name15 as "First name15",
gp.birthday_1,
gp.birthday_2,
gp.birthday_3,
gp.birthday_4,	
gp.birthday_5,	
gp.birthday_6,	
gp.birthday_7,	
gp.birthday_8,	
gp.birthday_9,	
gp.birthday_10,	
gp.birthday_11,
gp.birthday_12,
gp.birthday_13,
gp.birthday_14,
gp.birthday_15,
gp.street1_1,
gp.zip_1,
gp.city_1,	
gp.street1_2,
gp.zip_2,
gp.city_2,	
gp.street1_3,
gp.zip_3,	
gp.city_3,
gp.street1_4,	
gp.zip_4,
gp.city_4,	
gp.street1_5,	
gp.zip_5,
gp.city_5,	
gp.street1_6,	
gp.zip_6,
gp.city_6,	
gp.street1_7,	
gp.zip_7,
gp.city_7,	
gp.street1_8,	
gp.zip_8,
gp.city_8,	
gp.street1_9,	
gp.zip_9,
gp.city_9,	
gp.street1_10,	
gp.zip_10,
gp.city_10,	
gp.street1_11,
gp.zip_11,
gp.city_11,
gp.street1_12,	
gp.zip_12,
gp.city_12,	
gp.street1_13,	
gp.zip_13,
gp.city_13,
gp.street1_14,	
gp.zip_14,
gp.city_14,	
gp.street1_15,
gp.zip_15,
gp.city_15,
dc.logis as "Logis",
dc.extras as "Extras",
dc.fandb as "F&B",
dc.total_price as "Total Price",
gp.age_1,
gp.age_2,
gp.age_3,
gp.age_4,
gp.age_5,
gp.age_6,
gp.age_7,
gp.age_8,
gp.age_9,
gp.age_10,
gp.age_11,
gp.age_12,
gp.age_13,
gp.age_14,
gp.age_15,
gp.kids,
gp.adolescents,
gp.adults,
gp.leadtime,
book_prop.arrival_day as  "Arrival day",
book_prop.departure_day as "Departure day",
book_prop.creation_day as "Created day"
From booked_property book_prop 
Join hotel_details hotel_d ON book_prop.property_id = hotel_d.property_id
Join dist_channel dc ON book_prop.reservation_id = dc.reservation_id
Join guests_profile gp ON book_prop.reservation_id = gp.reservation_id"""