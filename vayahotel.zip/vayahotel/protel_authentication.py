from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import time
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from webdriver_manager.chrome import ChromeDriverManager
from vayahotel import protel_config as config
from vayahotel import common_constant as const
from selenium.webdriver.chrome.options import Options 

def protel_authentication(logger):
    """
    Protel website aauthentication process using login credentials which returns access token.
    """
    # Initialize the WebDriver (e.g., Chrome)
    chrome_options = Options()
    chrome_options.add_argument("--headless") # Run in headless m
    access_token = None
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)
    # Navigate to the login page
    driver.get(const.CONST_PROTEL_LOGIN_URL)
    time.sleep(1)
    # Fill in the username field and click "Continue"
    username_field = driver.find_element(By.ID, const.CONST_USERNAME_FIELD)
    username_field.send_keys(config.PROTEL_USERNAME)
    driver.find_element(By.XPATH, const.CONST_PROTEL_CONTINUE_BUTTON_XPATH).click()
    # Fill in the password field and click "Continue" to log in
    password_field = driver.find_element(By.ID, const.CONST_PASSWORD_FIELD)
    password_field.send_keys(config.PROTEL_PASSWORD)
    driver.find_element(By.XPATH,const.CONST_PROTEL_LOGIN_BUTTON_XPATH).click()
    # Wait for the dashboard page to load (you may need to adjust the wait time)
    time.sleep(3)
    data=driver.execute_script( \
                "var ls = window.localStorage, items = {}; " \
                "for (var i = 0, k; i < ls.length; ++i) " \
                "  items[k = ls.key(i)] = ls.getItem(k); " \
                "return items; ")

    if "access_token" in data:
        access_token = data["access_token"]
        logger.info("Protel login successfully")
    else:
        logger.error("Protel authentication failed")
    return access_token