import scrapy
import logging
from vayahotel.protel_database_connection import DatabaseConnection
from datetime import datetime, timedelta
from vayahotel import protel_config as config
from vayahotel import common_constant as const
import requests
import json
import os
import time
from vayahotel import queries
from vayahotel.pms_excel_parser_insertion.excel_reports_parser import parse_save_invoice_report, parse_save_dc_report, parse_save_dcs_report, parse_save_hsr_report, parse_save_hs_report, parse_save_hsbt_report
import shutil
from vayahotel.protel_authentication import protel_authentication


logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Create a file handler
handler = logging.FileHandler(const.CONST_PROTEL_OUTPUT_LOG)
handler.setLevel(logging.INFO)

# Create a log format
formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)

# Add the handler to the logger
logger.addHandler(handler)

class ProtelSpider(scrapy.Spider):
    """
    Protel spider class to crawl protel website data through APIs and store into database
    Also parse excel reports downloaded from reports API 
    
    """
    name = const.CONST_PROTEL_SPIDER_NAME
    start_urls = [const.CONST_PROTEL_PMS_API_URL]
    
    def __init__(self, name=None, **kwargs):
        """
        The function initializes an object with a database connection, occupancy value, and start time.
        
        :param name: The `name` parameter is used to specify the name of the object being initialized.
        It is an optional parameter and its default value is `None`
        """
        self.db_conn = DatabaseConnection()
        self.cursor = self.db_conn.connection.cursor()  
        self.auth_token = protel_authentication(logger)
        self.headers =  {
            const.CONST_AUTHORIZATION: f"Bearer {self.auth_token}",
            const.CONST_VAYA_CONTENT_TYPE: const.CONST_VAYA_APPLICATION_JSON
        }
        current_date = datetime.now()
        start_date = current_date - timedelta(days=6)
        start_date_str = start_date.strftime("%Y-%m-%d")
        self.start_date = start_date_str
        self.end_date = current_date.strftime("%Y-%m-%d")
        const.CONST_END_DATE =  self.end_date 
        const.CONST_START_DATE = self.start_date
        super().__init__(name, **kwargs)
        
        
    def start_requests(self):
        
        folders_to_delete = [const.CONST_PROTEL_REPORT_INVOICE_FOLDER, const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_FOLDER, 
                             const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_STATS_FOLDER, const.CONST_PROTEL_REPORT_HS_FOLDER,
                             const.CONST_PROTEL_REPORT_HSBT_FOLDER, const.CONST_PROTEL_REPORT_HSBR_FOLDER, const.CONST_PROTEL_MERGED_REPORT_FOLDER]

        # Delete the specified folders
        for folder in folders_to_delete:
            if os.path.exists(folder):
                try:
                    shutil.rmtree(folder)
                    logger.info(f"Deleted folder: {folder}")
                except Exception as e:
                    logger.error(f"Failed to delete folder {folder}: {str(e)}")
            else:
                logger.info(f"Folder not found: {folder}")

        if os.path.exists(const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER):
            try:
                # Delete the contents of the folder, but not the folder itself
                for filename in os.listdir(const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER):
                    file_path = os.path.join(const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER, filename)
                    if os.path.isfile(file_path):
                        os.unlink(file_path)
                    elif os.path.isdir(file_path):
                        shutil.rmtree(file_path)
                
                self.logger.info(f"Cleared contents of folder: {const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER}")
            except Exception as e:
                self.logger.error(f"Failed to clear contents of folder {const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER}: {str(e)}")
        else:
            self.logger.info(f"Folder not found: {const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER}")
        
        for url in self.start_urls:
            yield scrapy.Request(url, headers=self.headers, callback=self.parse_hotel_details)

    def parse_hotel_details(self, response):
        """
        Parse hotel details with there reservation states through APIs
        
        """
        hotel_data = response.json()
        properties_lists = list(map(lambda chain: chain["properties"], hotel_data["chains"]))
        all_properties = [property for properties in properties_lists for property in properties]
        
        property_id = None
        global_hotel_id = None
        property_name = None

        for property_item in all_properties:

            self.headers[const.CONST_PROTEL_GLOBALHOTELID] = property_item["id"]
            property_id = property_item["externalId"]
            global_hotel_id = property_item["id"]
            property_name =property_item[const.CONST_NAME]
            created_by = const.CONST_PROTEL_CREATED_BY
            try:                  
                self.cursor.execute(queries.INSERT_PROTEL_HOETEL_DETAILS,(property_id,global_hotel_id,property_name,created_by))
                self.db_conn.connection.commit()
                
            except Exception as excep:
                logger.error(f"Hotel details data already exist: {excep}")
           
                
            reservation_states = requests.get(url=const.CONST_PROTEL_RESERVATION_STATES_API_URL, headers=self.headers)
            self.headers[const.CONST_PROTEL_HOTELID] = property_item["externalId"]
     
            
            try:
                report_definition_data = requests.get(url=const.CONST_PROTEL_REPORT_DEFINITION_API_URL, headers=self.headers)
                report_definition_details = {}
                if report_definition_data.status_code == 200:  
                    report_definition_details=report_definition_data.json()
                else:
                    logger.error("Report definition API failed ")
            except Exception as excp:
                logger.error(f"Report definiton API failed: {excp}")
                
            if reservation_states.status_code == 200:  
                data=reservation_states.json()
                states = [entry["id"] for entry in data["data"]]
                payload={
                            "filter":{"onlyWithConfidentialRate":False,
                            "dayUse":False,
                            "reservationStates":states},
                            "listType":"RESERVATION_BY_TIME",
                            "validFrom": self.start_date,
                            "validTo": self.end_date,
                            "listBase":"ELEMENT",
                            "paging":{"size":100,"page":0}
                        }
                
                request_payload = json.dumps(payload)
                            
                yield scrapy.Request(url=const.CONST_PROTEL_RESERVATION_PERIOD_API_URL,
                                    method="POST", headers=self.headers, body=request_payload,
                                    callback=self.parse_reservation_details,
                                    meta={const.CONST_PROTEL_REPORT_DEFINITION_DETAILS: report_definition_details, const.CONST_PROTEL_GLOBALHOTELID:global_hotel_id, const.CONST_PROTEL_HOTELID: property_id, const.CONST_PROTEL_PROPERTY_NAME: property_name}
                                    
                                    )
                        
            else:
                logger.error("Reservations states ids not found") 
                                    
    def parse_reservation_details(self, response):
        """
        Parse reservation details using reservation states and hotel ids 
        Also parse room plan data through API
        
        """
        self.headers[const.CONST_PROTEL_GLOBALHOTELID] = response.meta.get(const.CONST_PROTEL_GLOBALHOTELID)
        self.headers[const.CONST_PROTEL_HOTELID] = response.meta.get(const.CONST_PROTEL_HOTELID)
        loop_property_name = response.meta.get(const.CONST_PROTEL_PROPERTY_NAME)
        loop_property_id = response.meta.get(const.CONST_PROTEL_HOTELID)
      

        resveration_period_details = json.loads(response.text)
        report_definition_details = response.meta.get(const.CONST_PROTEL_REPORT_DEFINITION_DETAILS) 
        
        flt_item_group_ids_options = []
        flt_type_channel_options = []
        flt_room_options = []
        flt_category_hs_options = []
        flt_category_hsbr_options = []
        flt_state_options = []
        flt_category_hsbt_options = []
        dist_channel_list = []
        channel_item_name = None
        channel_report_definition_id = None
        channel_stats_name = None
        channel_stats_report_definition_id = None
        house_sate_name = None
        house_sate_report_definition_id = None
        house_sate_by_room_name = None
        house_sate_by_room_report_definition_id = None
        house_sate_btype_name = None
        house_sate_btype_report_definition_id = None
        property_id = None
        print_task_ids = []    
   
        if "data" in report_definition_details:
            
            rechnung_data = next((item for item in report_definition_details["data"] if item.get("groupName") == const.CONST_PROTEL_INVOICE_SECTION), None)
            
            reservierung_data = next((item for item in report_definition_details["data"] if item.get("groupName") == const.CONST_PROTEL_RESERVATION_SECTION), None)
            
            keywords_to_match= const.CONST_PROTEL_REPORT_INVOICE_FILTER
            flt_item_ids_options = {keywords_to_match[0]:[],keywords_to_match[1]:[],keywords_to_match[2]:[]}
            
            if reservierung_data and const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST in reservierung_data:
        
                channel_items = [item for item in reservierung_data[const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST] if item.get(const.CONST_NAME) == const.CONST_PROTEL_CHANNELS]
                
                channel_item_name = channel_items[0].get(const.CONST_NAME)
                channel_report_definition_id = channel_items[0].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)

                for group in channel_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLTTYPE :
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_type_channel_options.append(option.get("value"))
                                dist_channel_list.append(option.get("label"))
                        
                channel_stats_items = [item for item in reservierung_data[const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST] if item.get(const.CONST_NAME) == const.CONST_PROTEL_DC_STATS_CHANNEL]
                
                channel_stats_name = channel_stats_items[0].get(const.CONST_NAME)
                channel_stats_report_definition_id = channel_stats_items[0].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)
                                
                house_sate_items = [item for item in reservierung_data[const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST] if item.get(const.CONST_NAME) == const.CONST_PROTEL_HOUSESTATE]
                
                house_sate_name = house_sate_items[0].get(const.CONST_NAME)
                house_sate_report_definition_id = house_sate_items[0].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)
                
                for group in house_sate_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLTROOM:
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_room_options.append(option.get("value"))
                
                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLTSTATEIDS :
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_state_options.append(option.get("value"))

                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLITCATEGORY :
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_category_hs_options.append(option.get("value"))
                        
                                
                house_sate_by_room_items = [item for item in reservierung_data[const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST] if item.get(const.CONST_NAME) == "HouseStateSortedByRooms"]
                
                house_sate_by_room_name = house_sate_by_room_items[0].get(const.CONST_NAME)
                house_sate_by_room_report_definition_id = house_sate_by_room_items[0].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)
                
                for group in house_sate_by_room_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLITCATEGORY:
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_category_hsbr_options.append(option.get("value"))
                
            
                                
                house_sate_bookingtype_items = [item for item in reservierung_data[const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST] if item.get(const.CONST_NAME) == "HouseStateByBookingType"]
                
                house_sate_btype_name = house_sate_bookingtype_items[0].get(const.CONST_NAME)
                house_sate_btype_report_definition_id = house_sate_bookingtype_items[0].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)

                for group in house_sate_bookingtype_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLITCATEGORY :
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_category_hsbt_options.append(option.get("value"))
                        
            else:
                logger.error(f"No data found for groupName: {const.CONST_PROTEL_RESERVATION_SECTION}")
    
            
            flt_type_channel_options =','.join(map(str, flt_type_channel_options))
            flt_room_options = ','.join(map(str, flt_room_options))
            flt_category_hs_options = ','.join(map(str, flt_category_hs_options))
            flt_category_hsbr_options = ','.join(map(str, flt_category_hsbr_options))
            flt_state_options =','.join(map(str, flt_state_options))
            flt_category_hsbt_options =','.join(map(str, flt_category_hsbt_options))
                
            journal_item_name = None
            journal_report_definition_id = None
            if rechnung_data and const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST in rechnung_data:
        
                journal_items = [item for item in rechnung_data[const.CONST_PROTEL_REPORT_DEFINITION_EXTLIST] if item.get(const.CONST_NAME) == const.CONST_PROTEL_INVOICE_REPORT_SECTION]
                
                journal_item_name = journal_items[0].get(const.CONST_NAME)
                journal_report_definition_id = journal_items[0].get(const.CONST_PROTEL_REPORT_DEFINITIONID_ID)

                for group in journal_items[0].get(const.CONST_DISPLAYGROUP):
                    for component in group.get(const.CONST_INPUTCOMPONENTS):
                        if component.get(const.CONST_PARAMETERS).get(const.CONST_NAME)== const.CONST_FLTITEMGROUPIDS :
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:
                                flt_item_group_ids_options.append(option.get("value"))
                        
                        elif component.get(const.CONST_PARAMETERS).get(const.CONST_NAME) == const.CONST_FLTITEMIDS:   
                            options = component.get(const.CONST_PARAMETERS).get(const.CONST_OPTIONS).get(const.CONST_OPTION)
                            for option in options:

                                label = option["label"]
                                for word in keywords_to_match:
                                    if word in label.split()[0]:
                                        flt_item_ids_options[word].append(int(option["value"]))
                                        break  # Stop searching for other matches for this word

            else:
                logger.error("No data found for groupName: {const.CONST_PROTEL_INVOICE_SECTION}")   
                  
            flt_item_ids= [flt_item_ids_options[keywords_to_match[0]][0],flt_item_ids_options[keywords_to_match[1]][0], flt_item_ids_options[keywords_to_match[2]][0]]
            flt_item_group_str = ','.join(map(str, flt_item_group_ids_options))
            fltItemGroupIDs_str = ','.join(map(str, flt_item_ids))    
        
            journal_payload= {
                        const.CONST_NAME:journal_item_name,
                        "reportDefinitionId":journal_report_definition_id,
                        "params":"validFrom={start};validTo={end};fltIgnoreFlag=0;fltItemGroupIDs={flt_item_group_ids};fltItemIDs={flt_item_ids_list}".format(start=self.start_date, end=self.end_date, flt_item_group_ids=flt_item_group_str, flt_item_ids_list=fltItemGroupIDs_str)
                        }
            journal_payload=json.dumps(journal_payload)
                   
            print_task_data = requests.post(url=const.CONST_PROTEL_PRINT_REPORT_API_URL, headers=self.headers, data=journal_payload)
            if print_task_data.status_code == 200:  
                print_task_data = print_task_data.json()
                print_task_ids.append(print_task_data["data"][const.CONST_TASKID])

            else:
                logger.error("Invoice report task id not generated properly")
                
            channel_payload= {
                const.CONST_NAME:channel_item_name,
                "reportDefinitionId":channel_report_definition_id,
                "params":"timeMode=0;validFrom={start};validTo={end};fltType={fltYpe}".format(start=self.start_date, end=self.end_date, fltYpe=flt_type_channel_options)
                }
            channel_payload=json.dumps(channel_payload)
            channel_task_data = requests.post(url=const.CONST_PROTEL_PRINT_REPORT_API_URL, headers=self.headers, data=channel_payload)
            if channel_task_data.status_code == 200:  
                channel_task_data = channel_task_data.json()
                print_task_ids.append(channel_task_data["data"][const.CONST_TASKID])
            else:
                logger.error("Channel report task id not generated properly")
        
            channel_stats_payload={
                                    const.CONST_NAME: channel_stats_name,
                                    "reportDefinitionId": channel_stats_report_definition_id,
                                    "params": "validTo={end};state=1;onlyRevenueRelevant=0;fltGross=0".format(end=self.end_date)
                                    }
            channel_stats_payload=json.dumps(channel_stats_payload)    
            channel_stats_task_data = requests.post(url=const.CONST_PROTEL_PRINT_REPORT_API_URL, headers=self.headers, data=channel_stats_payload)
            
            if channel_stats_task_data.status_code == 200:  
                channel_stats_task_data = channel_stats_task_data.json()
                print_task_ids.append(channel_stats_task_data["data"][const.CONST_TASKID])
            else:
                logger.error("Channel statististics report task id not generated properly")
                
            
            house_state_payload = {
                                const.CONST_NAME: house_sate_name,
                                "reportDefinitionId": house_sate_report_definition_id,
                                "params": "validFrom={start};validTo={end};group=none;reportType=0;fltRoom={fltroom_options};fltCategory={filtCategory_options};fltStateIDs={fltstate_ids};fltIgnoreFlag=0;fltBrutto=0;fltOOO=1;fltPseudo=0".format(start=self.start_date, end=self.end_date, fltroom_options= flt_room_options, filtCategory_options= flt_category_hs_options, fltstate_ids=flt_state_options)
                                }
            house_state_payload=json.dumps(house_state_payload) 
            hs_task_data = requests.post(url=const.CONST_PROTEL_PRINT_REPORT_API_URL, headers=self.headers, data=house_state_payload)  
            if hs_task_data.status_code == 200:  
                hs_task_data = hs_task_data.json()
                print_task_ids.append(hs_task_data["data"][const.CONST_TASKID])
            else:
                logger.error("Hotel status report task id not generated properly")
                
            house_state_rooms_payload ={
                                        const.CONST_NAME: house_sate_by_room_name,
                                        "reportDefinitionId": house_sate_by_room_report_definition_id,
                                        "params": "validFrom={start};validTo={end};fltCategory={fltcategory_options};reportMode=0;fltIgnoreFlag=0;fltBrutto=0".format(start = self.start_date, end = self.end_date, fltcategory_options=flt_category_hsbr_options)
                                        }
            
            house_state_rooms_payload=json.dumps(house_state_rooms_payload)
            hsbr_task_data = requests.post(url=const.CONST_PROTEL_PRINT_REPORT_API_URL, headers=self.headers, data=house_state_rooms_payload)
            
            if hsbr_task_data.status_code == 200:  
                hsbr_task_data = hsbr_task_data.json()
                print_task_ids.append(hsbr_task_data["data"][const.CONST_TASKID])
            else:
                logger.error("Hotel status rooms report task id not generated properly")     
                   
            house_state_btype_payload={ 
                                    const.CONST_NAME: house_sate_btype_name, 
                                    "reportDefinitionId": house_sate_btype_report_definition_id, 
                                    "params": "validFrom={start};validTo={end};reportType=0;fltCategory={fltcategory_options};fltIgnoreFlag=0;fltBrutto=0".format(start=self.start_date, end=self.end_date, fltcategory_options=flt_category_hsbt_options)
                                    }                
            house_state_btype_payload=json.dumps(house_state_btype_payload)
            hsbt_task_data = requests.post(url=const.CONST_PROTEL_PRINT_REPORT_API_URL, headers=self.headers, data=house_state_btype_payload)         
            if hsbt_task_data.status_code == 200:  
                hsbt_task_data = hsbt_task_data.json()
                print_task_ids.append(hsbt_task_data["data"][const.CONST_TASKID])
            else:
                logger.error("Hotel status booking type report task id not generated properly")
        else:
            logger.error("No data found for reservation definition details")

        max_retries = 3
        retry_delay = 5
        for task_id in print_task_ids:
            retries = 0
            while retries < max_retries:
                parse_save_hs_report
                generate_report_task = requests.get(url=const.CONST_PROTEL_REPORT_TASK_DOWNLOAD.format(task_id), headers=self.headers)

                if generate_report_task.status_code == 200:
                    generate_report = generate_report_task.json()

                    if generate_report["data"] and generate_report["data"]["result"] is not None:
                        filename = os.path.basename(generate_report["data"]["result"]["vfspath"])
                        filetoken = generate_report["data"]["result"]["token"]
                        url = const.CONST_PROTEL_REPORT_DOWNLOAD_API_URL.format(filetoken=filetoken)

                        yield scrapy.Request(url=url,
                                            headers=self.headers,
                                            callback=self.parse_download_file,
                                            meta={const.CONST_PROTEL_FILENAME: filename,const.CONST_PROTEL_PROPERTY_ID: loop_property_id, const.CONST_PROTEL_PROPERTY_NAME: loop_property_name}
                                            )
                        break  # Exit the loop when the data is available

                    else:
                        logger.info("No result yet, waiting and retrying...")
                else:
                    logger.error("Generate report task id API failed")

                retries += 1
                time.sleep(retry_delay)  # Add a delay between retries

            if retries == max_retries:
                logger.info(f"Data not available for task_id {task_id} after maximum retries.")
       
            
        room_type_data = requests.get(url=const.CONST_PROTEL_ROOMTYPE_API_URL, headers=self.headers) 
        if resveration_period_details and resveration_period_details["response"]["content"] is not None:            
            room_id = None 
            for res_detail in resveration_period_details["response"]["content"]:
                # Booker profile
                booker_id = res_detail[const.CONST_BOKERID]
                reservation_id = res_detail[const.CONST_RESERVATIONID]
                booker_name = res_detail[const.CONST_BOOKERNAME]
                
                #Booked property
                property_id = loop_property_id
                arrival_date = res_detail[const.CONST_ARRIVALDATE]
                departure_date = res_detail[const.CONST_DEPARTUREDATE]
                room_type = None
                persons = res_detail[const.CONST_GUESTCOUNT]
                res_status = res_detail[const.CONST_RESSTATENAME]
                country = res_detail[const.CONST_COUNTRY]
                dist_channel = res_detail[const.CONST_CHANNEL]
                booked_on = res_detail[const.CONST_RESERVATIONDATE]
                rate_code = res_detail[const.CONST_RATENAME]
                comm_chan = res_detail[const.CONST_HEARREASON]
                travel_reason = res_detail[const.CONST_COMEREASON]
                market_code = res_detail[const.CONST_MARKETCODE]
                
                arrival_day_obj = datetime.strptime(arrival_date, "%Y-%m-%dT%H:%M:%S")
                arrival_day = arrival_day_obj.strftime("%A")
                departure_day_obj = datetime.strptime(departure_date, "%Y-%m-%dT%H:%M:%S")
                departure_day = departure_day_obj.strftime("%A")
                creation_day_obj = datetime.strptime(booked_on, "%Y-%m-%dT%H:%M:%S")
                creation_day = creation_day_obj.strftime("%A")
                leadtime = (arrival_day_obj - creation_day_obj).days
                room_code = None
                created_by = const.CONST_PROTEL_CREATED_BY
                room_id = res_detail[const.CONST_CATEGORYID]   
                cancel_on = None  
                               
                #guest profiles
                guest_id = res_detail[const.CONST_GUESTID] 
                guests_name = res_detail[const.CONST_GUESTNAMES]
                adults = res_detail[const.CONST_AGEGROUPADULT]
                
                room_type=None
                room_code=None  
                if room_type_data.status_code == 200:  
                    roomtypes=room_type_data.json()
                    if roomtypes["data"] is not None:
                        matching_dict = None
                        # Iterate through the list of dictionaries
                        for dictionary in roomtypes["data"]:
                            if dictionary.get("id") == room_id:
                                matching_dict = dictionary
                                room_type = matching_dict["value"]["type"] 
                                room_code = matching_dict["value"]["code"]
                    
                else:
                    logger.error("Room type API failed")
                
                try:  
                    self.cursor.execute(queries.INSERT_PROTEL_BOOKER_PROFILE, (booker_id, property_id, reservation_id, booker_name, created_by))
                    self.db_conn.connection.commit()
                except Exception as excp:
                    logger.error("Booker profile already exist %s", excp)
                                    
            
                guest_api_url = const.CONST_PROTEL_GUEST_PROFILE_API_URL.format(guest_id=guest_id)
                
                guest_data = requests.get(url=guest_api_url, headers=self.headers)
                guest_names_list = guests_name.split(",")
                names = []
                for i, name in enumerate(guest_names_list, start=1):
                       names.append(name)
                
                
                if guest_data.status_code == 200:  
                    guest_data=guest_data.json()
                    if guest_data is not None and "data" in guest_data:
                        birthday = guest_data["data"]["birthday"]
                        age = guest_data["data"]["age"]
                        
                        street = None
                        zip = None
                        city = None
                        if len(guest_data["data"]["addresses"]) > 0:
                            street = guest_data["data"]["addresses"][0]["street1"]
                            zip = guest_data["data"]["addresses"][0]["zip"]
                            city = guest_data["data"]["addresses"][0]["city"]
                    
                        placeholders = ", ".join(["%s"] * len(names))
                        column_names = ", ".join([f"name{i+1}" for i in range(len(names))])
                        split_names = [name.split() for name in names]
                        first_names = [split[0] if split else "" for split in split_names]
                        last_names = [" ".join(split[1:]) if len(split) > 1 else "" for split in split_names]

                        # Create placeholders for first names and last names based on the number of names
                        first_name_placeholders = ", ".join(["%s"] * len(first_names))
                        last_name_placeholders = ", ".join(["%s"] * len(last_names))

                        # Create column names for first names and last names
                        first_name_columns = ", ".join([f"first_name{i+1}" for i in range(len(first_names))])
                        last_name_columns = ", ".join([f"last_name{i+1}" for i in range(len(last_names))])

                        try:    
                            guest_profile_query=queries.INSERT_PROTEL_GUESTS_PROFILES.format(column_names=column_names,first_name_columns=first_name_columns, last_name_columns=last_name_columns, placeholders=placeholders,first_name_placeholders=first_name_placeholders,last_name_placeholders=last_name_placeholders)
                    
                            self.cursor.execute(guest_profile_query, (guest_id, property_id, reservation_id, booker_id, guests_name, *names, *first_names, *last_names, birthday, age, leadtime, adults, street, city, zip, const.CONST_PROTEL_CREATED_BY))
                            self.db_conn.connection.commit() 
                        except Exception as excep:
                            logger.error("Guest profile already exist %s",excep)
                else:
                    logger.error("Guest profile API failed")
                    
                    
                
                self.cursor.execute(
                    queries.GET_BOOKED_PROPERTY_DETAILS,
                    (
                        reservation_id,
                        res_status
                    ),
                )
                existing_reservation = self.cursor.fetchone()
                if existing_reservation:
                    reservation_id = existing_reservation[0]
                    return reservation_id
                else:    
                    try:  
                        self.cursor.execute(queries.INSERT_PROTEL_BOOKED_PROPERTY, (property_id, reservation_id, arrival_date, departure_date, room_type, persons, res_status, booker_name, country,
                                                                                    booked_on, dist_channel, rate_code,comm_chan,travel_reason,market_code,arrival_day,departure_day,creation_day,
                                                                                    room_code, const.CONST_PROTEL_CREATED_BY))
                        self.db_conn.connection.commit()
                    except Exception as exc:
                        logger.error("Booked property already exist %s", exc)
                        
        
            
    def parse_download_file(self,response):
        """
        Download reports and dump into folder.
        Report parsed and store data into database using parse methods

        Args:
            response (_type_): _description_
        """
        filename = response.meta.get(const.CONST_PROTEL_FILENAME)
        property_id = response.meta.get(const.CONST_PROTEL_PROPERTY_ID)
        property_name = response.meta.get(const.CONST_PROTEL_PROPERTY_NAME)
        file_data = response.body

        if filename.startswith(const.CONST_PROTEL_DC_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(f"File '{filename}' downloaded and saved")
   
            parse_save_dc_report(local_path, filename, const.CONST_PROTEL_DC_SEPERATOR, property_id, property_name, self.db_conn, logger)
        
        if filename.startswith(const.CONST_PROTEL_INVOICE_JPG_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_INVOICE_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(f"File '{filename}' downloaded and saved")
            
            parse_save_invoice_report(local_path, filename, property_id, self.db_conn, logger)

        elif filename.startswith(const.CONST_PROTEL_DC_STATS_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_DISTRITUBTED_CHANNEL_STATS_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(f"File '{filename}' downloaded and saved")
            parse_save_dcs_report(local_path, filename, property_id, self.db_conn, logger)
        
        elif filename.startswith(const.CONST_PROTEL_HS_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_HS_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(f"File '{filename}' downloaded and saved")
            parse_save_hs_report(local_path, filename, property_id, self.db_conn, logger)
            
        elif filename.startswith(const.CONST_PROTEL_HSBT_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_HSBT_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(f"File '{filename}' downloaded and saved")
            parse_save_hsbt_report(local_path, filename, property_id, self.db_conn, logger)
            
        elif filename.startswith(const.CONST_PROTEL_HSBR_SUFFIX):
            local_path = os.path.join(os.getcwd(), const.CONST_PROTEL_REPORT_HSBR_FOLDER)
            if not os.path.exists(local_path):
                os.makedirs(local_path)
            with open(os.path.join(local_path, filename), "wb") as file:
                file.write(file_data)

            logger.info(f"File '{filename}' downloaded and saved")
            parse_save_hsr_report(local_path, filename, property_id, self.db_conn, logger)