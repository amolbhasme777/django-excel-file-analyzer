import json
import logging
import pandas as pd
from datetime import datetime, timedelta
import requests
from bs4 import BeautifulSoup

import scrapy
import vayahotel.common_constant as const
from vayahotel.items import PropertyItem, OfferItem, ProviderItem
from vayahotel import queries
from vayahotel.utils import all_saturday_dates
from vayahotel.database_connection import DatabaseConnection

import logging
import requests
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

logging.basicConfig(filename='sunweb.log', level=logging.INFO,
                    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', force=True)


class SunwebSpider(scrapy.Spider):
    name = const.CONST_SUNWEB_NAME
    search_api_url = const.CONST_SEARCH_API_URL

    def __init__(self, name=None, **kwargs):
        """
        The function initializes an object with a database connection and start time.
        
        :param name: The `name` parameter is used to specify the name of the object being initialized.
        It is an optional parameter and its default value is `None`
        """
        self.db_conn = DatabaseConnection()
        self.start_time = datetime.now()
        super().__init__(name, **kwargs)

    def start_requests(self):
        """
        The function "start_requests" sends requests to two different URLs and calls the "parse" function
        for each response.
        """

        start_urls = [const.CONST_SUNWEB_SERACHPAGE_AUSTRIA_URL, const.CONST_SUNWEB_SERACHPAGE_AUSTRIA_WINTERSPORT_URL]
        for url in start_urls:
            yield scrapy.Request(url=url, callback=self.parse, meta={'url':url})

    def get_urls(self):
        """
        The function `get_urls` retrieves data from a database table and returns it as a pandas
        DataFrame.
        :return: a DataFrame object called "url_data" which contains the results of a database query.
        """
        try:
            self.cur = self.db_conn.connection.cursor()
            self.cur.execute(queries.GET_SUNWEB_PROPERTIES_URL)
            results = self.cur.fetchall()
            columns = [desc[0] for desc in self.cur.description]
            url_data = pd.DataFrame(results, columns=columns)
            return url_data
        except Exception as get_urls_error:
            logging.error(f"An error occurred: {get_urls_error}")
        finally:
            self.cur.close()

    def parse(self, response):
        """
        The function parses a response and yields a ProviderItem, then extracts data from the response
        and sends a FormRequest with the extracted data.
        
        :param response: The `response` parameter is the HTTP response object returned by the website
        after making a request. It contains the HTML content of the webpage that you want to parse
        """
        url = response.meta.get('url')
        try:
            yield ProviderItem(
                provider=const.CONST_SUNWEB_PROVIDER_NAME,
                provider_description=const.CONST_SUUWEB_DES,
                provider_url=const.CONST_SUNWEB_HOMEPAGE_URL,
                created_by=const.CONST_SUNWEB_CREATED_BY)

            context_item_id = response.xpath(
                const.CONST_SUNWEB_CONTEXTITEMID_XPATH)
            self.contextitemid = context_item_id.get()

            offset = 0
            payload = {
                'contextitemid': self.contextitemid,
                'isFirstUserRequest': 'True',
                'limit': const.CONST_SUNWEB_LIMIT,
                'offset': str(offset),
                'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
                'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,
                'ParticipantsDistribution': const.CONST_SUNWEB_PARTICIPANTS_DISTRIBUTION,
                'Country[0]': const.CONST_SUNWEB_COUNTRY,
                'Duration[0]': const.CONST_SUNWEB_PAYLOAD_DURATION,
                'TransportType': const.CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE,
                'isFirstLoad': 'false'}

            yield scrapy.FormRequest(
                url=self.search_api_url,
                formdata=payload,
                callback=self.parse_api_response,
                meta={const.CONST_SUNWEB_OFFSET: offset, 'url':url}
            )
        except Exception as parse_error:
            # Handle exceptions here
            logging.error(f"An error occurred: {parse_error}")

    def parse_api_response(self, response):
        """
        The function `parse_api_response` is used to parse the response from an API and extract relevant
        data, including property information and offers, and then make subsequent requests if there are
        more results.
        
        :param response: The `response` parameter is the API response that is received from the server.
        It contains the data that needs to be parsed and processed
        """
        more_results = True

        offset = response.meta.get(const.CONST_SUNWEB_OFFSET)
        property_response = json.loads(response.text)
        for data in property_response[const.CONST_SUNWEB_RESULTS]:
            start_url = response.meta.get('url')
            print(start_url)
            accoid = data.get(const.CONST_SUNWEB_ID)
            base_price = data.get(const.CONST_SUNWEB_PRICE).get(const.CONST_SUNWEB_AVERAGE_PRICE)
            property_name = data.get(const.CONST_SUNWEB_PROPERTY_NAME)
            property_description = None
            accomodation_type = None
            country = data.get(const.CONST_SUNWEB_COUNTRY_NAME)
            region = data.get(const.CONST_SUNWEB_REGION_NAME)
            city = data.get(const.CONST_SUNWEB_CITY_NAME)
            slug = data.get(const.CONST_SUNWEB_URL)
            mealcode = data.get(
                const.CONST_SUNWEB_PRICE).get(
                const.CONST_SUNWEB_INFO).get(
                const.CONST_SUNWEB_MEAL_PLAN_CODE)
            country_slug = slug.split('/')[2]
            region_slug = slug.split(const.CONST_SUNWEB_SLASH)[3]
            city_slug = slug.split(const.CONST_SUNWEB_SLASH)[4]
            product_slug = slug.split(const.CONST_SUNWEB_SLASH)[5]

            property_url = const.CONST_SUNWEB_HOMEPAGE_URL + slug

            address = None
            url = data.get(const.CONST_SUNWEB_CALLTOACTION).get(const.CONST_SUNWEB_URL)

            urls = self.get_urls()
            properties_data = urls[[const.CONST_SUNWEB_HOTEL_URL, const.CONST_SUNWEB_APARTMENT_URL,
                                    const.CONST_SUNWEB_MAPPED_PROPERTY_CODE]]

            for _, row in properties_data.iterrows():

                hotel_url = row[const.CONST_SUNWEB_HOTEL_URL]
                apartment_url = row[const.CONST_SUNWEB_APARTMENT_URL]
                mapped_property_code = row[const.CONST_SUNWEB_MAPPED_PROPERTY_CODE]
                if property_url == hotel_url or property_url == apartment_url:

                    yield PropertyItem(
                        provider=const.CONST_SUNWEB_PROVIDER_NAME,
                        property_name=property_name,
                        property_slug=product_slug,
                        property_description=property_description,
                        mapped_property_code=mapped_property_code,
                        property_url=property_url,
                        accomodation_type=accomodation_type,
                        property_code=accoid,
                        country=country,
                        country_slug=country_slug,
                        region=region,
                        region_slug=region_slug,
                        city=city,
                        city_slug=city_slug,
                        address=address)

                    list_of_offers = self.parse_property_page(property_url, accoid, mealcode, base_price,
                                                              mapped_property_code, start_url)
                    if list_of_offers:
                        for offer in list_of_offers:
                            offer_item = OfferItem()
                            offer_item[const.CONST_SUNWEB_PROPERTY] = offer[const.CONST_SUNWEB_PROPERTY]
                            offer_item[const.CONST_SUNWEB_MAPPED_PROPERTY_CODE] = offer[
                                const.CONST_SUNWEB_MAPPED_PROPERTY_CODE]
                            offer_item[const.CONST_SUNWEB_OFFER_PER_PERSON] = offer[const.CONST_SUNWEB_OFFER_PER_PERSON]
                            offer_item[const.CONST_SUNWEB_PRICE_PACKAGE] = offer[const.CONST_SUNWEB_PRICE_PACKAGE]
                            offer_item[const.CONST_SUNWEB_OFFER_BRAND] = offer[const.CONST_SUNWEB_OFFER_BRAND]
                            offer_item[const.CONST_SUNWEB_PACKAGE] = offer[const.CONST_SUNWEB_PACKAGE]
                            offer_item[const.CONST_SUNWEB_MEAL_CODE] = offer[const.CONST_SUNWEB_MEAL_CODE]
                            offer_item[const.CONST_SUNWEB_MEAL_CODE_LABEL] = offer[const.CONST_SUNWEB_MEAL_CODE_LABEL]
                            offer_item[const.CONST_SUNWEB_DURATION] = offer[const.CONST_SUNWEB_DURATION]
                            offer_item[const.CONST_SUNWEB_OCCUPANCY] = offer[const.CONST_SUNWEB_OCCUPANCY]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_DATE] = offer[const.CONST_SUNWEB_ARRIVAL_DATE]
                            offer_item[const.CONST_PIPELINE_FREE_CANCELLATION_DEADLINE] = offer[
                                const.CONST_PIPELINE_FREE_CANCELLATION_DEADLINE]
                            offer_item[const.CONST_PIPELINE_NON_REFUNDABLE] = offer[const.CONST_PIPELINE_NON_REFUNDABLE]
                            offer_item[const.CONST_PIPELINE_ON_REQUEST] = offer[const.CONST_PIPELINE_ON_REQUEST]
                            offer_item[const.CONST_PIPELINE_WITHOUT_PAYEMENT] = offer[
                                const.CONST_PIPELINE_WITHOUT_PAYEMENT]
                            offer_item[const.CONST_PIPELINE_CANCELLATION] = offer[const.CONST_PIPELINE_CANCELLATION]
                            offer_item[const.CONST_PIPELINE_GUARANTEES] = offer[const.CONST_PIPELINE_GUARANTEES]
                            offer_item[const.CONST_PIEPLINE_TAXES] = offer[const.CONST_PIEPLINE_TAXES]
                            offer_item[const.CONST_PIPELINE_PETS] = offer[const.CONST_PIPELINE_PETS]
                            offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_INBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_INBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE] = offer[
                                const.CONST_SUNWEB_DEPT_AIRPORT_CODE]
                            offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_LABEL] = offer[
                                const.CONST_SUNWEB_DEPT_AIRPORT_LABEL]
                            offer_item[const.CONST_SUNWEB_PACKAGE_PROVIDER] = offer[const.CONST_SUNWEB_PACKAGE_PROVIDER]
                            offer_item[const.CONST_SUNWEB_FLIGHT_ID_INBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_ID_INBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_DATE_TIME_INBOUND] = offer[
                                const.CONST_SUNWEB_DEPT_DATE_TIME_INBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE_INBOUND] = offer[
                                const.CONST_SUNWEB_DEPT_AIRPORT_CODE_INBOUND]
                            offer_item[const.CONST_SUNWEB_AIRPORT_LABEL_INBOUND] = offer[
                                const.CONST_SUNWEB_AIRPORT_LABEL_INBOUND]
                            offer_item[const.CONST_SUNWEB_AIRPORT_TIMEZONE_INBOUND] = offer[
                                const.CONST_SUNWEB_AIRPORT_TIMEZONE_INBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_DATE_TIME_INBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_DATE_TIME_INBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_INBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_INBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_INBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_INBOUND]
                            offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_CODE_INBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_CLASS_CODE_INBOUND]
                            offer_item[const.CONST_SUNWEB_CARRIER_CODE_INBOUND] = offer[
                                const.CONST_SUNWEB_CARRIER_CODE_INBOUND]
                            offer_item[const.CONST_SUNWEB_CARRIER_LABEL_INBOUND] = offer[
                                const.CONST_SUNWEB_CARRIER_LABEL_INBOUND]
                            offer_item[const.CONST_SUNWEB_FLIGHT_NUMBER_INBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_NUMBER_INBOUND]
                            offer_item[const.CONST_SUNWEB_DURATIONS_MINUTES_INBOUND] = offer[
                                const.CONST_SUNWEB_DURATIONS_MINUTES_INBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_DATE_TIME_OUTBOUND] = offer[
                                const.CONST_SUNWEB_DEPT_DATE_TIME_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_DEPT_AIRPORT_CODE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_LABEL_OUTBOUND] = offer[
                                const.CONST_SUNWEB_DEPT_AIRPORT_LABEL_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_TIMEZONE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_DEPT_AIRPORT_TIMEZONE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVALDATE_TIME_OUTBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVALDATE_TIME_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_OUTBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_CODE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_CLASS_CODE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_OUTBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_CARRIER_CODE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_CARRIER_CODE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_CARRIER_LABLE_OUTBOUND] = offer[
                                const.CONST_SUNWEB_CARRIER_LABLE_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_FLIGHT_NUMBER_OUTBOUND] = offer[
                                const.CONST_SUNWEB_FLIGHT_NUMBER_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_DURATION_MINUTES_OUTBOUND] = offer[
                                const.CONST_SUNWEB_DURATION_MINUTES_OUTBOUND]
                            offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_INBOUND] = offer[
                                const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_INBOUND]
                            offer_item[const.CONST_SUNWEB_ROOM_TYPE] = offer[const.CONST_SUNWEB_ROOM_TYPE]
                            offer_item[const.CONST_SUNWEB_ROOM_DESCRIPTION] = offer[const.CONST_SUNWEB_ROOM_DESCRIPTION]
                            yield offer_item
                    else:
                        continue

        if len(property_response[const.CONST_SUNWEB_RESULTS]) == 0:
            more_results = False

        if more_results:
            offset += 50
            payload = {
                'contextitemid': self.contextitemid,
                'isFirstUserRequest': 'True',
                'limit': const.CONST_SUNWEB_LIMIT,
                'offset': str(offset),
                'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
                'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,
                'ParticipantsDistribution': const.CONST_SUNWEB_PARTICIPANTS_DISTRIBUTION,
                'Country[0]': const.CONST_SUNWEB_COUNTRY,
                'Duration[0]': const.CONST_SUNWEB_PAYLOAD_DURATION,
                'TransportType': const.CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE,
                'isFirstLoad': 'false'}

            yield scrapy.FormRequest(
                url=self.search_api_url,
                formdata=payload,
                callback=self.parse_api_response,
                meta={const.CONST_SUNWEB_OFFSET: offset}
            )

    def parse_property_page(self, offer_url, accoid, mealcode, base_price, mapped_property_code, start_url):
        """
        The function `parse_property_page` parses a property page by making HTTP requests, extracting
        data from the response, and returning a list of offers.
        
        :param offer_url: The URL of the property offer page
        :param accoid: The `accoid` parameter is the ID of the accommodation. It is used to identify the
        specific property for which the page is being parsed
        :param mealcode: The `mealcode` parameter is used to specify the meal plan for the property. It
        is a code that represents the meal plan option, such as "RO" for Room Only, "BB" for Bed and
        Breakfast, "HB" for Half Board, "FB" for Full Board, etc
        :param base_price: The `base_price` parameter is the starting price for the property. It is used
        in the payload for the filters API to filter the offers based on the price range
        :param mapped_property_code: The `mapped_property_code` parameter is a code that represents the
        property being parsed. It is used to uniquely identify the property in the system
        :return: a list of offer items.
        """

        response = requests.get(offer_url)
        if response.status_code != 200:
            logging.error(f"Failed to fetch offer page at URL: {offer_url}")
            return None
        soup = BeautifulSoup(response.content, 'html.parser')
        context_item_id = soup.find(
            'input', {'id': const.CONST_SUNWEB_FILTER_CONTEXTITEMID_XPATH})['value']
        booking_gate_id = soup.find(
            'input', {'id': f'booking-gate-{accoid}-bookingGateId'})['value']

        if context_item_id is None or booking_gate_id is None:
            return None

        payload_for_filters_api = {
            "accoid": accoid,
            "contextitemid": context_item_id,
            "bookingGateId": booking_gate_id,
            'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
            'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,

        }

        response = requests.post(
            const.CONST_SUNWEB_FILTER_API,
            data=payload_for_filters_api)

        if not response:
            logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_FILTER_API}")
            return
        try:
            response = json.loads(response.text)
        except json.decoder.JSONDecodeError:
            return

        months_values = [month[const.CONST_SUNWEB_VALUE] for month in response[const.CONST_SUNWEB_MONTHS]]

        mealplan = response[const.CONST_SUNWEB_MEALPLANS][0][const.CONST_SUNWEB_TEXT]

        if mealplan == const.CONST_SUNWEB_ACCOMMODATION:
            mealplan = None
        formatted_dates = [
            date.split("-")[0] +
            "-" +
            date.split("-")[1] for date in months_values]
        current_date = datetime.today()
        while current_date.weekday() != const.CONST_VAYA_FIVE:
            current_date += timedelta(days=const.CONST_VAYA_ONE)

        end_date = datetime(const.CONST_VAYA_YEAR, const.CONST_VAYA_FIVE, const.CONST_VAYA_SIX)
        while end_date.weekday() != const.CONST_VAYA_FIVE:
            end_date += timedelta(days=const.CONST_VAYA_ONE)

        saturday_dates_list = all_saturday_dates(current_date, end_date)
        offers = []

        prefix = const.CONST_SUNWEB_PREFIX
        prefix1 = const.CONST_SUNWEB_PREFIX1

        if start_url == const.CONST_SUNWEB_SERACHPAGE_AUSTRIA_WINTERSPORT_URL or offer_url.startswith(prefix):
            payload = {
            "accoid": str(accoid),
            "contextitemid": context_item_id,
            "bookinggateid": booking_gate_id,
            'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
            'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,
            'duration[0]': const.CONST_SUNWEB_DURATION_VALUE_PAYLOAD,
            'durationsranges': const.CONST_SUNWEB_DURATION_RANGE_VALUE,
            "mealplan": mealcode,
            "transporttype": const.CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE
        }
            for month in formatted_dates:
                payload[const.CONST_SUNWEB_MONTH] = month
                response = requests.post(const.CONST_SUNWEB_DURATION_WINTERSPORT_PRICE_API, data=payload)
                if not response:
                    logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_DURATION_PRICE_API}")
                    continue
                try:
                    response = json.loads(response.text)
            
                except json.decoder.JSONDecodeError:
                    continue
                else:
                    if 'packages' in response:
                        for price in response['packages']:
                            if (price[const.CONST_SUNWEB_DURATION] == 8) and price[
                            const.CONST_SUNWEB_DEPATURE_DATE] in saturday_dates_list:
                                payload_for_room = payload.copy()
                                departure_date = price[const.CONST_SUNWEB_DEPATURE_DATE]
                                duration_for_room = price[const.CONST_SUNWEB_DURATION]
                                payload_for_room[const.CONST_SUNWEB_DURATION] = duration_for_room
                                payload_for_room['DepartureDate'] = departure_date

                                session = requests.Session()
                                retry = Retry(connect=3, backoff_factor=0.5)
                                adapter = HTTPAdapter(max_retries=retry)
                                session.mount('http://', adapter)
                                session.mount('https://', adapter)
                                response_room = session.post(
                                    const.CONST_SUNWEB_ROOM_SELECTOR_API, data=payload_for_room)
                                if not response_room:
                                    logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_ROOM_SELECTOR_API}")
                                    continue
                                try:
                                    response_room = json.loads(response_room.text)
                                except json.decoder.JSONDecodeError:
                                    continue
                                response_data = response_room[const.CONST_SUNWEB_DATA]
                                for room in response_data[const.CONST_SUNWEB_ROOMS]:
                                    offer_item = {}

                                    room_id = room[const.CONST_SUNWEB_ROOM_ID]
                                    room_des = room[const.CONST_SUNWEB_NAME_VARIABLE]

                                    session = requests.Session()
                                    retry = Retry(connect=3, backoff_factor=0.5)
                                    adapter = HTTPAdapter(max_retries=retry)
                                    session.mount('http://', adapter)
                                    session.mount('https://', adapter)

                                    payload_for_final_price = {
                                        "accoid": str(accoid),
                                        "contextitemid": context_item_id,
                                        "bookinggateid": booking_gate_id,
                                        'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
                                        'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,
                                        "duration": const.CONST_SUNWEB_DUARTION_VALUE_FOR_FINAL_PRICE_PAYLOAD,
                                        "durationsranges": const.CONST_SUNWEB_DURATION_RANGE_VALUE,
                                        "month": month,
                                        "datefrom": departure_date,
                                        "dateto": departure_date,
                                        "mealplan": mealcode,
                                        "transporttype": const.CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE,
                                        "room[0]": room_id

                                    }

                                    api_for_final_price = const.CONST_SUNWEB_API_FOR_FINAL_PRICE

                                    response_final = session.post(api_for_final_price, data=payload_for_final_price, timeout=50)
                                    if not response_final:
                                        logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_API_FOR_FINAL_PRICE}")
                                        continue
                                    try:
                                        response_final_price = json.loads(response_final.text)
                                    except json.decoder.JSONDecodeError:
                                        continue
                                    price_package = response_final_price[const.CONST_SUNWEB_TOTAL_PRICE].replace(
                                        const.CONST_SUNWEB_EURO, "").replace(const.CONST_SUNWEB_COMMA,
                                                                            const.CONST_SUNWEB_FULL_STOP)
                                    offer_per_person = response_final_price[const.CONST_SUNWEB_AVERAGE_PRICE].replace(
                                        const.CONST_SUNWEB_EURO, "").replace(const.CONST_SUNWEB_COMMA,
                                                                            const.CONST_SUNWEB_FULL_STOP)

                                    offer_item[const.CONST_SUNWEB_PROPERTY] = offer_url
                                    offer_item[const.CONST_SUNWEB_MAPPED_PROPERTY_CODE] = mapped_property_code
                                    offer_item[const.CONST_SUNWEB_OFFER_PER_PERSON] = offer_per_person
                                    offer_item[const.CONST_SUNWEB_PRICE_PACKAGE] = price_package
                                    offer_item[const.CONST_SUNWEB_OCCUPANCY] = 2
                                    offer_item[const.CONST_SUNWEB_OFFER_BRAND] = None
                                    offer_item[const.CONST_SUNWEB_PACKAGE] = None
                                    offer_item[const.CONST_SUNWEB_MEAL_CODE] = mealplan
                                    offer_item[const.CONST_SUNWEB_MEAL_CODE_LABEL] = None
                                    offer_item[const.CONST_SUNWEB_DURATION] = duration_for_room
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_DATE] = departure_date
                                    offer_item[const.CONST_PIPELINE_FREE_CANCELLATION_DEADLINE] = None
                                    offer_item[const.CONST_PIPELINE_NON_REFUNDABLE] = None
                                    offer_item[const.CONST_PIPELINE_ON_REQUEST] = None
                                    offer_item[const.CONST_PIPELINE_WITHOUT_PAYEMENT] = None
                                    offer_item[const.CONST_PIPELINE_CANCELLATION] = None
                                    offer_item[const.CONST_PIPELINE_GUARANTEES] = None
                                    offer_item[const.CONST_PIEPLINE_TAXES] = None
                                    offer_item[const.CONST_PIPELINE_PETS] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_LABEL] = None
                                    offer_item[const.CONST_SUNWEB_PACKAGE_PROVIDER] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_DATE_TIME_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_LABEL_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_TIMEZONE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVALDATE_TIME_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_CODE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_CARRIER_CODE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_CARRIER_LABLE_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_FLIGHT_NUMBER_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DURATION_MINUTES_OUTBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ROOM_TYPE] = room_id
                                    offer_item[const.CONST_SUNWEB_ROOM_DESCRIPTION] = room_des
                                    offer_item[const.CONST_SUNWEB_FLIGHT_ID_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_CODE_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_CARRIER_CODE_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_CARRIER_LABEL_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_FLIGHT_NUMBER_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DURATIONS_MINUTES_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_DATE_TIME_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_AIRPORT_LABEL_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_AIRPORT_TIMEZONE_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_DATE_TIME_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_INBOUND] = None
                                    offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_INBOUND] = None

                                    offers.append(offer_item)

            return offers
        
        elif start_url == const.CONST_SUNWEB_SERACHPAGE_AUSTRIA_URL or offer_url.startswith(prefix1):
            payload = {
                "accoid": str(accoid),
                "contextitemid": context_item_id,
                "bookinggateid": booking_gate_id,
                'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
                'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,
                'duration[0]': const.CONST_SUNWEB_DURATION_VALUE_PAYLOAD,
                'durationsranges': const.CONST_SUNWEB_DURATION_RANGE_VALUE,
                "mealplan": mealcode,
                "transporttype": const.CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE
            }
            
            
            for month in formatted_dates:
                payload[const.CONST_SUNWEB_MONTH] = month
                response = requests.post(const.CONST_SUNWEB_DURATION_PRICE_API, data=payload)
                if not response:
                    logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_DURATION_PRICE_API}")
                    continue
                try:
                    response = json.loads(response.text)
                except json.decoder.JSONDecodeError:
                    continue
                if not response[const.CONST_SUNWEB_DATA][const.CONST_SUNWEB_PRICES]:
                    continue
                else:

                    for price in response["data"]["prices"]:
                        if (price[const.CONST_SUNWEB_DURATION] == 8) and price[
                            const.CONST_SUNWEB_DEPATURE_DATE] in saturday_dates_list:
                            payload_for_room = payload.copy()
                            departure_date = price[const.CONST_SUNWEB_DEPATURE_DATE]
                            duration_for_room = price[const.CONST_SUNWEB_DURATION]
                            payload_for_room[const.CONST_SUNWEB_DURATION] = duration_for_room
                            payload_for_room['DepartureDate'] = departure_date

                            session = requests.Session()
                            retry = Retry(connect=3, backoff_factor=0.5)
                            adapter = HTTPAdapter(max_retries=retry)
                            session.mount('http://', adapter)
                            session.mount('https://', adapter)
                            response_room = session.post(
                                const.CONST_SUNWEB_ROOM_SELECTOR_API, data=payload_for_room)
                            if not response_room:
                                logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_ROOM_SELECTOR_API}")
                                continue
                            try:
                                response_room = json.loads(response_room.text)
                            except json.decoder.JSONDecodeError:
                                continue
                            response_data = response_room[const.CONST_SUNWEB_DATA]
                            for room in response_data[const.CONST_SUNWEB_ROOMS]:
                                offer_item = {}

                                room_id = room[const.CONST_SUNWEB_ROOM_ID]
                                room_des = room[const.CONST_SUNWEB_NAME_VARIABLE]

                                session = requests.Session()
                                retry = Retry(connect=3, backoff_factor=0.5)
                                adapter = HTTPAdapter(max_retries=retry)
                                session.mount('http://', adapter)
                                session.mount('https://', adapter)

                                payload_for_final_price = {
                                    "accoid": str(accoid),
                                    "contextitemid": context_item_id,
                                    "bookinggateid": booking_gate_id,
                                    'Participants[0][0]': const.CONST_SUNWEB_PARTICIPANTS,
                                    'Participants[0][1]': const.CONST_SUNWEB_PARTICIPANTS,
                                    "duration": const.CONST_SUNWEB_DUARTION_VALUE_FOR_FINAL_PRICE_PAYLOAD,
                                    "durationsranges": const.CONST_SUNWEB_DURATION_RANGE_VALUE,
                                    "month": month,
                                    "datefrom": departure_date,
                                    "dateto": departure_date,
                                    "mealplan": mealcode,
                                    "transporttype": const.CONST_SUNWEB_TRANSPORT_TYPE_SELF_DRIVE,
                                    "room[0]": room_id

                                }

                                api_for_final_price = const.CONST_SUNWEB_API_FOR_FINAL_PRICE

                                response_final = session.post(api_for_final_price, data=payload_for_final_price, timeout=50)
                                if not response_final:
                                    logging.error(f"Failed to fetch data from {const.CONST_SUNWEB_API_FOR_FINAL_PRICE}")
                                    continue
                                try:
                                    response_final_price = json.loads(response_final.text)
                                except json.decoder.JSONDecodeError:
                                    continue
                                price_package = response_final_price[const.CONST_SUNWEB_TOTAL_PRICE].replace(
                                    const.CONST_SUNWEB_EURO, "").replace(const.CONST_SUNWEB_COMMA,
                                                                        const.CONST_SUNWEB_FULL_STOP)
                                offer_per_person = response_final_price[const.CONST_SUNWEB_AVERAGE_PRICE].replace(
                                    const.CONST_SUNWEB_EURO, "").replace(const.CONST_SUNWEB_COMMA,
                                                                        const.CONST_SUNWEB_FULL_STOP)
                                
                                offer_item[const.CONST_SUNWEB_PROPERTY] = offer_url
                                offer_item[const.CONST_SUNWEB_MAPPED_PROPERTY_CODE] = mapped_property_code
                                offer_item[const.CONST_SUNWEB_OFFER_PER_PERSON] = offer_per_person
                                offer_item[const.CONST_SUNWEB_PRICE_PACKAGE] = price_package
                                offer_item[const.CONST_SUNWEB_OCCUPANCY] = 2
                                offer_item[const.CONST_SUNWEB_OFFER_BRAND] = None
                                offer_item[const.CONST_SUNWEB_PACKAGE] = None
                                offer_item[const.CONST_SUNWEB_MEAL_CODE] = mealplan
                                offer_item[const.CONST_SUNWEB_MEAL_CODE_LABEL] = None
                                offer_item[const.CONST_SUNWEB_DURATION] = duration_for_room
                                offer_item[const.CONST_SUNWEB_ARRIVAL_DATE] = departure_date
                                offer_item[const.CONST_PIPELINE_FREE_CANCELLATION_DEADLINE] = None
                                offer_item[const.CONST_PIPELINE_NON_REFUNDABLE] = None
                                offer_item[const.CONST_PIPELINE_ON_REQUEST] = None
                                offer_item[const.CONST_PIPELINE_WITHOUT_PAYEMENT] = None
                                offer_item[const.CONST_PIPELINE_CANCELLATION] = None
                                offer_item[const.CONST_PIPELINE_GUARANTEES] = None
                                offer_item[const.CONST_PIEPLINE_TAXES] = None
                                offer_item[const.CONST_PIPELINE_PETS] = None
                                offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE] = None
                                offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_LABEL] = None
                                offer_item[const.CONST_SUNWEB_PACKAGE_PROVIDER] = None
                                offer_item[const.CONST_SUNWEB_DEPT_DATE_TIME_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_LABEL_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_TIMEZONE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVALDATE_TIME_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_CODE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_CARRIER_CODE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_CARRIER_LABLE_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_FLIGHT_NUMBER_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_DURATION_MINUTES_OUTBOUND] = None
                                offer_item[const.CONST_SUNWEB_ROOM_TYPE] = room_id
                                offer_item[const.CONST_SUNWEB_ROOM_DESCRIPTION] = room_des
                                offer_item[const.CONST_SUNWEB_FLIGHT_ID_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_TIMEZONE_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_CODE_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_FLIGHT_CLASS_LABEL_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_CARRIER_CODE_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_CARRIER_LABEL_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_FLIGHT_NUMBER_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_DURATIONS_MINUTES_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_DEPT_DATE_TIME_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_DEPT_AIRPORT_CODE_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_AIRPORT_LABEL_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_AIRPORT_TIMEZONE_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_DATE_TIME_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_CODE_INBOUND] = None
                                offer_item[const.CONST_SUNWEB_ARRIVAL_AIRPORT_LABEL_INBOUND] = None

                                offers.append(offer_item)

            return offers

    def closed(self, reason):
        """
        The `closed` function is responsible for closing the spider and performing some database
        operations.
        
        :param reason: The "reason" parameter is a string that represents the reason for closing the
        spider. It could be an error message, a completion message, or any other relevant information
        """
        end_time = datetime.now()
        try:
            self.cur = self.db_conn.connection.cursor()
            self.cur.execute(f"SELECT provider_id FROM provider WHERE provider = '{const.CONST_SUNWEB_PROVIDER_NAME}'")

            row = self.cur.fetchone()
            if row is not None:
                provider_id = row[0]
            self.cur.execute(queries.INSERT_CRAWLER_QUERY, (self.start_time, end_time, provider_id))
            self.db_conn.connection.commit()

        except Exception as closed_spider_error:
            logging.exception(f"An exception occurred while closing the spider:{closed_spider_error}")
        finally:
            if hasattr(self, 'cur') and self.cur:
                self.cur.close()