import json
from datetime import datetime, timedelta
import logging
import pandas as pd
import scrapy
import re

from vayahotel.database_connection import DatabaseConnection
from vayahotel.items import (
    ProviderItem,
    PropertyItem,
    OfferItem
)
from vayahotel.utils import (
    extract_description,
    extract_property_code,
    extract_location,
    extract_property_name,
    remove_html_tags,
    all_saturday_dates,
    extract_clean_text
)
from vayahotel import queries
import vayahotel.common_constant as const


# The class VayaHotelSpider is a Python spider used for web scraping hotel data from a specific
# website.
class VayaHotelSpider(scrapy.Spider):
    name = const.CONST_VAYA_SPIDER_NAME
    start_urls = [const.CONST_VAYA_BASE_URL]
    logging.basicConfig(filename=const.CONST_VAYA_FILENAME, level=logging.INFO)
    LoggerFormat = '[%(asctime)s] {%(pathname)s:%(lineno)d} %(levelname)s - %(message)s'

    def __init__(self, name=None, **kwargs):
        """
        The function initializes an object with a database connection, occupancy value, and start time.
        
        :param name: The `name` parameter is used to specify the name of the object being initialized.
        It is an optional parameter and its default value is `None`
        """
        self.db_conn = DatabaseConnection()
        self.occupancy = const.CONST_VAYA_OCCUPANCY
        self.start_time = datetime.now()
        super().__init__(name, **kwargs)

    def get_urls(self):
        """
        The function `get_urls` retrieves data from a database table and returns it as a pandas
        DataFrame.
        :return: a DataFrame object called "url_data" which contains the results of a database query.
        """
        try:
            self.cur = self.db_conn.connection.cursor()
            self.cur.execute(queries.GET_VAYA_PROPERTIES_URL)
            results = self.cur.fetchall()
            columns = [desc[0] for desc in self.cur.description]
            url_data = pd.DataFrame(results, columns=columns)
            return url_data
        except Exception as get_urls_error:
            logging.error(f"An error occurred: {get_urls_error}")
        finally:
            self.cur.close()

    def parse(self, response):
        """
        The function parses a response and yields ProviderItem objects, then iterates over properties
        data and makes scrapy requests for each property.
        
        :param response: The `response` parameter is the HTTP response object returned by the website
        you are scraping. It contains the HTML content of the webpage you are parsing
        :return: In this code, a scrapy `ProviderItem` object is being yielded first. Then, a loop is
        iterating over `properties_data` and for each row, a scrapy `Request` object is being yielded.
        """
        yield ProviderItem(
            provider=const.CONST_VAYA_NAME,
            provider_description=const.CONST_VAYA_DESCRIPTION,
            provider_url=const.CONST_VAYA_PROVIDER_URL,
            created_by=const.CONST_VAYA_CREATED_BY,
        )
        urls = self.get_urls()
        properties_data = urls[[const.CONST_VAYA_URL_VAYA, const.CONST_VAYA_MAPPED_PROPERTY_CODE]]
        for _, row in properties_data.iterrows():

            url = row[const.CONST_VAYA_URL_VAYA]
            mapped_property_code = row[const.CONST_VAYA_MAPPED_PROPERTY_CODE]
            if url is None:
                return
            if url == '':
                return
            else:
                yield scrapy.Request(
                    url=url, callback=self.parse_property,
                    meta={const.CONST_VAYA_PROPERTY_URL: url, const.PROVIDER: const.CONST_VAYA_NAME,
                          const.CONST_VAYA_MAPPED_PROPERTY_CODE: mapped_property_code}
                )

    def parse_property(self, response):
        """
        The function `parse_property` is used to extract information from a web page response and yield
        a `PropertyItem` object, and then make subsequent requests to retrieve offers for the property.
        
        :param response: The `response` parameter is the response object returned by the web server
        after making a request. It contains information such as the HTML content of the page, response
        headers, and metadata
        """
        mapped_property_code = response.meta.get(const.CONST_VAYA_MAPPED_PROPERTY_CODE)
        property_url = response.meta.get(const.CONST_VAYA_PROPERTY_URL)
        html_content = response.text

        description = extract_description(html_content)
        description = remove_html_tags(description)

        property_code = extract_property_code(html_content)
        city, country, address, state = extract_location(html_content)
        property_name = extract_property_name(html_content)

        yield PropertyItem(
            provider=response.meta.get(const.PROVIDER),
            property_name=property_name,
            property_slug=None,
            property_description=description,
            mapped_property_code=mapped_property_code,
            property_url=property_url,
            accomodation_type=None,
            property_code=property_code,
            country=country,
            country_slug=None,
            region=state,
            region_slug=None,
            city=city,
            city_slug=None,
            address=address
        )

        current_date = datetime.today()
        while current_date.weekday() != const.CONST_VAYA_FIVE:
            current_date += timedelta(days=const.CONST_VAYA_ONE)

        end_date = datetime(const.CONST_VAYA_YEAR, const.CONST_VAYA_FIVE, const.CONST_VAYA_SIX)
        while end_date.weekday() != const.CONST_VAYA_FIVE:
            end_date += timedelta(days=const.CONST_VAYA_ONE)

        saturday_dates_list = all_saturday_dates(current_date, end_date)

        for i in range(len(saturday_dates_list) - const.CONST_VAYA_ONE):
            checkin = saturday_dates_list[i]
            checkout = saturday_dates_list[i + const.CONST_VAYA_ONE]
            api_offers = const.CONST_VAYA_API_OFFERS
            payload = {
                "channelId": const.CONST_VAYA_CHANNEL_ID,
                "propertyCode": property_code,
                "checkIn": checkin,
                "checkOut": checkout,
                "occupancy": const.CONST_VAYA_OCCUPANCY_DICT,
                "currency": const.CONST_VAYA_CURRENCY_CODE,
                "user": {
                    "ipAddress": const.CONST_VAYA_IP_ADDRESS,
                    "userAgent": const.CONST_VAYA_USER_AGENT,
                    "language": const.CONST_VAYA_LANGUAGE,
                },
                "priceDisplayMode": const.CONST_VAYA_PRICE_DISPLAY_MODE,
                "priceCalcMode": const.CONST_VAYA_PRICE_CAL_MODE,
                "includeWaitingLists": False,
                "coupon": None,
                "sortOrder": const.CONST_VAYA_SORT_ORDER,
            }

            headers = {const.CONST_VAYA_CONTENT_TYPE: const.CONST_VAYA_APPLICATION_JSON}

            yield scrapy.Request(
                url=api_offers,
                method=const.CONST_VAYA_METHOD_POST,
                headers=headers,
                body=json.dumps(payload),
                callback=self.parse_offer,
                meta={const.PROVIDER: response.meta.get(const.PROVIDER),
                      const.CONST_VAYA_DICT_KEY_PROPERTY: property_url,
                      const.CONST_VAYA_PROPERTY_CODE: property_code,
                      const.CONST_VAYA_MAPPED_PROPERTY_CODE: mapped_property_code,
                      const.CONST_VAYA_CHECK_IN: checkin,
                      const.CONST_VAYA_CHECK_OUT: checkout}
            )

    def parse_offer(self, response):
        """
        The function `parse_offer` parses the response from a web API and extracts room offers and
        package offers, making subsequent requests to retrieve more information.
        
        :param response: The `response` parameter is the response object returned by the HTTP request
        made in the previous function. It contains the response data, headers, and other information
        related to the request
        """
        checkin = response.meta.get(const.CONST_VAYA_CHECK_IN)
        checkout = response.meta.get(const.CONST_VAYA_CHECK_OUT)
        mapped_property_code = response.meta.get(const.CONST_VAYA_MAPPED_PROPERTY_CODE)
        property_code = response.meta.get(const.CONST_VAYA_PROPERTY_CODE)
        offer_data = json.loads(response.body)
        room_offers = offer_data.get(const.CONST_VAYA_ROOM_OFFERS, [])
        packageOffers = offer_data.get(const.CONST_VAYA_PACKAGES_OFFERS, [])
        property_url = response.meta.get(const.CONST_VAYA_DICT_KEY_PROPERTY)
        if room_offers:
            for room_offer in room_offers:
                room_type = room_offer.get(const.CONST_VAYA_CODE)
                room_description = room_offer.get(const.CONST_VAYA_METADATA, {}).get(const.CONST_VAYA_TITLE, "")
                rates = room_offer.get(const.CONST_VAYA_RATES, [])
                for rate in rates:
                    rate_code = rate.get(const.CONST_VAYA_CODE)
                    shopping_cart_price = rate.get(const.CONST_VAYA_SHOPPING_CART_PRICE)
                    meal_plan_code = rate.get(const.CONST_VAYA_EXTRA_INFO, {}).get(const.CONST_VAYA_MEAL_PLAN)
                    free_cancellation_deadline = rate.get(const.CONST_VAYA_EXTRA_INFO, {}).get(
                        const.CONST_VAYA_FREE_CANCELLATION_DEADLINE)
                    non_refundable = rate.get(const.CONST_VAYA_EXTRA_INFO, {}).get(const.CONST_VAYA_NON_REFUNDABLE)
                    on_request = rate.get(const.CONST_VAYA_EXTRA_INFO, {}).get(const.CONST_VAYA_ON_REQUEST)
                    without_payment = rate.get(const.CONST_VAYA_EXTRA_INFO, {}).get(const.CONST_VAYA_WITHOUT_PAYEMENT)

                    cancellations = rate.get(const.CONST_VAYA_POLICIES).get(const.CONST_VAYA_CANCELLATION)
                    cleaned_strings = [re.sub(r'<.*?>', '', html) for html in cancellations]
                    cancellations = ' '.join(cleaned_strings)

                    guarantees = rate.get(const.CONST_VAYA_POLICIES).get(const.CONST_VAYA_GUARANTEES)
                    guarantees = remove_html_tags(guarantees)

                    taxes = rate.get(const.CONST_VAYA_POLICIES).get(const.CONST_VAYA_TAXES)
                    taxes = extract_clean_text(taxes)

                    pets = rate.get(const.CONST_VAYA_POLICIES).get(const.CONST_VAYA_PETS)
                    pets = extract_clean_text(pets)

                    room_code = room_type
                    api_url = const.CONST_VAYA_PROPERTY + f"{property_code}" + const.CONST_VAYA_SHOPPING_CART_URL
                    payload = {
                        "roomCode": room_code,
                        "rateCode": rate_code,
                        "guid": None,
                        "checkIn": checkin,
                        "checkOut": checkout,
                        "currencyCode": const.CONST_VAYA_CURRENCY_CODE,
                        "occupancy": const.CONST_VAYA_OCCUPANCY_DICT,
                        "user": {
                            "language": const.CONST_VAYA_LANGUAGE,
                            "ipAddress": const.CONST_VAYA_IP_ADDRESS,
                            "userAgent": const.CONST_VAYA_USER_AGENT,
                        },
                        "price": shopping_cart_price,
                        "priceCalcMode": const.CONST_VAYA_PRICE_CAL_MODE,
                        "returnUrlTemplate": const.CONST_VAYA_RETURN_URL_TEMPLATE,
                    }

                    headers = {const.CONST_VAYA_CONTENT_TYPE: const.CONST_VAYA_APPLICATION_JSON}
                    yield scrapy.Request(
                        url=api_url,
                        method=const.CONST_VAYA_METHOD_POST,
                        headers=headers,
                        body=json.dumps(payload),
                        callback=self.parse_shopping_cart,
                        meta={
                            "room_type": room_type,
                            "room_description": room_description,
                            "shopping_cart_price": shopping_cart_price,
                            "ratecode": rate_code,
                            "meal_plan_code": meal_plan_code,
                            const.PROVIDER: response.meta.get(const.PROVIDER),
                            const.CONST_VAYA_DICT_KEY_PROPERTY: property_url,
                            "mapped_property_code": mapped_property_code,
                            const.CONST_VAYA_FREE_CANCELLATION_DEADLINE: free_cancellation_deadline,
                            const.CONST_VAYA_NON_REFUNDABLE: non_refundable,
                            const.CONST_VAYA_ON_REQUEST: on_request,
                            const.CONST_VAYA_WITHOUT_PAYEMENT: without_payment,
                            const.CONST_VAYA_CANCELLATION: cancellations,
                            const.CONST_VAYA_GUARANTEES: guarantees,
                            const.CONST_VAYA_TAXES: taxes,
                            const.CONST_VAYA_PETS: pets,
                            const.CONST_VAYA_CHECK_IN: checkin,
                            const.CONST_VAYA_CHECK_OUT: checkout

                        }
                    )
        for packageoffer in packageOffers:
            package_code = packageoffer.get(const.CONST_VAYA_CODE)

        if packageOffers:
            api_url_package = const.CONST_VAYA_PACKAGE_API
            package_payload = {
                "channelId": const.CONST_VAYA_CHANNEL_ID,
                "marketing": {
                    "bookingIncentiveReservationFormat": "LastBookingTimespanAgo",
                    "bookingIncentiveRoomThreshold": const.CONST_VAYA_ONE,
                    "bookingIncentiveCheckPeriod": const.CONST_VAYA_TWENTY_FOUR
                },
                "propertyCode": property_code,
                "checkIn": checkin,
                "checkOut": checkout,
                "currency": const.CONST_VAYA_CURRENCY_CODE,
                "occupancy": const.CONST_VAYA_OCCUPANCY_DICT,
                "priceDisplayMode": const.CONST_VAYA_PRICE_DISPLAY_MODE,
                "priceCalcMode": const.CONST_VAYA_PRICE_CAL_MODE,
                "user": {
                    "ipAddress": const.CONST_VAYA_IP_ADDRESS,
                    "userAgent": const.CONST_VAYA_USER_AGENT,
                    "language": const.CONST_VAYA_LANGUAGE
                },
                "packageCode": package_code,
                "sortOrder": const.CONST_VAYA_SORT_ORDER
            }
            package_headers = {const.CONST_VAYA_CONTENT_TYPE: const.CONST_VAYA_APPLICATION_JSON}

            yield scrapy.Request(
                url=api_url_package,
                method=const.CONST_VAYA_METHOD_POST,
                headers=package_headers,
                body=json.dumps(package_payload),
                callback=self.parse_package_offers,
                meta={
                    const.PROVIDER: response.meta.get(const.PROVIDER),
                    const.CONST_VAYA_DICT_KEY_PROPERTY: property_url,
                    const.CONST_VAYA_MAPPED_PROPERTY_CODE: mapped_property_code,
                    const.CONST_VAYA_PROPERTY_CODE: property_code,
                    const.CONST_VAYA_CHECK_IN: checkin,
                    const.CONST_VAYA_CHECK_OUT: checkout
                }
            )

    def parse_package_offers(self, response):
        """
        The function `parse_package_offers` parses package offers from a response and sends a request to
        the shopping cart API for each offer.
        
        :param response: The `response` parameter is the response object returned by the HTTP request
        made to the API endpoint. It contains the response body, headers, and other information related
        to the request
        """
        checkin = response.meta.get(const.CONST_VAYA_CHECK_IN)
        checkout = response.meta.get(const.CONST_VAYA_CHECK_OUT)
        mapped_property_code = response.meta.get(const.CONST_VAYA_MAPPED_PROPERTY_CODE)
        property_code = response.meta.get(const.CONST_VAYA_PROPERTY_CODE)

        property_url = response.meta.get(const.CONST_VAYA_DICT_KEY_PROPERTY)
        package_data = json.loads(response.body)
        free_cancellation_deadline = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_EXTRA_INFO,
                                                                                        {}).get(
            const.CONST_VAYA_FREE_CANCELLATION_DEADLINE)
        non_refundable = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_EXTRA_INFO, {}).get(
            const.CONST_VAYA_NON_REFUNDABLE)
        on_request = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_EXTRA_INFO, {}).get(
            const.CONST_VAYA_ON_REQUEST)
        without_payment = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_EXTRA_INFO, {}).get(
            const.CONST_VAYA_WITHOUT_PAYEMENT)

        cancellations = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_POLICIES).get(
            const.CONST_VAYA_CANCELLATION)
        cleaned_strings = [re.sub(r'<.*?>', '', html) for html in cancellations]
        cancellations = ' '.join(cleaned_strings)

        guarantees = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_POLICIES).get(
            const.CONST_VAYA_GUARANTEES)
        guarantees = remove_html_tags(guarantees)

        taxes = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_POLICIES).get(
            const.CONST_VAYA_TAXES)
        taxes = extract_clean_text(taxes)

        pets = package_data.get(const.CONST_VAYA_DETAILS, {}).get(const.CONST_VAYA_POLICIES).get(const.CONST_VAYA_PETS)
        pets = extract_clean_text(pets)

        room_offers = package_data.get(const.CONST_VAYA_ROOM_OFFERS, [])
        for room_offer in room_offers:
            room_type = room_offer.get(const.CONST_VAYA_CODE)
            room_description = room_offer.get(const.CONST_VAYA_METADATA, {}).get(const.CONST_VAYA_TITLE, "")
            rates = room_offer.get(const.CONST_VAYA_RATES, [])
            for rate in rates:
                rate_code = rate.get(const.CONST_VAYA_CODE)
                shopping_cart_price = rate.get(const.CONST_VAYA_SHOPPING_CART_PRICE)
                meal_plan_code = rate.get(const.CONST_VAYA_EXTRA_INFO, {}).get(const.CONST_VAYA_MEAL_PLAN)
                room_code = room_type
                api_url = const.CONST_VAYA_PROPERTY + f"{property_code}" + const.CONST_VAYA_SHOPPING_CART_URL   

                payload = {
                    "roomCode": room_code,
                    "rateCode": rate_code,
                    "guid": None,
                    "checkIn": checkin,
                    "checkOut": checkout,
                    "currencyCode": const.CONST_VAYA_CURRENCY_CODE,
                    "occupancy": const.CONST_VAYA_OCCUPANCY_DICT,
                    "user": {
                        "language": const.CONST_VAYA_LANGUAGE,
                        "ipAddress": const.CONST_VAYA_IP_ADDRESS,
                        "userAgent": const.CONST_VAYA_USER_AGENT,
                    },
                    "price": shopping_cart_price,
                    "priceCalcMode": const.CONST_VAYA_PRICE_CAL_MODE,
                    "returnUrlTemplate": const.CONST_VAYA_RETURN_URL_TEMPLATE,
                }

                headers = {const.CONST_VAYA_CONTENT_TYPE: const.CONST_VAYA_APPLICATION_JSON}
                yield scrapy.Request(
                    url=api_url,
                    method=const.CONST_VAYA_METHOD_POST,
                    headers=headers,
                    body=json.dumps(payload),
                    callback=self.parse_shopping_cart,
                    meta={
                        "room_type": room_type,
                        "room_description": room_description,
                        "shopping_cart_price": shopping_cart_price,
                        "ratecode": rate_code,
                        "meal_plan_code": meal_plan_code,
                        const.CONST_VAYA_FREE_CANCELLATION_DEADLINE: free_cancellation_deadline,
                        const.CONST_VAYA_NON_REFUNDABLE: non_refundable,
                        const.CONST_VAYA_ON_REQUEST: on_request,
                        const.CONST_VAYA_WITHOUT_PAYEMENT: without_payment,
                        const.CONST_VAYA_CANCELLATION: cancellations,
                        const.CONST_VAYA_GUARANTEES: guarantees,
                        const.CONST_VAYA_TAXES: taxes,
                        const.CONST_VAYA_PETS: pets,
                        const.PROVIDER: response.meta.get(const.PROVIDER),
                        const.CONST_VAYA_DICT_KEY_PROPERTY: property_url,
                        const.CONST_VAYA_MAPPED_PROPERTY_CODE: mapped_property_code,
                        const.CONST_VAYA_CHECK_IN: checkin
                    }
                )

    def parse_shopping_cart(self, response):
        """
        The function `parse_shopping_cart` parses a shopping cart response and yields an `OfferItem`
        object with various attributes.
        
        :param response: The `response` parameter is the HTTP response object that is returned from
        making a request to a website or API. It contains information such as the response body,
        headers, and status code
        """
        free_cancellation_deadline = response.meta.get(const.CONST_VAYA_FREE_CANCELLATION_DEADLINE)
        non_refundable = response.meta.get(const.CONST_VAYA_NON_REFUNDABLE)
        on_request = response.meta.get(const.CONST_VAYA_ON_REQUEST)
        without_payment = response.meta.get(const.CONST_VAYA_WITHOUT_PAYEMENT)
        cancellations = response.meta.get(const.CONST_VAYA_CANCELLATION)
        guarantees = response.meta.get(const.CONST_VAYA_GUARANTEES)
        taxes = response.meta.get(const.CONST_VAYA_TAXES)
        pets = response.meta.get(const.CONST_VAYA_TAXES)
        checkin = response.meta.get(const.CONST_VAYA_CHECK_IN)
        mapped_property_code = response.meta.get(const.CONST_VAYA_MAPPED_PROPERTY_CODE)
        room_type = response.meta.get(const.CONST_VAYA_ROOM_TYPE)
        room_description = response.meta.get(const.CONST_VAYA_ROOM_DES)
        meal_plan_code = response.meta.get(const.CONST_MEAL_PLAN_CODE)
        shopping_cart_data = json.loads(response.body)
        user_total = shopping_cart_data.get(const.CONST_VAYA_TOTALS).get(const.CONST_VAYA_USER_TOTALS)
        offer_per_person = user_total / self.occupancy
        offer_per_person = round(offer_per_person, 2)
        price_package = round(user_total, 2)

        yield OfferItem(
            property=response.meta.get(const.CONST_VAYA_DICT_KEY_PROPERTY),
            mapped_property_code=mapped_property_code,
            offer_per_person=offer_per_person,
            price_package=price_package,
            occupancy=self.occupancy,
            package=None,
            offer_brand=None,
            meal_code=meal_plan_code,
            meal_code_label=None,
            arrivaldate=checkin,
            free_cancellation_deadline=free_cancellation_deadline,
            non_refundable=non_refundable,
            on_request=on_request,
            without_payment=without_payment,
            cancellations=cancellations,
            guarantees=guarantees,
            taxes=taxes,
            pets=pets,
            departure_date_time_inbound=None,
            departure_airport_code_inbound=None,
            departure_airport_label_inbound=None,
            departure_airport_timezone_inbound=None,
            arrival_date_time_inbound=None,
            arrival_airport_code_inbound=None,
            arrival_airport_label_inbound=None,
            arrival_airport_timezone_inbound=None,
            flight_class_code_inbound=None,
            flight_class_label_inbound=None,
            carrier_code_inbound=None,
            carrier_label_inbound=None,
            flight_number_inbound=None,
            duration_minutes_inbound=None,
            departure_datetime_outbound=None,
            departure_airport_code_outbound=None,
            departure_airport_label_outbound=None,
            departure_airport_timezone_outbound=None,
            arrival_date_time_outbound=None,
            arrival_airport_code_outbound=None,
            arrival_airport_label_outbound=None,
            arrival_airport_timezone_outbound=None,
            flight_class_code_outbound=None,
            flight_class_label_outbound=None,
            carrier_code_outbound=None,
            carrier_label_outbound=None,
            flight_number_outbound=None,
            duration_minutes_outbound=None,
            room_type=room_type,
            room_description=room_description,
            duration=const.CONST_VAYA_DURATION,
            departure_airport_code=None,
            departure_airport_label=None,
            package_provider=None,
            flightId_inbound=None
        )

    def closed(self, reason):
        """
        The `closed` function is responsible for closing the spider and performing some database
        operations.
        
        :param reason: The "reason" parameter is a string that represents the reason for closing the
        spider. It could be an error message, a completion message, or any other relevant information
        """
        end_time = datetime.now()
        try:
            self.cur = self.db_conn.connection.cursor()
            self.cur.execute(f"SELECT provider_id FROM provider WHERE provider = '{const.CONST_VAYA_NAME}'")

            row = self.cur.fetchone()
            if row is not None:
                provider_id = row[0]
            self.cur.execute(queries.INSERT_CRAWLER_QUERY, (self.start_time, end_time, provider_id))
            self.db_conn.connection.commit()

        except Exception as closed_spider_error:
            logging.exception(f"An exception occurred while closing the spider:{closed_spider_error}")
        finally:
            if hasattr(self, 'cur') and self.cur:
                self.cur.close()
