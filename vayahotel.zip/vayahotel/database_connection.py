import logging
import mysql.connector
from mysql.connector import Error
from vayahotel import config

# The class `DatabaseConnection` initializes a connection attribute and establishes a connection.
class DatabaseConnection:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        """
        The `connect` function establishes a connection to a MySQL database using the provided configuration
        parameters.
        """
        try:
            HOSTNAME = config.HOSTNAME
            USERNAME = config.USERNAME
            PASSWORD = config.PASSWORD
            DATABASE = config.DATABASE
            self.connection = mysql.connector.connect(
                host=HOSTNAME,
                user=USERNAME,
                password=PASSWORD,
                database=DATABASE
            )
        except Error as connection_error:
            logging.error(f"Error while connecting to MySQL: {connection_error}")

    def close(self):
        if self.connection is not None:
            self.connection.close()
