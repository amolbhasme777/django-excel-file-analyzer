import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from vayahotel import common_constant as const
import os
import logging

def send_mail(excel_file_path):
    """
    Automation to send mail with attachment of PMS booking data report to the client mail.
    """
    # Create an EmailMessage instance
    msg = MIMEMultipart()

    # Set the email headers
    msg["Subject"] = const.CONST_PMS_EMAIL_SUBJECT
    msg["From"] = const.CONST_SENDER_MAIL
    msg["To"] = const.CONST_RECIPIENT_MAIL

    # Create the email message body
    email_body = const.CONST_PMS_EMAIL_BODY

    # Attach the PMS booking data report (Assuming it"s an Excel file)
    file_name = os.path.basename(excel_file_path)
    
    try:
        with open(excel_file_path, "rb") as file:
            part = MIMEBase("application", "octet-stream")
            part.set_payload((file).read())
            encoders.encode_base64(part)
            part.add_header("Content-Disposition", "attachment; filename={file_name}".format(file_name=file_name))
            msg.attach(part)

        # Set the email message body
        msg.attach(MIMEText(email_body, "plain"))

        # Connect to your email provider"s SMTP server (e.g., Gmail)
        s = smtplib.SMTP("smtp.gmail.com", 587)
        s.starttls()

        # Log in to your email account
        s.login(const.CONST_SENDER_MAIL, const.CONST_SENDER_MAIL_PASSWORD)

        # Send the email
        s.send_message(msg)

        # Quit the SMTP server
        s.quit()
        
        logging.info("Protel PMS booking report sent to mail successfully")
    except Exception as excep:
        logging.error(f"Protel PMS booking report not sent {excep} ")
        
        
