import re
import json
import logging
from bs4 import BeautifulSoup
from vayahotel import common_constant as const
from datetime import datetime, timedelta


logging.basicConfig(level=logging.ERROR)  

def extract_description(html_content):
    """
    The function `extract_description` takes in HTML content as input, uses BeautifulSoup to parse the
    content, and extracts the description from the HTML metadata. If the description is found, it is
    returned. If not, a default message is returned.
    
    :param html_content: The HTML content from which you want to extract the description
    :return: the extracted description from the HTML content if it is found. If the description is not
    found or if an error occurs during the extraction process, the function returns the string
    "Description not found".
    """
    try:
        soup = BeautifulSoup(html_content, 'html.parser')
        if description_tag and 'content' in description_tag.attrs:
            description = description_tag['content']
            return description
        else:
            return "Description not found"
    except Exception as extract_description_error:
        logging.error("An error occurred while extracting description: %s", extract_description_error)
        return "Description not found"

def extract_property_code(html_content):
    """
    The function `extract_property_code` extracts the property code from HTML content using regular
    expressions.
    
    :param html_content: The `html_content` parameter is a string that represents the HTML content of a
    webpage
    :return: the property code extracted from the HTML content. If the property code is found, it is
    returned as a string. If the property code is not found or an error occurs during the extraction
    process, None is returned.
    """
    try:
        property_code_pattern = re.compile(r'"propertyCode"\s*:\s*"([^"]+)"')
        property_code_match = property_code_pattern.search(html_content)
        if property_code_match:
            return property_code_match.group(1)
        else:
            return None
    except Exception as extract_property_code_error:
        logging.error("An error occurred while extracting property code: %s", extract_property_code_error)
        return None

def extract_location(html_content):
    """
    The function `extract_location` extracts the city, country, address, and state from HTML content.
    
    :param html_content: The `html_content` parameter is a string that contains the HTML content of a
    webpage
    :return: The function `extract_location` returns a tuple containing the values of `city`, `country`,
    `address`, and `state`.
    """
    try:
        location_pattern = re.compile(r'location":(.*?)}')
        location_match = location_pattern.search(html_content)
        if location_match:
            location_json = location_match.group(1) + "}"
            location_dict = json.loads(location_json)
            city = location_dict.get(const.CONST_VAYA_CITY, None)
            country = location_dict.get(const.CONST_VAYA_COUNTRY, None)
            address = location_dict.get(const.CONST_VAYA_ADDRESS, None)
            state = location_dict.get(const.CONST_VAYA_STATE, None)
            return city, country, address, state
        else:
            return None, None
    except Exception as extract_location_error:
        logging.error("An error occurred while extracting location: %s", extract_location_error)
        return None, None

def extract_property_name(html_content):
    """
    The function `extract_property_name` extracts the title from an HTML content and returns it, or
    returns "Title not found" if the title is not present.
    
    :param html_content: The HTML content from which you want to extract the property name
    :return: the extracted property name from the HTML content if it is found. If the property name is
    not found, it returns the string "Title not found".
    """
    try:
        title_pattern = re.compile(r'<title>(.*?)<\/title>')
        title_match = title_pattern.search(html_content)
        if title_match:
            return title_match.group(1)
        else:
            return "Title not found"
    except Exception as extract_title_error:
        logging.error("An error occurred while extracting title: %s", extract_title_error)
        return "Title not found"
    
def remove_html_tags(input_string):
    """
    The function removes HTML tags from an input string.
    
    :param input_string: The input string that contains HTML tags that need to be removed
    :return: a clean string with all HTML tags removed.
    """
    clean_string = re.sub(r'<.*?>', '', input_string)  
    return clean_string    

def all_saturday_dates(start_date, end_date):
    """
    The function "all_saturday_dates" returns a list of all the Saturday dates between a given start
    date and end date.
    
    :param start_date: The start date is the date from which you want to start finding Saturday dates.
    It should be in the format 'YYYY-MM-DD'
    :param end_date: The end_date parameter is the date until which you want to find all the Saturday
    dates
    :return: a list of all the Saturday dates between the start_date and end_date.
    """
    saturday_dates = []
    current_date = start_date
    while current_date <= end_date:
        if current_date.weekday() == const.CONST_VAYA_FIVE:
            saturday_dates.append(current_date.strftime('%Y-%m-%d'))
        current_date += timedelta(days=const.CONST_VAYA_ONE)
    return saturday_dates


def extract_clean_text(text):
    """
    The function `extract_clean_text` takes in a string of HTML text, extracts the text content from it
    using BeautifulSoup, and returns the cleaned text.
    
    :param text: The `text` parameter is the input text that you want to extract and clean. It is
    assumed to be a list containing a single string element
    :return: the clean text extracted from the input text.
    """
    text = text[0]
    soup = BeautifulSoup(text, 'html.parser')
    clean_text = soup.get_text()
    return clean_text

def format_datetime(datetime_string):
    """
    Format a datetime string by replacing 'T' with a space.

    Args:
    datetime_string (str): The datetime string to be formatted.

    Returns:
    str: The formatted datetime string.
    """
    formatted_datetime = datetime_string.replace("T", " ")
    return formatted_datetime

