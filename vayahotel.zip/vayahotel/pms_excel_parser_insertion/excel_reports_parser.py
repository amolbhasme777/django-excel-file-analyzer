## Created on: September25th, 2023
## Description: parse and save excel reports
## Author: Tanveer Khan

import pandas as pd
import os
from vayahotel import common_constant as const
import logging
from vayahotel.pms_excel_parser_insertion.Insert_DB_Scripts.insert_into_db import insert_journal_data, insert_distribution_channel_data, insert_distribution_channel_status_data, insert_hotel_status_data, insert_hotel_status_by_booking_type, insert_hotel_status_rooms_data

# Specify the name of the folder you want to create
folder_name = const.CONST_PROTEL_PARSED_EXCEL_REPORT_FOLDER
parsed_excel_reports_folder_path = os.path.join(os.getcwd(), folder_name)

if not os.path.exists(parsed_excel_reports_folder_path):
    os.makedirs(parsed_excel_reports_folder_path)
else:
    logging.info(f"Folder '{folder_name}' already exists at {os.getcwd()}")

def parse_save_invoice_report(excel_file_path, filename, property_id, db_conn, logger):
    # Directory containing your Excel files
    excel_directory = excel_file_path
    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_INVOICE_JPG_SUFFIX
    if filename.startswith(prefix_to_search) and filename.endswith(".xlsx"):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)         
        # Extract the date and time from the file name
        date_time = filename.replace(prefix_to_search, "").replace(".xlsx", "")
        try:
            # Read the Excel file into a pandas DataFrame and skip the header row
            df = pd.read_excel(file_path, header=None, engine=const.CONST_READ_EXCEL_ENGINE)
            result_df = pd.DataFrame()
            
            # Define the column indices you want to extract
            column_indices_to_extract = [1, 3, 4, 12, 13, 14, 18, 21, 22, 26, 27, 29, 31, 35, 37]

            # Iterate through the column indices you want to extract
            for col_index in column_indices_to_extract:
                if col_index < df.shape[1]:
                    # If the column index is valid, copy it to the result DataFrame
                    result_df[df.columns[col_index]] = df.iloc[:, col_index]
                else:
                    # If the column index is out of bounds, fill the result DataFrame with NaN
                    result_df[str(col_index)] = None
                    
            result_df = result_df.dropna(how="all")

            # Drop rows that don"t have a booking_date
            result_df = result_df.dropna(subset=[1], how="all")
                    
            # Function to check if a row contains any of the specified patterns
            def contains_pattern(row):
                return any(pattern in str(row) for pattern in const.CONST_PROTEL_INVOICEJPG_PATTERNTODROP)

            # Filter rows to keep
            filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]

            # Use the DataFrame.drop method to drop rows with the specified values
            filtered_df = filtered_df[~filtered_df.isin(const.CONST_PROTEL_INVOICEJPG_VALUESTODROP).all(axis=1)]

            # Reset the index of the DataFrame after dropping rows
            filtered_df.reset_index(drop=True, inplace=True)

            # Drop column with index 13
            filtered_df = filtered_df.drop(df.columns[13], axis=1)

            # Assign the new column names to the DataFrame
            filtered_df.columns = const.CONST_PROTEL_INVOICEJPG_NEWCOLUMNS
            filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

            # Save the modified DataFrame back to the Excel file
            output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

            # Combine the folder path and Excel file name to create the full path
            excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)
            filtered_df.to_excel(excel_file_path, index=False, header=True)
            
            insert_journal_data(excel_file_path, db_conn, logger)

            logger.info("Data parsed and saved successfully!!")
        
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")

def split_dataframe_by_separator(df, separator, property_id,  property_name):
    separator_indices = df[df.apply(lambda row: separator in str(row), axis=1)].index.tolist()
    split_dataframes = []

    prev_channel_name = None

    for i in range(len(separator_indices)):
        start_idx = separator_indices[i]
        end_idx = separator_indices[i + 1] if i + 1 < len(separator_indices) else None

        # Extract channel name from the row above the separator
        channel_name = df.iloc[start_idx - 1, 0] if start_idx > 0 else None

        # Store the channel name for the current split
        prev_channel_name = channel_name if channel_name else prev_channel_name

        # Create a new DataFrame with the channel name and the data between separators
        split_df = df.iloc[start_idx:end_idx].copy()

        # Add the associated channel name as a new column
        split_df[28] = prev_channel_name
        split_df[29] = property_id
        split_df[30] = property_name

        split_dataframes.append(split_df)

    return split_dataframes

def parse_save_dc_report(excel_file_path, filename, separator, property_id, property_name, db_conn, logger):
    excel_directory = excel_file_path
    prefix_to_search = const.CONST_PROTEL_DC_SUFFIX

    output_dataframes = []  # List to store DataFrames from all sheets
 
    if filename.startswith(prefix_to_search) and filename.endswith(".xlsx"):
        file_path = os.path.join(excel_directory, filename)
        date_time = filename.replace(prefix_to_search, "").replace(".xlsx", "")

        try:
            df = pd.read_excel(file_path, header=None, engine='openpyxl')
            tables = split_dataframe_by_separator(df, separator, property_id, property_name)

            for idx, table in enumerate(tables):
                result_df = pd.DataFrame()
                column_indices_to_extract = [0, 2, 7, 14, 16, 17, 19, 22, 25, 27, 28, 29, 30]

                for col_index in column_indices_to_extract:
                    if col_index < table.shape[1]:
                        result_df[table.columns[col_index]] = table.iloc[:, col_index]
                    else:
                        result_df[str(col_index)] = None
           
                def contains_pattern(row):
                    return any(pattern in str(row) for pattern in const.CONST_PROTEL_DC_PATERN_DROP)

                filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]
                column_name_mapping = {
                    0: "reservation_id",
                    2: "booker",
                    7: "room_id",
                    14: "arrival",
                    16: "departure",
                    17: "room_nights",
                    19: "logis",
                    22: "extras",
                    25: "fandb",
                    27: "total_price",
                    28: "booking_channel",
                    29: "property_id",
                    30: "property_name",
                    
                }
                filtered_df = filtered_df.rename(columns=column_name_mapping)
                output_dataframes.append(filtered_df)

        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")

    # Concatenate all DataFrames into a single DataFrame
    try:
        merged_df = pd.concat(output_dataframes)
        output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX
        excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)
        merged_df.to_excel(excel_file_path, index=False, header=True)

        # Call the insert_distribution_channel_data function
        insert_distribution_channel_data(excel_file_path, db_conn, logger)

        logger.info("Data parsed and saved successfully!!")
    except:
        logger.error("Error in data parsing or empty data ")


def parse_save_dcs_report(excel_file_path, filename, property_id, db_conn, logger):
    # Directory containing your Excel files
    excel_directory = excel_file_path

    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_DC_STATS_SUFFIX
    
    if filename.startswith(prefix_to_search) and filename.endswith(".xlsx"):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)
        
        # Extract the date and time from the file name
        date_time = filename.replace(prefix_to_search, "").replace(".xlsx", "")
        try:
            # Read the Excel file into a pandas DataFrame and skip the header row
            df = pd.read_excel(file_path, header=None, engine=const.CONST_READ_EXCEL_ENGINE)
            
            # # Initialize a DataFrame to store the extracted columns
            result_df = pd.DataFrame()

            # Define the column indices you want to extract
            column_indices_to_extract = [0, 2, 4, 5, 6, 8, 13, 18, 20, 21, 22, 25, 26, 32, 34, 36, 37, 39, 40]  ## [A, C, E, F, G, I, N, S, U, V, W, Z, AA, AG, AI, AK, AL, AN, AO]

            # Iterate through the column indices you want to extract
            for col_index in column_indices_to_extract:
                if col_index < df.shape[1]:
                    # If the column index is valid, copy it to the result DataFrame
                    result_df[df.columns[col_index]] = df.iloc[:, col_index]
                else:
                    # If the column index is out of bounds, fill the result DataFrame with NaN
                    result_df[str(col_index)] = None

            # Drop empty rows (rows with all NaN values)
            result_df = result_df.dropna(how="all")
            
            # Function to check if a row contains any of the specified patterns
            def contains_pattern(row):
                return any(pattern in str(row) for pattern in const.CONST_PROTEL_DCS_PATERN_DROP)

            # Filter rows to keep
            filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]

            # Assign new column names and Define the new column names
            new_column_names = const.CONST_PROTEL_DCS_NEW_COLUMNS

            # # Assign the new column names to the DataFrame
            filtered_df.columns = new_column_names
           
            filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id
            filtered_df["date_"] = const.CONST_END_DATE
          
            # Save the modified DataFrame back to the Excel file
            output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

            # Combine the folder path and Excel file name to create the full path
            excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)

            filtered_df.to_excel(excel_file_path, index=False, header=True)

            # Call the insert_distribution_channel_status_data function
            insert_distribution_channel_status_data(excel_file_path, db_conn, logger)
 
            logger.info("Data parsed and saved successfully!!")
        
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")

def parse_save_hs_report(excel_file_path,filename, property_id, db_conn, logger):
    # Directory containing your Excel files
    excel_directory = excel_file_path

    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_HS_SUFFIX

    if filename.startswith(prefix_to_search) and filename.endswith(".xlsx"):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)
        
        # Extract the date and time from the file name
        date_time = filename.replace(prefix_to_search, "").replace(".xlsx", "")
        try:
            # Read the Excel file into a pandas DataFrame and skip the header row
            df = pd.read_excel(file_path, header=None, engine=const.CONST_READ_EXCEL_ENGINE)

            # # Initialize a DataFrame to store the extracted columns
            result_df = pd.DataFrame()
            # Define the column indices you want to extract
            column_indices_to_extract = [0, 2, 5, 6, 9, 13, 20, 21, 27, 28, 32, 33, 37, 38, 41, 43, 47, 48]  
            # Iterate through the column indices you want to extract
            for col_index in column_indices_to_extract:
                if col_index < df.shape[1]:
                    # If the column index is valid, copy it to the result DataFrame
                    result_df[df.columns[col_index]] = df.iloc[:, col_index]
                else:
                    # If the column index is out of bounds, fill the result DataFrame with NaN
                    result_df[str(col_index)] = None

            # Drop empty rows (rows with all NaN values)
            result_df = result_df.dropna(how="all")

            # # Drop rows that don"t have a booking_date
            # result_df = result_df.dropna(subset=[1], how="all")

            # Define the patterns for the rows to drop
            patterns_to_drop = const.CONST_PROTEL_HS_PATERN_DROP

            # Function to check if a row contains any of the specified patterns
            def contains_pattern(row):
                return any(pattern in str(row) for pattern in patterns_to_drop)

            # Filter rows to keep
            filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]
            #### Assign new column names
            ### Define the new column names
            new_column_names = const.CONST_PROTEL_HS_NEW_COLUMNS
            # Assign the new column names to the DataFrame
            filtered_df.columns = new_column_names
            # Clean and format the "Date" column
            filtered_df["date_"] = filtered_df["date_"].str.replace(r"Do, |Fr, |So, |Si, |Mi, |Mo, |Di, |Sa,", "", regex=True)
            # Strip leading spaces and then convert the "Date" column to the desired format
            filtered_df["date_"] = pd.to_datetime(filtered_df["date_"].str.strip(), format="%d.%m.%Y").dt.strftime("%Y-%m-%d")
            filtered_df[const.CONST_PROTEL_PROPERTY_ID]= property_id

            # Save the modified DataFrame back to the Excel file
            output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

            # Combine the folder path and Excel file name to create the full path
            excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)

            filtered_df.to_excel(excel_file_path, index=False, header=True)

            # Call the insert_hotel_status_data function
            insert_hotel_status_data(excel_file_path, db_conn, logger)
            logger.info("Data parsed and saved successfully!!")
        
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")

def parse_save_hsbt_report(excel_file_path, filename, property_id, db_conn, logger):
    # Directory containing your Excel files
    excel_directory = excel_file_path

    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_HSBT_SUFFIX

    if filename.startswith(prefix_to_search) and filename.endswith(".xlsx"):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)
        
        # Extract the date and time from the file name
        date_time = filename.replace(prefix_to_search, "").replace(".xlsx", "")
        try:
            # Read the Excel file into a pandas DataFrame and skip the header row
            df = pd.read_excel(file_path, header=None, engine=const.CONST_READ_EXCEL_ENGINE)

            # Drop columns with all None values
            df = df.dropna(axis=1, how="all")

            # Define the patterns for the rows to drop
            patterns_to_drop = const.CONST_PROTEL_HSBT_PATERN_DROP

            # Function to check if a row contains any of the specified patterns
            def contains_pattern(row):
                return any(pattern in str(row) for pattern in patterns_to_drop)

            # Filter rows to keep
            filtered_df = df[~df.apply(contains_pattern, axis=1)]

            # Create an empty list to store the formatted data
            formatted_data = []

            # Initialize variables to keep track of the current date
            current_date = None

            # Iterate through the rows in the original DataFrame
            for index, row in filtered_df.iterrows():
                if not pd.isna(row.iloc[0]):
                    current_date = row.iloc[0]
                elif current_date:
                    # Filter out None values in the row
                    filtered_row = [str(cell) if not pd.isna(cell) else "0" for cell in row[1:]]
                    # Append the current date to the beginning of the filtered row
                    formatted_data.append([current_date] + filtered_row)

            # Create a DataFrame from the formatted data
            formatted_df = pd.DataFrame(formatted_data, columns=["Date"] + df.columns[1:].tolist())

            # Specify the column indices you want to drop
            columns_to_drop = [2, 3, 5, 7, 8, 11, 13, 16, 18]

            # Drop the specified columns
            formatted_df.drop(formatted_df.columns[columns_to_drop], axis=1, inplace=True)
            column_name_mapping = {
                2: "Logis",
                5: "FandB",
                7: "Extras",
                10: "Total",
                14: "Room",
                16: "Comp_room",
                19: "House_use_room",
                21: "OoR_rooms",
                23: "Rooms_overall"
            }

            # Clean and format the "Date" column
            formatted_df["Date"] = formatted_df["Date"].str.replace(r"Do, |Fr, |So, |Si, |Mi, |Mo, |Di, |Sa,", "", regex=True)

            # Strip leading spaces and then convert the "Date" column to the desired format
            formatted_df["Date"] = pd.to_datetime(formatted_df["Date"].str.strip(), format="%d.%m.%Y").dt.strftime("%Y-%m-%d")

            # Rename the columns using the mapping dictionary
            formatted_df = formatted_df.rename(columns=column_name_mapping)
            formatted_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

            # Save the modified DataFrame back to the Excel file
            output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

            # Combine the folder path and Excel file name to create the full path
            excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)

            formatted_df.to_excel(excel_file_path, index=False, header=True)

            # Call the insert_hotel_status_by_booking_type function
            insert_hotel_status_by_booking_type(excel_file_path, db_conn, logger)

            # Delete the original Excel file
            #os.remove(file_path)
            logger.info("Data parsed and saved successfully!!")
        
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")

def parse_save_hsr_report(excel_file_path, filename, property_id, db_conn, logger):
    # Directory containing your Excel files
    excel_directory = excel_file_path
    # Prefix to search for in file names
    prefix_to_search = const.CONST_PROTEL_HSBR_SUFFIX
    if filename.startswith(prefix_to_search) and filename.endswith(".xlsx"):
        # Construct the full path to the file
        file_path = os.path.join(excel_directory, filename)
        
        # Extract the date and time from the file name
        date_time = filename.replace(prefix_to_search, "").replace(".xlsx", "")
        try:
            # Read the Excel file into a pandas DataFrame and skip the header row
            df = pd.read_excel(file_path, header=None, engine=const.CONST_READ_EXCEL_ENGINE)
            
            # # Initialize a DataFrame to store the extracted columns
            result_df = pd.DataFrame()

            # Define the column indices you want to extract
            column_indices_to_extract = [0, 1, 2, 3, 4, 9, 12, 14, 16, 20, 23, 25, 26, 28, 29, 31, 33]  ## [A, B, C, D, E, J, M, O, Q, U, X, Z, AA, AC, AD, AF, AH]

            # Iterate through the column indices you want to extract
            for col_index in column_indices_to_extract:
                if col_index < df.shape[1]:
                    # If the column index is valid, copy it to the result DataFrame
                    result_df[df.columns[col_index]] = df.iloc[:, col_index]
                else:
                    # If the column index is out of bounds, fill the result DataFrame with NaN
                    result_df[str(col_index)] = None

            # Drop empty rows (rows with all NaN values)
            result_df = result_df.dropna(how="all")

            # Define the patterns for the rows to drop
            patterns_to_drop = const.CONST_PROTEL_HSBR_PATERN_DROP

            # Function to check if a row contains any of the specified patterns
            def contains_pattern(row):
                return any(pattern in str(row) for pattern in patterns_to_drop)

            # Filter rows to keep
            filtered_df = result_df[~result_df.apply(contains_pattern, axis=1)]

            column_name_mapping = {
                0: "room_type", 
                1: "room_available",
                2: "room_available_percent",
                3: "room_occ",
                4: "room_occ_percent",
                9: "arrival_count",
                12: "arrival_per",
                14: "leave_count",
                16: "leave_per",
                20: "In_house_count",
                23: "In_house_percent",
                25: "logis",
                26: "fandb",
                28: "extras",
                29: "total",
                31: "misc",
                33: "misc_percent"
            }

            # Rename the columns using the mapping dictionary
            filtered_df = filtered_df.rename(columns=column_name_mapping)
            filtered_df[const.CONST_PROTEL_PROPERTY_ID] = property_id

            # Save the modified DataFrame back to the Excel file
            output_file_path = prefix_to_search + date_time + const.CONST_PROTEL_FILTERED_FILE_SUFFIX

            # Combine the folder path and Excel file name to create the full path
            excel_file_path = os.path.join(parsed_excel_reports_folder_path, output_file_path)

            filtered_df.to_excel(excel_file_path, index=False, header=True)

            # Call the insert_hotel_status_data function
            insert_hotel_status_rooms_data(excel_file_path, db_conn, logger)

            logger.info("Data parsed and saved successfully!!")
        
        except Exception as e:
            logger.error(f"Error processing {filename}: {str(e)}")