

import pandas as pd
import mysql.connector
from datetime import datetime
from vayahotel import queries
from vayahotel import common_constant as const

def insert_distribution_channel_data(excel_file_path, db_conn, logger):
    try:
        cursor = db_conn.connection.cursor()  
        # Read Excel froqile into a pandas DataFrame
        df = pd.read_excel(excel_file_path, engine=const.CONST_READ_EXCEL_ENGINE)
        
        for _, row in df.iterrows():
            reservation_id = row[const.CONST_RESERVATION_ID]
            booking_channel = row[const.CONST_BOOKING_CHANNEL]
            arrival_obj = datetime.strptime(row["arrival"], "%d.%m.%Y")
            arrival = arrival_obj.strftime("%Y-%m-%d")
            departure_obj = datetime.strptime(row["departure"], "%d.%m.%Y")
            departure = departure_obj.strftime("%Y-%m-%d")
            property_id = row[const.CONST_PROTEL_PROPERTY_ID]
            property_name = row[const.CONST_PROTEL_PROPERTY_NAME]
            data = (
                property_id,
                property_name,
                reservation_id,
                booking_channel,
                row[const.CONST_BOOKER],
                row[const.CONST_ROOM_ID], 
                arrival,
                departure,
                row[const.CONST_ROOM_NIGHTS],
                row[const.CONST_LOGIS],
                row[const.CONST_EXTRAS],
                row[const.CONST_FANDB],
                row[const.CONST_TOTAL_PRICE]
            )

            # Check if the record already exists
            check_sql = queries.GET_PROTEL_DC_DATA
            cursor.execute(check_sql, (reservation_id,))
            count = cursor.fetchone()[0]
   
            if count == 0:
                insert_sql = queries.INSERT_PROTEL_DC_DATA
                cursor.execute(insert_sql, data)
            else:
                # Record already exists, insert it into duplicate_dist_channel
                duplicate_insert_sql = queries.INSERT_PROTEL_DC_HISTORY_DATA
                cursor.execute(duplicate_insert_sql, data)

        # Commit the changes and close the connection
        db_conn.connection.commit()
        cursor.close()
        # db_conn.close()
        logger.info("Data insertion completed!")

    except mysql.connector.Error as err:
        logger.error("Error in database insertion:", err)


def insert_distribution_channel_status_data(excel_file_path, db_conn, logger):
    try:
        cursor = db_conn.connection.cursor()  

        # Read Excel file into a pandas DataFrame
        df = pd.read_excel(excel_file_path, engine=const.CONST_READ_EXCEL_ENGINE)

        # Loop through the DataFrame and insert rows into the MySQL table
        for _, row in df.iterrows():
            data = (
                row[const.CONST_PROTEL_PROPERTY_ID],
                row[const.CONST_BOOKING_CHANNEL], 
                row[const.CONST_DATE_],
                row[const.CONST_NIGHT_ROOMS_DAY],
                row[const.CONST_GUESTS_DAY],
                row[const.CONST_TOTAL_SALES_DAY],
                row[const.CONST_SALES_ROOMS_DAY], 
                row[const.CONST_LOGIS_DAY],
                row[const.CONST_LOGIS_ROOMS_DAY],
                row[const.CONST_NIGHTS_ROOMS_MONTH],
                row[const.CONST_GUESTS_MONTH], 
                row[const.CONST_TOTAL_SALES_MONTH], 
                row[const.CONST_SALES_ROOMS_MONTH],
                row[const.CONST_LOGIS_MONTH],
                row[const.CONST_LOGIS_ROOMS_MONTH],
                row[const.CONST_NIGHTS_ROOMS_YEAR], 
                row[const.CONST_GUESTS_YEAR],
                row[const.CONST_TOTAL_SALES_YEAR],
                row[const.CONST_SALES_ROOMS_YEAR],
                row[const.CONST_LOGIS_YEAR],
                row[const.CONST_LOGIS_ROOMS_YEAR]
            )

            check_sql = queries.CHECK_DUPLICATE_PROTEL_DCS_DATA
            cursor.execute(check_sql, data)
            count = cursor.fetchone()[0]
            
            if count == 0:
                # Insert the data if no duplicates are found
                insert_sql = queries.INSERT_PROTEL_DC_STATS_DATA
                cursor.execute(insert_sql, data)
                logger.info("DCS data inserted successfully.")
            else:
                duplicate_insert_sql = queries.INSERT_PROTEL_DC_STATS_HISTORY_DATA
                cursor.execute(duplicate_insert_sql, data)
                logger.info("Duplicate DCS data inserted into history table")
         

        # Commit the changes and close the connection
        db_conn.connection.commit()
        cursor.close()
        logger.info("Data insertion completed!")

    except mysql.connector.Error as err:
        logger.error("Error in database insertion:", err)



def insert_hotel_status_data(excel_file_path, db_conn, logger):
    try:
        # Create a cursor object
        cursor = db_conn.connection.cursor()  

        # Read Excel file into a pandas DataFrame
        df = pd.read_excel(excel_file_path, engine=const.CONST_READ_EXCEL_ENGINE)

        # Loop through the DataFrame and insert rows into the MySQL table
        for _, row in df.iterrows():
            data = (
                row[const.CONST_PROTEL_PROPERTY_ID],
                row[const.CONST_DATE_],	
                row[const.CONST_ROOMS_FREE],
                row[const.CONST_ROOMS_FREE_PERCENTAGE],	
                row[const.CONST_ROOMS_OCC],	
                row[const.CONST_ROOMS_OCC_PERCENTAGE],	
                row[const.CONST_BEDS_PERCENTAGE],
                row[const.CONST_ARRIVAL_ROOMS_COUNT],
                row[const.CONST_ARRIVAL_PERSONS_COUNT],	
                row[const.CONST_LEAVE_ROOMS_COUNT],	
                row[const.CONST_LEAVE_PERSONS_COUNT],
                row[const.CONST_INHOUSE_BEDS],	
                row[const.CONST_INHOUSE_PERSONS],
                row[const.CONST_LOGIS],	
                row[const.CONST_FANDB],	
                row[const.CONST_EXTRAS],	
                row[const.CONST_TOTAL],
                row[const.CONST_MISC_COUNT],	
                row[const.CONST_MISC_PERCENTAGE]
            )
            check_sql = queries.CHECK_DUPLICATE_PROTEL_HS_DATA
            cursor.execute(check_sql, data)
            count = cursor.fetchone()[0]
            
            if count == 0:
                # Insert the data if no duplicates are found
                insert_sql = queries.INSERT_PROTEL_HS_DATA
                cursor.execute(insert_sql, data)
                logger.info("HS data inserted successfully.")
            else:
                duplicate_insert_sql = queries.INSERT_PROTEL_HS_HISTORY_DATA
                cursor.execute(duplicate_insert_sql, data)
                logger.info("Duplicate HS data inserted into history table")
          
        # Commit the changes and close the connection
        db_conn.connection.commit()
        cursor.close()
        logger.info("Data insertion completed!")

    except mysql.connector.Error as err:
        logger.error("Error in database insertion:", err)


def insert_hotel_status_by_booking_type(excel_file_path, db_conn, logger):
    try:
        # Create a cursor object
        cursor = db_conn.connection.cursor()

        # Read Excel file into a pandas DataFrame
        df = pd.read_excel(excel_file_path, engine=const.CONST_READ_EXCEL_ENGINE)

        # Loop through the DataFrame and insert rows into the MySQL table
        for _, row in df.iterrows():
            data = (
                row[const.CONST_PROTEL_PROPERTY_ID],
                row["Date"],
                row[const.CONST_LOGIS.capitalize()],
                row["FandB"],
                row[const.CONST_EXTRAS.capitalize()],
                row[const.CONST_TOTAL.capitalize()],
                row["Room"],
                row["Comp_room"],
                row["House_use_room"],
                row["OoR_rooms"],
                row["Rooms_overall"]
            )
            check_sql = queries.CHECK_DUPLICATE_PROTEL_HSBT_DATA
            cursor.execute(check_sql, data)
            count = cursor.fetchone()[0]
            if count == 0:
                # Insert the data if no duplicates are found
                insert_sql = queries.INSERT_PROTEL_HSBT_DATA
                cursor.execute(insert_sql, data)
                logger.info("HSBT data inserted successfully.")
            else:
                duplicate_insert_sql = queries.INSERT_PROTEL_HSBT_HISTORY_DATA
                cursor.execute(duplicate_insert_sql, data)
                logger.info("Duplicate HSBT data inserted into history table")
       

        # Commit the changes and close the connection
        db_conn.connection.commit()
        cursor.close()
        logger.info("Data insertion completed!")

    except mysql.connector.Error as err:
        logger.error("Error in database insertion:", err)



def insert_hotel_status_rooms_data(excel_file_path, db_conn, logger):
    try:
        # Create a cursor object
        cursor = db_conn.connection.cursor()  

        # Read Excel file into a pandas DataFrame
        df = pd.read_excel(excel_file_path, engine=const.CONST_READ_EXCEL_ENGINE)

        # Loop through the DataFrame and insert rows into the MySQL table
        for _, row in df.iterrows():
            data = (
                row[const.CONST_PROTEL_PROPERTY_ID],
                row["room_type"], 
                row["room_available"],
                row["room_available_percent"],
                row["room_occ"],
                row["room_occ_percent"],
                row["arrival_count"],
                row["arrival_per"],
                row["leave_count"],
                row["leave_per"],
                row["In_house_count"],
                row["In_house_percent"],
                row[const.CONST_LOGIS],
                row[const.CONST_FANDB],
                row[const.CONST_EXTRAS],
                row[const.CONST_TOTAL],
                row["misc"],
                row["misc_percent"]
            )

            check_sql = queries.CHECK_DUPLICATE_PROTEL_HSBR_DATA
            cursor.execute(check_sql, data)
            count = cursor.fetchone()[0]
            if count == 0:
                # Insert the data if no duplicates are found
                insert_sql = queries.INSERT_PROTEL_HSBR_DATA
                cursor.execute(insert_sql, data)
                logger.info("HSBR data inserted successfully.")
            else:
                duplicate_insert_sql = queries.INSERT_PROTEL_HSBR_HISTORY_DATA
                cursor.execute(duplicate_insert_sql, data)
                logger.info("Duplicate HSBR data inserted into history table")

        # Commit the changes and close the connection
        db_conn.connection.commit()
        cursor.close()
        logger.info("Data insertion completed!")

    except mysql.connector.Error as err:
        logger.error("Error in database insertion:", err)



def insert_journal_data(excel_file_path, db_conn, logger):
    try:
        # Create a cursor object
        cursor = db_conn.connection.cursor()  

        # Read Excel file into a pandas DataFrame
        df = pd.read_excel(excel_file_path, engine=const.CONST_READ_EXCEL_ENGINE)

        # Loop through the DataFrame and insert rows into the MySQL table
        for _, row in df.iterrows():
            data = (
                None if pd.isna(row[const.CONST_PROTEL_PROPERTY_ID]) else row[const.CONST_PROTEL_PROPERTY_ID], 
                None if pd.isna(row["booking_date"]) else row["booking_date"],          
                None if pd.isna(row["invoice_id"]) else row["invoice_id"],
                None if pd.isna(row["invoice"]) else row["invoice"],
                None if pd.isna(row[const.CONST_RESERVATION_ID]) else row[const.CONST_RESERVATION_ID],
                None if pd.isna(row["nights"]) else row["nights"],
                None if pd.isna(row["booking_text"]) else row["booking_text"],
                None if pd.isna(row["e_price"]) else row["e_price"],
                None if pd.isna(row[const.CONST_TOTAL]) else row[const.CONST_TOTAL],
                None if pd.isna(row["misc"]) else row["misc"],
                None if pd.isna(row[const.CONST_ROOM_ID]) else row[const.CONST_ROOM_ID],
                None if pd.isna(row["room_type"]) else row["room_type"],
                None if pd.isna(row["guest"]) else row["guest"],
                None,  # row[arrival],
                None  # row["departure"]
            )

            check_sql = queries.CHECK_DUPLICATE_PROTEL_INVOICE_JPG_DATA
            cursor.execute(check_sql, data)
            count = cursor.fetchone()[0]
            if count == 0:
                # Insert the data if no duplicates are found
                insert_sql = queries.INSERT_PROTEL_INVOICE_JPG_DATA
                cursor.execute(insert_sql, data)
                logger.info("Invoice data inserted successfully.")
            else:
                duplicate_insert_sql = queries.INSERT_PROTEL_INVOICE_JPG_HISTORY_DATA
                cursor.execute(duplicate_insert_sql, data)
                logger.info("Duplicate invoice_jpg data inserted into history table")

        db_conn.connection.commit()
        cursor.close()
        logger.info("Data insertion completed!")

    except mysql.connector.Error as err:
        logger.error("Error in database insertion:", err)