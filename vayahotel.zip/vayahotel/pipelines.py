# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
import logging
from datetime import datetime

import mysql.connector
from mysql.connector import Error

from vayahotel.items import ProviderItem, PropertyItem, OfferItem
from vayahotel import config
import vayahotel.common_constant as const
from vayahotel import queries

logging.basicConfig(filename="output.log", level=logging.DEBUG)


# The VayahotelPipeline class establishes a connection to a MySQL database using the provided
# configuration parameters.
class VayahotelPipeline:
    def __init__(self):
        try:
            HOSTNAME = config.HOSTNAME
            USERNAME = config.USERNAME
            PASSWORD = config.PASSWORD
            DATABASE = config.DATABASE

            self.connection = mysql.connector.connect(
                host=HOSTNAME, user=USERNAME, password=PASSWORD, database=DATABASE
            )
        except Error as connection_error:
            logging.Logger.error(f"Error while connecting to MySQL: {connection_error}")

    def process_item(self, item, spider):
        """
        The `process_item` function processes different types of items and assigns IDs to them based on
        their type.
        
        :param item: The `item` parameter is an object that represents the data being scraped by the spider.
        It could be an instance of `ProviderItem`, `PropertyItem`, or `OfferItem`, depending on the type of
        data being processed
        :param spider: The `spider` parameter is an instance of the spider class that is currently running.
        It is used to access spider-specific attributes and methods
        :return: The variable "item" is being returned.
        """
        global provider_id, proprerty_id
        try:
            if isinstance(item, ProviderItem):
                provider_id = self.process_provider_item(item)
            if isinstance(item, PropertyItem) and provider_id:
                proprerty_id = self.process_property_item(item, provider_id)
            if isinstance(item, OfferItem) and proprerty_id:
                offer_id = self.process_offer_item(item, provider_id, proprerty_id)

        except TypeError:
            logging.Logger.error("Invalid item type")

        return item

    def process_provider_item(self, item):
        """
        The function `process_provider_item` checks if a provider already exists in a database and
        inserts it if it doesn't.
        
        :param item: The `item` parameter is a dictionary that contains information about a provider. It
        is expected to have the following keys:
        :return: The function `process_provider_item` returns the `provider_id` value.
        """
        try:
            self.cur = self.connection.cursor()
            self.cur.execute(
                queries.GET_PROVIDER_QUERY, (item[const.CONST_PIPELINE_PROVIDER],)
            )
            existing_provider = self.cur.fetchone()
            if existing_provider:
                provider_id = existing_provider[0]
                return provider_id
            else:
                self.cur.execute(
                    queries.INSERT_PROVIDER_QUERY,
                    (
                        item[const.CONST_PIPELINE_PROVIDER],
                        item[const.CONST_PIPELINE_PROVIDER_DESCRIPTION],
                        item[const.CONST_PIPELINE_PROVIDER_URL],
                        const.CONST_PIPELINE_CREATED_BY,
                        const.CONST_PIPELINE_MODIFIED_BY,
                    ),
                )
                self.connection.commit()
                provider_id = self.cur.lastrowid
                return provider_id
        except Error as provider_item_error:
            logging.logger.error(
                f"Error while processing provider item: {provider_item_error}"
            )

    def process_location_item(self, country, city, region, country_slug, region_slug, city_slug):
        """
        The function processes a location item by checking if it already exists in the database and
        either returns its ID or inserts a new location item and returns its ID.
        
        :param country: The country parameter represents the name of the country where the location is
        located
        :param city: The city parameter represents the name of the city
        :param region: The "region" parameter represents the region or state of the location
        :param country_slug: The parameter "country_slug" is a string that represents the slug (a
        URL-friendly version) of the country name. It is used as a unique identifier for the country in
        the database
        :param region_slug: The parameter "region_slug" is a string that represents the slug (a
        URL-friendly version) of the region. It is used as a unique identifier for the region in the
        database
        :param city_slug: The `city_slug` parameter is a string that represents a unique identifier for
        the city. It is typically used in URLs or database queries to identify a specific city
        :return: the location ID.
        """
        try:
            self.cur = self.connection.cursor()

            self.cur.execute(queries.GET_LOCATION_QUERY, (city, region, country))
            existing_location = self.cur.fetchone()

            if existing_location:
                location_id = existing_location[0]
                return location_id
            else:
                self.cur.execute(
                    queries.INSERT_LOCATION_QUERY,
                    (
                        None,
                        city,
                        city_slug,
                        None,
                        region,
                        region_slug,
                        None,
                        country,
                        country_slug,
                        const.CONST_PIPELINE_CREATED_BY,
                        const.CONST_PIPELINE_MODIFIED_BY,
                    ),
                )
                self.connection.commit()
                location_id = self.cur.lastrowid
                return location_id

        except Error as location_item_error:
            logging.logger.error(
                f"Error while processing location item: {location_item_error}"
            )

    def process_property_item(self, item, provider_id):
        """
        The function `process_property_item` processes a property item by retrieving provider
        information, location information, and existing property information from a database, and then
        either updating the existing property or inserting a new property into the database.
        
        :param item: The `item` parameter is a dictionary that contains various properties of a property
        item. It is used to extract information such as the provider, country, region, city, property
        name, property URL, property description, accommodation type, property address, and other
        details related to the property
        :param provider_id: The provider_id is the ID of the provider associated with the property item.
        It is used to link the property item to a specific provider in the database
        :return: the property ID (proprerty_id) after processing the property item.
        """
        self.cur = self.connection.cursor()
        provider = item[const.CONST_PIPELINE_PROVIDER]
        self.cur.execute(queries.GET_PROVIDER_QUERY, (provider,))
        row = self.cur.fetchone()
        if row is not None:
            provider_id = row[0]
        else:
            provider_id = None

        country_slug = item[const.CONST_PIPLEINE_COUNTRY_SLUG]
        country = item[const.CONST_PIPLEINE_COUNTRY_NL]
        region = item[const.CONST_PIPLEINE_REGION_NL]
        region_slug = item[const.CONST_PIPLEINE_REGION_SLUG]
        city = item[const.CONST_PIPLEINE_CITY_NL]
        city_slug = item[const.CONST_PIPLEINE_CITY_SLUG]

        location_id = self.process_location_item(
            country, city, region, country_slug, region_slug, city_slug
        )

        try:
            self.cur = self.connection.cursor()

            self.cur.execute(
                queries.GET_PROPERTY_QUERY,
                (
                    item[const.CONST_PIPELINE_PROPERTY_NL],
                    item[const.CONST_PIPELINE_PROPERTY_URL],
                ),
            )
            existing_property = self.cur.fetchone()
            if existing_property:
                proprerty_id = existing_property[0]
                return proprerty_id
            else:
                self.cur.execute(
                    queries.INSERT_PROPERTY_QUERY,
                    (
                        provider_id,
                        location_id,
                        item[const.CONST_PIPELINE_MAPPED_PROPERTY_CODE],
                        None,
                        item[const.CONST_PIPELINE_PROPERTY_NL],
                        item[const.CONST_PIPELINE_PROPERTY_SLUG],
                        item[const.CONST_PIPELINE_PROPERTY_DESCRIPTION],
                        item[const.CONST_PIPELINE_PROPERTY_CODE],
                        item[const.CONST_PIPELINE_PROPERTY_URL],
                        item[const.CONST_PIPELINE_PORPERTY_ACCOMDATION_TYPE],
                        item[const.CONST_PIPELINE_PROPERTY_ADDRESS],
                        const.CONST_PIPELINE_CREATED_BY,
                        const.CONST_PIPELINE_MODIFIED_BY,
                        None,
                    ),
                )
                self.connection.commit()
                proprerty_id = self.cur.lastrowid
                return proprerty_id

        except Error as property_item_error:
            logging.logger.error(
                f"Error while processing property item: {property_item_error}"
            )

    def get_existing_offer_id(self, property_id, meal_code, mapped_property_code, offer_per_person, price_package,
                              occupancy, room_type, room_des, duration, arrival_date, flightId_inbound,
                              departure_date_time_inbound, arrival_date_time_inbound, arrival_date_time_outbound,
                              departure_datetime_outbound):
        """
        The function `get_existing_offer_id` retrieves the existing offer ID based on various
        parameters.
        
        :param property_id: The ID of the property for which the offer is being searched
        :param meal_code: The meal code is a code that represents the type of meal included in the offer
        :param mapped_property_code: The mapped_property_code parameter is a code that is used to
        identify a specific property. It is typically a unique identifier assigned to each property in a
        system
        :param offer_per_person: The offer_per_person parameter represents the number of people for whom
        the offer is applicable
        :param price_package: The parameter "price_package" refers to the package or rate at which the
        room is being offered. It could be a specific price or a package deal that includes additional
        services or amenities
        :param occupancy: The occupancy parameter refers to the number of people that can occupy a room.
        It typically represents the maximum number of guests that a room can accommodate
        :param room_type: The parameter "room_type" refers to the type of room that is being requested
        or searched for. It could be a single room, double room, suite, etc
        :param room_des: The parameter "room_des" refers to the description of the room. It is used as a
        filter to find an existing offer ID in the database
        :param duration: The duration parameter represents the length of stay in days
        :param arrival_date: The arrival date of the offer
        :return: the existing offer ID if it exists in the database, otherwise it returns None.
        """
        self.cur.execute(queries.GET_OFFER_ID, (
            property_id, mapped_property_code, offer_per_person, price_package, occupancy, room_type, room_des,
            duration, arrival_date, meal_code, flightId_inbound, departure_date_time_inbound, arrival_date_time_inbound,
            arrival_date_time_outbound, departure_datetime_outbound))
        row = self.cur.fetchone()
        if row is not None:
            existing_offer_id = row[0]
            return existing_offer_id
        return None

    def process_offer_item(self, item, provider_id, proprerty_id):
        """
        The function `process_offer_item` processes an offer item by inserting it into a database table
        and returning the offer ID.
        
        :param item: The "item" parameter is a dictionary that contains various properties of an offer
        item. These properties include:
        :param provider_id: The `provider_id` parameter is the ID of the provider associated with the
        offer item
        :param proprerty_id: The `proprerty_id` parameter is the ID of the property associated with the
        offer item
        :return: the offer_id.
        """
        try:
            self.cur = self.connection.cursor(buffered=True)
            property_url = item[const.CONST_PIPELINE_PROPERTY]
            self.cur.execute(queries.GET_PROPERTY_ID_FROM_PROPERTY_URL, (property_url,))

            row = self.cur.fetchone()
            if row is not None:
                property_id = row[0]

            else:
                property_id = None

            mapped_property_code = item[const.CONST_PIPELINE_MAPPED_PROPERTY_CODE]
            offer_per_person = item[const.CONST_PIPELINE_OFFER_PER_PERSON]
            price_package = item[const.CONST_PIPELINE_PRICE_PACKAGE]
            meal_code = item[const.CONST_PIPELINE_MEAL_CODE]
            occupancy = item[const.CONST_PIPELINE_OCCUPANCY]
            room_type = item[const.CONST_PIPELINE_ROOM_TYPE]
            room_des = item[const.CONST_PIPELINE_ROOM_DESCRIPTION]
            duration = item[const.CONST_PIPELINE_DURATION]
            arrival_date = item[const.CONST_PIPELINE_ARRIVAL_DATE]
            flightId_inbound = item[const.CONST_PIPELINE_FLIGHTID_INBOUND]
            departure_date_time_inbound = item[const.CONST_PIPELINE_DEPARTURE_DATE_TIME_INBOUND]
            arrival_date_time_inbound = item[const.CONST_PIPELINE_ARRIVAL_DATE_TIME_INBOUND]
            arrival_date_time_outbound = item[const.CONST_PIPELINE_ARRIVAL_DATE_TIME_OUTBOUND]
            departure_datetime_outbound = item[const.CONST_PIPELINE_DEPARTURE_DATETIME_OUTBOUND]

            existing_offer_id = self.get_existing_offer_id(property_id, meal_code, mapped_property_code,
                                                           offer_per_person, price_package, occupancy, room_type,
                                                           room_des, duration, arrival_date, flightId_inbound,
                                                           departure_date_time_inbound, arrival_date_time_inbound,
                                                           arrival_date_time_outbound, departure_datetime_outbound)

            if existing_offer_id is not None:

                self.cur.execute(
                    queries.INSERT_OFFER_HISTORY_QUERY,
                    (
                        property_id,
                        item[const.CONST_PIPELINE_MAPPED_PROPERTY_CODE],
                        item[const.CONST_PIPELINE_OFFER_PER_PERSON],
                        item[const.CONST_PIPELINE_PRICE_PACKAGE],
                        item[const.CONST_PIPELINE_OFFER_BRAND],
                        item[const.CONST_PIPELINE_PACKAGE],
                        item[const.CONST_PIPELINE_MEAL_CODE],
                        item[const.CONST_PIPELINE_MEAL_CODE_LABEL],
                        item[const.CONST_PIPELINE_DURATION],
                        item[const.CONST_PIPELINE_OCCUPANCY],
                        item[const.CONST_PIPELINE_ARRIVAL_DATE],
                        item[const.CONST_PIPELINE_FREE_CANCELLATION_DEADLINE],
                        item[const.CONST_PIPELINE_NON_REFUNDABLE],
                        item[const.CONST_PIPELINE_ON_REQUEST],
                        item[const.CONST_PIPELINE_WITHOUT_PAYEMENT],
                        item[const.CONST_PIPELINE_CANCELLATION],
                        item[const.CONST_PIPELINE_GUARANTEES],
                        item[const.CONST_PIEPLINE_TAXES],
                        item[const.CONST_PIPELINE_PETS],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_CODE],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL],
                        item[const.CONST_PIPELINE_PACKAGE_PROVIDER],
                        item[const.CONST_PIPELINE_FLIGHTID_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_DATE_TIME_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_CODE_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_TIMEZONE_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_DATE_TIME_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_CODE_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_TIMEZONE_INBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_CODE_INBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_CARRIER_CODE_INBOUND],
                        item[const.CONST_PIPELINE_CARRIER_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_NUMBER_INBOUND],
                        item[const.CONST_PIPELINE_DURATION_MINUTES_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_DATETIME_OUTBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_TIMEZONE_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_DATE_TIME_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_CARRIER_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_CARRIER_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_NUMBER_OUTBOUND],
                        item[const.CONST_PIPELINE_DURATION_MINUTES_OUTBOUND],
                        item[const.CONST_PIPELINE_ROOM_TYPE],
                        item[const.CONST_PIPELINE_ROOM_DESCRIPTION],
                        None,
                        const.CONST_PIPELINE_MODIFIED_BY,
                        const.CONST_PIPELINE_CREATED_BY,
                    ),
                )
                self.connection.commit()
                offer_id = self.cur.lastrowid
                return offer_id
            else:
                self.cur.execute(
                    queries.INSERT_OFFER_QUERY,
                    (
                        property_id,
                        item[const.CONST_PIPELINE_MAPPED_PROPERTY_CODE],
                        item[const.CONST_PIPELINE_OFFER_PER_PERSON],
                        item[const.CONST_PIPELINE_PRICE_PACKAGE],
                        item[const.CONST_PIPELINE_OFFER_BRAND],
                        item[const.CONST_PIPELINE_PACKAGE],
                        item[const.CONST_PIPELINE_MEAL_CODE],
                        item[const.CONST_PIPELINE_MEAL_CODE_LABEL],
                        item[const.CONST_PIPELINE_DURATION],
                        item[const.CONST_PIPELINE_OCCUPANCY],
                        item[const.CONST_PIPELINE_ARRIVAL_DATE],
                        item[const.CONST_PIPELINE_FREE_CANCELLATION_DEADLINE],
                        item[const.CONST_PIPELINE_NON_REFUNDABLE],
                        item[const.CONST_PIPELINE_ON_REQUEST],
                        item[const.CONST_PIPELINE_WITHOUT_PAYEMENT],
                        item[const.CONST_PIPELINE_CANCELLATION],
                        item[const.CONST_PIPELINE_GUARANTEES],
                        item[const.CONST_PIEPLINE_TAXES],
                        item[const.CONST_PIPELINE_PETS],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_CODE],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL],
                        item[const.CONST_PIPELINE_PACKAGE_PROVIDER],
                        item[const.CONST_PIPELINE_FLIGHTID_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_DATE_TIME_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_CODE_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_TIMEZONE_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_DATE_TIME_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_CODE_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_TIMEZONE_INBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_CODE_INBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_CARRIER_CODE_INBOUND],
                        item[const.CONST_PIPELINE_CARRIER_LABEL_INBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_NUMBER_INBOUND],
                        item[const.CONST_PIPELINE_DURATION_MINUTES_INBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_DATETIME_OUTBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_DEPARTURE_AIRPORT_TIMEZONE_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_DATE_TIME_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_ARRIVAL_AIRPORT_TIMEZONE_OUTBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_CLASS_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_CARRIER_CODE_OUTBOUND],
                        item[const.CONST_PIPELINE_CARRIER_LABEL_OUTBOUND],
                        item[const.CONST_PIPELINE_FLIGHT_NUMBER_OUTBOUND],
                        item[const.CONST_PIPELINE_DURATION_MINUTES_OUTBOUND],
                        item[const.CONST_PIPELINE_ROOM_TYPE],
                        item[const.CONST_PIPELINE_ROOM_DESCRIPTION],
                        None,
                        const.CONST_PIPELINE_MODIFIED_BY,
                        const.CONST_PIPELINE_CREATED_BY,
                    ),
                )
                self.connection.commit()
                offer_id = self.cur.lastrowid
                return offer_id

        except Error as offer_item_error:
            logging.logger.error(
                f"Error while processing offer item: {offer_item_error}"
            )

        finally:
            if hasattr(self, "cur"):
                # Only fetch the results if needed
                if self.cur.description is not None:
                    self.cur.fetchall()
                self.cur.close()

    def close_spider(self, spider):
        """
        The `close_spider` function is used to close the MySQL connection and cursor if they exist, and
        prints an error message if there is an error while closing the connection.
        
        :param spider: The `spider` parameter is an instance of the spider class that is being closed. In
        the context of web scraping, a spider is a program or script that automatically navigates through
        websites and extracts data
        """
        try:
            if hasattr(self, "cur"):
                self.cur.close()
            if hasattr(self, "connection"):
                self.connection.close()
        except Error as e:
            print(f"Error while closing MySQL connection: {e}")


logging.debug("This message will be logged in output.log")
