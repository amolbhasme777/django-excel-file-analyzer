import os
from datetime import datetime, timedelta
import pandas as pd
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.utils.dataframe import dataframe_to_rows
from database_connection import DatabaseConnection
import logging
import common_constant as const
import queries
from send_email import send_mail

logging.basicConfig(
    level=logging.INFO, format="%(asctime)s - %(levelname)s - %(message)s"
)


# The StaffingInputGenerator class is used to generate an input file for staffing purposes.
class StaffingInputGenerator:
    def __init__(self, file_name=const.CONST_FILE_NAME):
        self.file_name = file_name
        if os.path.exists(self.file_name):
            os.remove(self.file_name)
        self.wb = Workbook()
        self.cursor = None
        self.db_conn = None

    def fetch_count(self, i, booking_text, prop_id):
        """
        The function fetches a count from the database based on the provided parameters.

        :param i: The parameter "i" is used as a placeholder for an integer value. It is likely used to
        specify a specific index or position in a list or array
        :param booking_text: The `booking_text` parameter is a string that represents the booking text
        used to filter the count in the database
        :param prop_id: The `prop_id` parameter is used to identify a specific property in the database.
        It is likely a unique identifier for a property, such as an integer or a string
        :return: the count fetched from the database based on the provided parameters.
        """
        """Fetch count from the database based on the provided parameters."""
        self.cursor.execute(queries.query_for_fetch_count.format(column_name = booking_text), (i, prop_id))
        return self.cursor.fetchone()[const.CONST_ZERO]

    def initialize_database_connection(self):
        """
        The function initializes a database connection and cursor, and logs an error if there is an
        exception.
        """
        """Initialize database connection and cursor."""
        try:
            self.db_conn = DatabaseConnection()
            self.cursor = self.db_conn.connection.cursor()
        except Exception as database_error:
            logging.error(f"Error initializing database connection: {database_error}")
            raise

    def generate_input_file(self):
        """
        The function `generate_input_file` generates an Excel file with staffing input based on database
        queries and data manipulation.
        """
        """Generate the staffing input Excel file."""
        try:
            self.initialize_database_connection()

            # Workbook creation and other setups
            ws = self.wb.active
            ws.title = const.CONST_DATES

            start_date = datetime.now()
            end_date = start_date + timedelta(days=const.CONST_SIX)

            headers = const.CONST_HEADERS
            for col_num, header in enumerate(headers, const.CONST_ONE):
                col_letter = get_column_letter(col_num)
                ws[f"{col_letter}1"] = header

            for i in range(const.CONST_ONE, const.CONST_EIGHT):
                day = f"day {i}"
                date_value = (
                    start_date + timedelta(days=i - const.CONST_ONE)
                ).strftime("%d-%m-%Y")
                ws[f"A{i + const.CONST_ONE}"] = day
                ws[f"B{i + const.CONST_ONE}"] = date_value

            ws_weights = self.wb.create_sheet(title=const.CONST_WEIGHTS)
            headers_weights = const.CONST_HEADERS_WEIGHTS
            for col_num, header in enumerate(headers_weights, 1):
                col_letter = get_column_letter(col_num)
                ws_weights[f"{col_letter}1"] = header

            weight_data = const.CONST_WEIGHT_DATA

            for row_num, (model, weight) in enumerate(weight_data, const.CONST_TWO):
                ws_weights[f"A{row_num}"] = model
                ws_weights[f"B{row_num}"] = weight

            self.cursor.execute(queries.query_for_hotel_details)
            data_for_hotel = self.cursor.fetchall()

            hotel_mapping = const.CONST_HOTEL_MAPPING

            processed_data = [
                (
                    int(
                        str(id_name[const.CONST_ZERO])
                        .split(const.CONST_HYPHEN)[const.CONST_ZERO]
                        .strip()
                    ),
                    id_name[const.CONST_ONE]
                    .split(const.CONST_HYPHEN)[const.CONST_ONE]
                    .strip(),
                )
                for id_name in data_for_hotel
            ]
            updated_data = [
                (id_val, hotel_mapping.get(hotel_name, hotel_name))
                for id_val, hotel_name in processed_data
            ]
            result_df = pd.DataFrame()
            vfb = self.wb.create_sheet(title="Data")
            for prop_id, sheet_name in updated_data:
                complete_date_range = pd.date_range(
                    start_date, periods=const.CONST_SEVEN
                ).to_frame(index=False, name=const.CONST_DATE)

                complete_date_list = complete_date_range[const.CONST_DATE].dt.date
                prop_id_tuple = (
                    prop_id,
                    prop_id,
                )
                self.cursor.execute(queries.query_for_hotel_status, prop_id_tuple)
                columns = [
                    column[const.CONST_ZERO] for column in self.cursor.description
                ]
                data = self.cursor.fetchall()
                
                self.cursor.execute(queries.query_for_hotel_status_all, prop_id_tuple)
                columns_all = [
                    column[const.CONST_ZERO] for column in self.cursor.description
                ]
                data_all = self.cursor.fetchall()
                
                data_all_df = pd.DataFrame(data_all, columns=columns_all)

                # Add a new column 'property_name' with the corresponding sheet_name value
                data_all_df['Hotel'] = sheet_name
                data_all_df['Date'] = pd.to_datetime(data_all_df['Date'], errors='coerce')
                data_all_df['Date'] = data_all_df['Date'].dt.date
                data_all_df['Week'] = data_all_df['Date'].apply(lambda x: x.isocalendar()[1])
                data_all_df['Year'] = data_all_df['Date'].apply(lambda x: x.isocalendar()[0])

                # Append the current data_all_df to the result_df
                result_df = pd.concat([result_df, data_all_df], ignore_index=True)    

                len_data = len(data)
                if len_data > const.CONST_SEVEN:
                    continue
                if len_data <= const.CONST_SEVEN:
                    existing_dates = [row[const.CONST_ZERO] for row in data]

                    missing_dates = [
                        date
                        for date in complete_date_list
                        if date not in existing_dates
                    ]

                    default_values = (None, None, None, None, None, None)

                    for missing_date in missing_dates:
                        data.append((missing_date,) + default_values)

                results_halfboard = [
                    self.fetch_count(i, const.CONST_HALBPENSION, prop_id) or 0
                    for i in range(const.CONST_SEVEN)
                ]

                results_breakfast = [
                    self.fetch_count(i, const.CONST_FRUHSTUCK, prop_id) or 0
                    for i in range(const.CONST_SEVEN)
                ]

                df = pd.DataFrame(data, columns=columns)
                df_len = len(df)
                if df_len > const.CONST_SEVEN:
                    continue
                df[const.CONST_BREAKFASTS] = results_breakfast
                df[const.CONST_HALFBOARDS] = results_halfboard
                df[const.CONST_DATE] = pd.to_datetime(df[const.CONST_DATE])
                df[const.CONST_RESERVATIONS] = df[const.CONST_DATE].dt.date
                df[const.CONST_RESERVATIONS] = df[const.CONST_RESERVATIONS].apply(
                    lambda x: x.strftime("%d-%m-%Y")
                )
                df = df.rename(columns=const.CONST_COLUMNS)
                df = df[
                    [
                        const.CONST_RESERVATIONS,
                        const.CONST_OCCUPIED_ROOMS,
                        const.CONST_GUESTS,
                        const.CONST_NEW_ROOMS,
                        const.CONST_DEPARTED_ROOMS,
                        const.CONST_NEW_GUESTS,
                        const.CONST_DEPARTING_GUESTS,
                        const.CONST_BREAKFASTS,
                        const.CONST_HALFBOARDS,
                    ]
                ]

                df[const.CONST_RESERVATIONS] = pd.to_datetime(
                    df[const.CONST_RESERVATIONS], format="%d-%m-%Y"
                )

                transposed_df = df.transpose()

                transposed_df = transposed_df.reset_index()

                ws_vfb = self.wb.create_sheet(title=sheet_name)

                headers_vfb = list(transposed_df.columns)
                for col_num, header in enumerate(headers_vfb, const.CONST_ONE):
                    col_letter = get_column_letter(col_num)

                    ws_vfb[f"{col_letter}1"] = header

                for row_num, (index, row) in enumerate(
                    transposed_df.iterrows(), const.CONST_ONE
                ):
                    for col_num, value in enumerate(row, const.CONST_ONE):
                        col_letter = get_column_letter(col_num)
                        ws_vfb[f"{col_letter}{row_num}"] = value

            
            for row in dataframe_to_rows(result_df, index=False, header=True):
                vfb.append(row)
            self.wb.save(self.file_name)
            logging.info(const.CONST_FILE_CREATED)

        except Exception as generate_input_file_error:
            logging.error(f"Error generating input file: {generate_input_file_error}")
            raise

        finally:
            if self.cursor:
                self.cursor.close()
            if self.db_conn:
                self.db_conn.connection.close()

            today_date = datetime.now()
            end_date = today_date + timedelta(days=const.CONST_SIX)
            end_date_str = end_date.strftime(const.EXCEL_RECORD_DATE_FORMAT)
            start_date = today_date.strftime(const.EXCEL_RECORD_DATE_FORMAT)
            pms_mail_subject = const.CONST_PMS_EMAIL_SUBJECT.format(date=start_date)
            pms_mail_body = const.CONST_PMS_EMAIL_BODY.format(
                start_date=start_date, end_date=end_date_str
            )
            if os.path.exists(self.file_name):
                # send_mail(self.file_name, pms_mail_subject, pms_mail_body)
                pass


if __name__ == "__main__":
    try:
        generator = StaffingInputGenerator()
        generator.generate_input_file()
    except Exception as e:
        logging.error(f"An error occurred: {e}")
