import pandas as pd
import warnings
warnings.simplefilter("ignore")
import math
pd.set_option('display.precision', 2)
from pandas.io.formats import excel
excel.ExcelFormatter.header_style = None
from openpyxl.styles import Alignment
from openpyxl.styles import Font
from openpyxl import formatting, styles, Workbook
import openpyxl
import os
from openpyxl.styles.borders import Border, Side
from collections import namedtuple
import numpy as np
import datetime
from datetime import timedelta
import time
import datetime
from pandas.tseries.offsets import MonthEnd
pd.set_option('display.float_format', '{:.2f}'.format)
from scipy.spatial import distance
from scipy import stats
from input_staffing import StaffingInputGenerator



# input_matrix = pd.read_excel("Input.xlsx").set_index('Reservations')
input_matrix = pd.read_excel("Input_Staffing.xlsx", sheet_name=None, index_col=0)
cluster_matrix = pd.read_excel("HotelClusters.xlsx", index_col=0)

wd  = os.getcwd()
directories = os.walk(wd)
dirpath, dirnames, filenames = next(directories)

try:
    hgc_data_total = pd.read_pickle('Hotel_hours.pkl')
except:
    hgc_data_total = pd.DataFrame()

if hgc_data_total.empty:
       
    daily_files = [s for s in filenames if ').csv' in s]
    daily_matrix = []

    for csv_file in daily_files:
        hgc_data= pd.read_csv(r''+dirpath + '\\' + str(csv_file), header=[0],  sep=';')
        hgc_data['Hotel'] = '-'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel Margarete Maultasch by VAYA '] = 'VND' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel Astoria by VAYA '] = 'VND' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel VAYA Nauders'] = 'VND'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel Pass Thurn by VAYA'] = 'VPT'   
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel The Crystal'] = 'CRY'   
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel Sportiv'] = 'VOG' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='Hotel Tyrol by VAYA'] = 'VPF' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']=='VAYA Pfunds'] = 'VPF'  
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Hotel VAYA Sölden'] = 'VSD'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Hotel VAYA St. Zeno'] = 'VSZ'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Hotel Victoria Kaprun'] = 'VIC'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Hotel Vier Jahreszeiten by VAYA'] = 'VJZ'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Residence Kristall u. Saalbach by VAYA'] = 'ARK'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Resort Achensee'] = 'VAS'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Aschau'] = 'VZI' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Galtür'] = 'VGT'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Gerlos'] = 'VGE'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Kaprun'] = 'VKP'  
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Kühtai'] = 'VKT'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Vaya Ladis'] = 'VLA'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Resort St. Anton'] = 'VSA'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Seefeld'] = 'VSF'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Zell am See'] = 'VZS'   
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Village Park Suites'] = 'AVP' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Hotel Post Saalbach'] = 'VPS'
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Office Innsbruck'] = 'Office' 
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'Office Zell am See'] = 'Office'  
        hgc_data['Hotel'][hgc_data['Geschäftsstelle']== 'VAYA Fieberbrunn'] = 'VFB'    

        daily_matrix.append(hgc_data)
    hgc_data_total = pd.concat(daily_matrix)

    # REZ, HSK, KÜCHE, SERVICE, TECHNIK, SPA/MASS, ADMIN
    hgc_data_total['Kostenstelle'].loc[hgc_data_total.Tätigkeit.str.contains('SPA|Spa|Mass|Beauty & Spa')==True] = 'SPA/MASS'
    hgc_data_total['Kostenstelle'].loc[hgc_data_total.Tätigkeit.str.contains('Rezeptionshilfe|Bar|Rang|rang|de bar|service|Service|Kellner|Kinder')==True] = 'SERVICE'
    hgc_data_total['Kostenstelle'] = hgc_data_total['Kostenstelle'].replace(['Front Office', 'Reception TC', 'Reception','Sekretariat TC'],'REZ')
    hgc_data_total['Kostenstelle']= hgc_data_total['Kostenstelle'].replace(['Room´s', 'Room´s','Room´s ' ,'Room\'s SC', 'Room\'s TC', 'Rooms'],'HSK') 
    hgc_data_total['Kostenstelle'] = hgc_data_total['Kostenstelle'].replace(['A la carte Restaurant', 'Abwasch TC', 'Hotel Restaurant', 'Hotel Küche TC', 'Hotel Küche SC', 'Hauptküche ', 'Hauptküche', 'Hotel Restaurant SC', 'Hotel Restaurant TC', 'Lounge TC', 'Restaurant ', 'Restaurant'],'KÜCHE') 
    hgc_data_total['Kostenstelle']= hgc_data_total['Kostenstelle'].replace(['Beauty', 'Massagen TC', 'Beauty & Spa'],'SPA/MASS') 
    hgc_data_total['Kostenstelle']= hgc_data_total['Kostenstelle'].replace(['Hausmeister', 'Hausmeister TC', 'Hausmeister SC'],'TECHNIK') 
    hgc_data_total['Kostenstelle']= hgc_data_total['Kostenstelle'].replace(['Direktion', 'Direktion TC', 'Unternehmer', 'Verwaltung', 'Headoffice Innsbruck', 'Sunweb Austria'],'ADMIN') 
    hgc_data_total['Kostenstelle']= hgc_data_total['Kostenstelle'].replace(['Hotel Bar TC'],'SERVICE') 


    hgc_data_total['Tagestyp'] = '-'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Arbeitstag|Dienstreise|Kurzarbeit|Arbeitsfeiertag')==True] = 'Actual Working Days'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Wochenruhetag|Wochenruhetag 6 Tg|Wochenruhetag 7 Tg|Ersatzruhezeit|Dienstfreistellung|Zeitausgleich|Ersatzzeit für FT|Ersatzzeit für FT (Tg)')==True] = 'Rest Days'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Arbeitsverhinderung|kein Dienstverhältnis|unbegründete Abwesenheit|Arbeitssuche')==True] = 'Other'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Urlaubstag|Sonderurlaub|Pflegeurlaub|Kinderbetreuungsurlaub|Feiertag')==True] = 'Holidays and Leave'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Krank|Quarantäne|Ka. Wo.R.T.')==True] = 'Sick Days'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Mutterschutz|Karenz|Kinderbetreuungsgeld|vorzeitige Wochenhilfe|Wochenhilfe')==True] = 'Maternity Leave'
    hgc_data_total['Tagestyp'].loc[hgc_data_total.Zeitart.str.contains('Bildungsurlaub|Schulung & Weiterbildung|Berufsschule')==True] = 'Education and Training'

    hgc_data_total['Datum'] = pd.to_datetime(hgc_data_total['Datum'], format="%d.%m.%Y")

    hgc_data_total.loc[(hgc_data_total.Datum >= datetime.datetime(2021, 5, 1)) & (hgc_data_total.Datum < datetime.datetime(2021, 11, 1)), 'Season'] = 'Summer21'
    hgc_data_total.loc[(hgc_data_total.Datum >= datetime.datetime(2021, 11, 1)) & (hgc_data_total.Datum < datetime.datetime(2022, 5, 1)), 'Season'] = 'Winter21/22'
    hgc_data_total.loc[(hgc_data_total.Datum >= datetime.datetime(2022, 5, 1)) & (hgc_data_total.Datum < datetime.datetime(2022, 11, 1)), 'Season'] = 'Summer22'
    hgc_data_total.loc[(hgc_data_total.Datum >= datetime.datetime(2022, 11, 1)) & (hgc_data_total.Datum < datetime.datetime(2023, 5, 1)), 'Season'] = 'Winter22/23'
    hgc_data_total.loc[(hgc_data_total.Datum >= datetime.datetime(2023, 5, 1)) & (hgc_data_total.Datum < datetime.datetime(2023, 11, 1)), 'Season'] = 'Summer23'


    hgc_data_total['GAZ'] = hgc_data_total['GAZ'].replace(',','.', regex=True).astype(float)
    hgc_data_total['StundenProTag'] = hgc_data_total['StundenProTag'].replace(',','.', regex=True).astype(float)
    hgc_data_total['FTEProTag'] = hgc_data_total['StundenProTag'] / 8
    hgc_data_total['TageWoche'] = hgc_data_total['TageWoche'].replace(',','.', regex=True).astype(float)
    hgc_data_total['GAZWoche'] = hgc_data_total['GAZWoche'].replace(',','.', regex=True).astype(float)
    hgc_data_total['NAZWoche'] = hgc_data_total['NAZWoche'].replace(',','.', regex=True).astype(float)
    hgc_data_total.set_index('Datum', inplace=True)
    hgc_data_total['A_FTE'] = hgc_data_total['GAZ']/8
    hgc_data_total['A_FTE_adj'] = hgc_data_total['GAZ'] /8 * hgc_data_total.index.days_in_month / 21.625

    hgc_data_total.to_pickle("Hotel_hours.pkl")
else:
    pass

try:
    Hotel_overview = pd.read_pickle('Hotel_overview.pkl')
except:
    Hotel_overview = pd.DataFrame()

if Hotel_overview.empty:
    
    xlsx_files = [s for s in filenames if 'HouseState' in s]
    xlsx_matrix = []
    for xlsx_file in xlsx_files:
        try:
            Occupancies= pd.read_excel(r''+dirpath + '\\' + str(xlsx_file), header=[14])
            Occupancies = Occupancies.drop(Occupancies.filter(regex='Unnamed').columns, axis=1)
            Occupancies = Occupancies[Occupancies['Datum'] != 'Total / Seite']
            hotel_name = pd.read_excel(r''+dirpath + '\\' + str(xlsx_file), header=[0]).columns[16]
        except:
            Occupancies= pd.read_excel(r''+dirpath + '\\' + str(xlsx_file), header=[12])
            Occupancies = Occupancies.drop(Occupancies.filter(regex='Unnamed').columns, axis=1)
            Occupancies = Occupancies[Occupancies['Datum'] != 'Total / Seite']        
            hotel_name = pd.read_excel(r''+dirpath + '\\' + str(xlsx_file), header=[0]).columns[16]
            print(hotel_name)
        Occupancies = Occupancies[Occupancies['Datum'] != 'Total']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Total']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Systemdatum:']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Gruppierung']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Auswertungszeitraum:']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Type']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Filter']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Umsatz']
        Occupancies = Occupancies[Occupancies['Datum'] != 'OOO Zimmer']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Pseudozimmer']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Status']
        Occupancies = Occupancies[Occupancies['Datum'] != 'Datum']
        Occupancies = Occupancies[Occupancies['Datum'] != '']
        Occupancies = Occupancies[Occupancies['Datum'].notnull()]

        Occupancies['Datum'] = Occupancies['Datum'].str[-10:]
        Occupancies = Occupancies.dropna(axis=0, how='all')
        Occupancies['Hotel'] = '-'
        if 'Naunders' in hotel_name:
            Occupancies['Hotel'] = 'VND'
        elif 'Sölden' in hotel_name:
            Occupancies['Hotel'] = 'VSD'
        elif 'Ladis' in hotel_name:
            Occupancies['Hotel'] = 'VLA'
        elif 'Post Saalbach' in hotel_name:
            Occupancies['Hotel'] = 'VPS'
        elif 'Kühtai' in hotel_name:
            Occupancies['Hotel'] = 'VKT'
        elif 'VAYA Galtür' in hotel_name:
            Occupancies['Hotel'] = 'VGT'
        elif 'Aschau' in hotel_name:
            Occupancies['Hotel'] = 'VZI'
        elif 'Zell am See' in hotel_name:
            Occupancies['Hotel'] = 'VZS'
        elif 'Achen' in hotel_name:
            Occupancies['Hotel'] = 'VAS'
        elif 'Residence Saalbach' in hotel_name:
            Occupancies['Hotel'] = 'ARS'
        elif 'Residence Kristall' in hotel_name:
            Occupancies['Hotel'] = 'ARK'
        elif 'Victoria' in hotel_name:
            Occupancies['Hotel'] = 'VIC'
        elif 'Vierjahres' in hotel_name:
            Occupancies['Hotel'] = 'VJZ'
        elif 'VAYA Kaprun' in hotel_name:
            Occupancies['Hotel'] = 'VKP'
        elif 'Gerlos' in hotel_name:
            Occupancies['Hotel'] = 'VGE'
        elif 'Terra' in hotel_name:
            Occupancies['Hotel'] = 'VTE'
        elif 'Fieberbrunn' in hotel_name:
            Occupancies['Hotel'] = 'VFB'
        elif 'Sportiv' in hotel_name:
            Occupancies['Hotel'] = 'VOG'
        elif 'Anton' in hotel_name:
            Occupancies['Hotel'] = 'VSA'
        elif 'Haus Bel' in hotel_name:
            Occupancies['Hotel'] = 'ABV'
        elif 'St. Zeno' in hotel_name:
            Occupancies['Hotel'] = 'VSZ'
        elif 'Village' in hotel_name:
            Occupancies['Hotel'] = 'AVP'
        elif 'Residence Galtür' in hotel_name:
            Occupancies['Hotel'] = 'VRG'
        elif 'Pfunds' in hotel_name:
            Occupancies['Hotel'] = 'VPF'
        elif 'Vaya Seefeld' in hotel_name:
            Occupancies['Hotel'] = 'VSF'
        elif 'Cry' in hotel_name:
            Occupancies['Hotel'] = 'CRY'
        xlsx_matrix.append(Occupancies)
    Hotel_overview = pd.concat(xlsx_matrix)
    Hotel_overview['Datum'] = pd.to_datetime(Hotel_overview['Datum'], format="%d.%m.%Y")
    Hotel_overview.set_index('Datum', inplace=True)
    Hotel_overview['Hotel'][(Hotel_overview['Hotel'] == 'ARS') | (Hotel_overview['Hotel'] == 'ARK')] = 'ARK'
    Hotel_overview['Hotel'][(Hotel_overview['Hotel'] == 'VGT') | (Hotel_overview['Hotel'] == 'VRG')] = 'VGT'
    Hotel_overview.to_pickle("Hotel_overview.pkl")
else:
    pass

# writer = pd.ExcelWriter('Hotels_overview.xlsx')   
# output.to_excel(writer, engine="xlsxwriter", startrow=0)
# writer.save()


try:
    Hotel_reservations = pd.read_pickle('Hotel_reservations.pkl')
except:
    Hotel_reservations = pd.DataFrame()

if Hotel_reservations.empty:
    wd  = os.getcwd()
    directories = os.walk(wd)
    dirpath, dirnames, filenames = next(directories)

    for dirname in dirnames:
        dirpath, dirnames, filenames = next(directories)

        print(dirname)
        Reservations_files = [s for s in filenames if 'reservations' in s]

        Reservation_matrix = []
        for Reservations_file in Reservations_files:
            if '(17)' in Reservations_file:
                Reservations = pd.read_excel(r''+dirpath + '\\' + str(Reservations_file), header=[9])
            else:
                Reservations = pd.read_excel(r''+dirpath + '\\' + str(Reservations_file), header=[6])
            Reservations = Reservations[Reservations.columns.drop(list(Reservations.filter(regex='Unnamed')))]
            Reservations=Reservations.iloc[:Reservations.loc[Reservations.iloc[:,0].eq('Summe')].index[0]]
            if 'Guest name(s)' in Reservations.columns:
                Reservations_all_names = Reservations['Guest name(s)'].str.split(', ', expand=True)
            elif 'Gastname' in Reservations.columns:
                Reservations_all_names = Reservations['Gastname(n)'].str.split(', ', expand=True)
            else:
                guest_names =  ['[anonym]']* len(Reservations_all_names.iloc[:,0])
                Reservations_all_names.insert(0, 'Gastname(n)', guest_names)
            Reservations_all_names = Reservations_all_names.replace('[anonym] ', np.nan).replace('[anonym]', np.nan)
            Reservations_all_names = Reservations_all_names.fillna(value=np.nan)
            Reservations_all_names = Reservations_all_names.dropna(axis=1, how='all')
            Reservations_all_names.columns = ['Name' + str(x) for x in range(1,len(Reservations_all_names.columns)+1)]
            Reservations_all_names.replace(' - ','~~~~', regex=True, inplace=True)
            Reservations_all_names.replace(' and ',';;;;', regex=True, inplace=True)
            for names in range(1,len(Reservations_all_names.columns)+1):    
                if len(Reservations_all_names['Name' + str(names)].str.rsplit(expand=True, n=1).columns) > 1:
                    Reservations_all_names[['Last name'+str(names),'First name'+str(names)]] = Reservations_all_names['Name' + str(names)].str.rsplit(expand=True, n=1)
            Reservations_all_names.replace('~~~~',' - ', regex=True, inplace=True)
            Reservations_all_names.replace(';;;;',' and ', regex=True, inplace=True)
            Reservations = pd.concat([Reservations, Reservations_all_names], axis=1) 
            Reservations.drop('Allotment short  name', axis=1, errors='ignore')   
            Reservation_matrix.append(Reservations)
            print('Concatenating Reservation Matrices')
        if dirname != 'F&B':
            Reservations = pd.concat(Reservation_matrix)
            Reservations = Reservations.drop_duplicates()
        else:
            continue
    Reservations.to_pickle("Hotel_reservations.pkl") 
else:
    pass   
    
try:
    Hotel_boards = pd.read_pickle('Hotel_boards.pkl')
except:
    Hotel_boards = pd.DataFrame()

if Hotel_boards.empty:
    wd  = os.getcwd()
    directories = os.walk(wd)
    dirpath, dirnames, filenames = next(directories)
    
    Journal_matrix = []
    directories = os.walk(wd + '\\' + 'F&B')
    dirpath, dirnames, filenames = next(directories)  
    for dirname in dirnames:
        dirpath, dirnames, filenames = next(directories)  
        Journal_files = [s for s in filenames if 'Journal' in s]
        for Journal_file in Journal_files:
            try:
                Journals = pd.read_excel(r''+dirpath + '\\' + str(Journal_file), header=[7]).iloc[:,1:]
                Journals = Journals.loc[:, Journals.columns.notna()]
                Journals = Journals.dropna(axis=0, how='all')
                Journals = Journals.dropna(axis=1, how='all')
                Journals = Journals[Journals['Buchungsd'] != 'Buchungsd']
                Journals = Journals[Journals['Buchungsd'] != 'Systemdatum:']
                Journals = Journals[Journals['Buchungsd'] != 'Parameter']
                Journals = Journals[Journals['Buchungsd'] != 'Warengruppe:']
                Journals = Journals[Journals['Buchungsd'] != 'Artikel:']
                Journals = Journals[Journals['Buchungsd'] != 'Zeitraum:']
                Journals = Journals[Journals['Buchungsd'].notna()]
                Journals.columns.name = None
                Journals = Journals[['Buchungsd','Rechnung', 'Unnamed: 12','Unnamed: 14', 'Buchungstext' , 'Zimmer', 'Unnamed: 29', 'Gast']].rename(columns={'Buchungsd': 'Datum','Unnamed: 12': 'Res.','Unnamed: 14': 'Amount', 'Unnamed: 29': 'Type'})
                Journals['Hotel'] = dirname
                Journals['Buchungstext'].loc[Journals.Buchungstext.str.contains('Halbpension|halbpension|HalbPension')==True] = 'Halbpension'
                Journals['Buchungstext'].loc[Journals.Buchungstext.str.contains('Frühstuck|frühstuck|Fruhstuck|fruhstuck|Frühstück|frühstück')==True] = 'Früstuck' 
                Journals = Journals[(Journals['Buchungstext'] == 'Halbpension') | (Journals['Buchungstext'] == 'Früstuck')]   
                Journal_matrix.append(Journals)
            except:
                continue
        Journals = pd.concat(Journal_matrix)
    # Journals = Journals.drop_duplicates()  
    Hotel_boards = Journals.set_index('Datum') 
    Hotel_boards.to_pickle("Hotel_boards.pkl") 
else:
    pass   

          
breakfast = Hotel_boards[Hotel_boards['Buchungstext'] == 'Früstuck'].groupby(['Hotel', pd.Grouper( freq='D')])['Amount'].sum().reset_index().set_index(['Datum'])
halfboards = Hotel_boards[Hotel_boards['Buchungstext'] == 'Halbpension'].groupby(['Hotel', pd.Grouper( freq='D')])['Amount'].sum().reset_index().set_index(['Datum'])
ftes = hgc_data_total.groupby(['Hotel', pd.Grouper( freq='D'), 'Kostenstelle'])['A_FTE'].sum().reset_index().set_index(['Datum'])
total= Hotel_overview.groupby(['Hotel', pd.Grouper( freq='D')])[['#.2', 'Pers..2', '#', 'Pers.', '#.1', 'Pers..1']].sum().reset_index().set_index(['Datum'])
total = pd.merge(total, ftes, how='outer', on=['Datum', 'Hotel']).sort_index()
total = pd.merge(total, breakfast, how='outer', on=['Datum', 'Hotel']).sort_index()
total = pd.merge(total, halfboards, how='outer', on=['Datum', 'Hotel']).sort_index()
total = total.groupby(['Datum','Hotel', 'Kostenstelle']).agg({'Pers..2': 'sum', '#.2': 'sum','Pers..1': 'sum', '#.1': 'sum','Pers.': 'sum', '#': 'sum', 'A_FTE':'sum', 'Amount_x': 'sum', 'Amount_y': 'sum'})


# total = total.reset_index(level=[0,1,2,3]).set_index(['Datum'])
total = total.reset_index(level=[0,1,2]).set_index(['Datum'])

total = total.rename(columns = {'Amount_x': 'Breakfasts', 'Amount_y': 'Halfboards', 'A_FTE':'FTE', 'Pers..2': 'Guests', '#.2': 'Occupied Rooms','#': 'New Rooms', 'Pers.': 'New Guests', '#.1': 'Departed Rooms', 'Pers..1': 'Departing Guests'})
# total = total.pivot_table(index = ['Datum', 'Hotel', 'Tagestyp','#.2' ,'Pers..2' ], columns=['Kostenstelle'], values=['A_FTE', 'C_FTE', 'TotalMntKostenInkSZ', 'Headcount']).reset_index(level=[1,2,3,4])
# total = total.pivot_table(index = ['Datum', 'Hotel', 'Tagestyp','#.2' ,'Pers..2' ], columns=['Kostenstelle'], values=['A_FTE', 'TotalMntKostenInkSZ', 'Headcount']).reset_index(level=[1,2,3,4])
total = total.pivot_table(index = ['Datum', 'Hotel', 'Occupied Rooms' ,'Guests', 'New Rooms', 'New Guests', 'Departed Rooms', 'Departing Guests', 'Breakfasts', 'Halfboards'], columns=['Kostenstelle'], values=['FTE']).reset_index(level=[1,2])

total = total.sort_values(['Hotel', 'Datum'])
total.columns = ['_'.join(col).strip('_') for col in total.columns.values]
total['Total_FTE'] = total[['FTE_ADMIN', 'FTE_HSK', 'FTE_KÜCHE', 'FTE_REZ', 'FTE_SERVICE', 'FTE_SPA/MASS', 'FTE_TECHNIK']].sum(axis=1)

total = total.reset_index().set_index(['Datum'])
# total['Total_C_FTE'] = total[['C_FTE_ADMIN', 'C_FTE_HSK', 'C_FTE_KÜCHE', 'C_FTE_REZ', 'C_FTE_SERVICE', 'C_FTE_SPA/MASS', 'C_FTE_TECHNIK']].sum(axis=1)

total['Guests'] = total['Guests'].astype(float)
total['Occupied Rooms'] = total['Occupied Rooms'].astype(float)
total['New Rooms'] = total['New Rooms'].astype(float)
total['New Guests'] = total['New Guests'].astype(float)
total['Departed Rooms'] = total['Departed Rooms'].astype(float)
total['Departing Guests'] = total['Departing Guests'].astype(float)
total['Breakfasts'] = total['Breakfasts'].astype(float)
total['Halfboards'] = total['Halfboards'].astype(float)

# VSZ_VTE_ABV = total[(total['Hotel'] == 'VSZ') | (total['Hotel'] == 'VTE') | (total['Hotel'] == 'ABV')]  

total[(total['Hotel'] == 'VSZ') | (total['Hotel'] == 'VTE') | (total['Hotel'] == 'ABV')] == 'VSZ'

CRY_VOG = total[(total['Hotel'] == 'CRY') | (total['Hotel'] == 'VOG')]  
CRY_VOG = CRY_VOG.groupby('Datum').sum()
CRY_VOG['Hotel'] ='CRY_VOG'

# total = total.append(CRY_VOG)
total = pd.concat([total, CRY_VOG], axis=0)


VZS_AVP = total[(total['Hotel'] == 'VZS') | (total['Hotel'] == 'AVP')]  
VZS_AVP = VZS_AVP.groupby('Datum').sum()
VZS_AVP['Hotel'] ='VZS_AVP'

# total = total.append(VZS_AVP)
total = pd.concat([total, VZS_AVP], axis=0)


total.loc[(total.index >= datetime.datetime(2021, 5, 1)) & (total.index < datetime.datetime(2021, 11, 1)), 'Season'] = 'Summer21'
total.loc[(total.index >= datetime.datetime(2021, 11, 1)) & (total.index < datetime.datetime(2022, 5, 1)), 'Season'] = 'Winter21/22'
total.loc[(total.index >= datetime.datetime(2022, 5, 1)) & (total.index < datetime.datetime(2022, 11, 1)), 'Season'] = 'Summer22'
total.loc[(total.index >= datetime.datetime(2022, 11, 1)) & (total.index < datetime.datetime(2023, 5, 1)), 'Season'] = 'Winter22/23'
total.loc[(total.index >= datetime.datetime(2023, 5, 1)) & (total.index < datetime.datetime(2023, 11, 1)), 'Season'] = 'Summer23'
total.loc[(total.index >= datetime.datetime(2023, 11, 1)) & (total.index < datetime.datetime(2024, 5, 1)), 'Season'] = 'Winter23/24'

guest_bins = [-1,0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
guest_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
total['GuestsGroup']=pd.cut(total['Guests'],guest_bins,labels=guest_group_names)

newguest_bins = [-1,0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
newguest_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
total['NewGuestsGroup']=pd.cut(total['New Guests'],newguest_bins,labels=newguest_group_names)

departingguest_bins = [-1,0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
departingguest_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
total['DepGuestsGroup']=pd.cut(total['Departing Guests'],departingguest_bins,labels=departingguest_group_names)

occrooms_bins = [-1,0,10,20,30,40,50, 60,70,80,90,100,120,140,160,180,200,220,240,260,280,300]
occrooms_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,220,240,260,280,300]
total['OccRoomsGroups']=pd.cut(total['Occupied Rooms'],occrooms_bins,labels=occrooms_group_names)

newrooms_bins = [-1,0,10,20,30,40,50, 60,70,80,90,100,120,140,160,180,200,220,240,260,280,300]
newrooms_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,220,240,260,280,300]
total['NewRoomsGroups']=pd.cut(total['New Rooms'],newrooms_bins,labels=newrooms_group_names)

departedrooms_bins = [-1,0,10,20,30,40,50, 60,70,80,90,100,120,140,160,180,200,220,240,260,280,300]
departedrooms_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,220,240,260,280,300]
total['DepRoomsGroups']=pd.cut(total['Departed Rooms'],departedrooms_bins,labels=departedrooms_group_names)

breakfast_bins = [-1,0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
breakfast_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
total['BreakfastsGroup']=pd.cut(total['Breakfasts'],guest_bins,labels=guest_group_names)

halfboards_bins = [-1,0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
halfboards_group_names=[0,10,20,30,40,50,60,70,80,90,100,120,140,160,180,200,240,280,320,360,400,440,480,520,560,600]
total['HalfboardsGroup']=pd.cut(total['Halfboards'],guest_bins,labels=guest_group_names)

total.to_excel("all_data.xlsx")

staffs = {'Housekeeping': {'variable_groups': ['DepRoomsGroups', 'OccRoomsGroups', 'GuestsGroup'], 'variables': ['Departed Rooms', 'Occupied Rooms', 'Guests'], 'department': 'FTE_HSK'}, 
         'Reception': { 'variable_groups': ['DepGuestsGroup', 'NewGuestsGroup', 'GuestsGroup'], 'variables': ['Departing Guests', 'New Guests', 'Guests'], 'department': 'FTE_REZ'}, 
         'Waitering': {'variable_groups': ['BreakfastsGroup', 'HalfboardsGroup', 'GuestsGroup'], 'variables': ['Breakfasts', 'Halfboards', 'Guests'], 'department': 'FTE_SERVICE'}, 
         'Kitchen': {'variable_groups': ['BreakfastsGroup', 'HalfboardsGroup', 'GuestsGroup'], 'variables': ['Breakfasts', 'Halfboards', 'Guests'], 'department': 'FTE_KÜCHE'}}
        #  'spastaff': {'variable_groups': ['GuestsGroup'], 'variables': ['Guests'], 'department': 'FTE_SPA/MASS'},
        #  'technikstaff': {'variable_groups': ['GuestsGroup'], 'variables': ['Guests'], 'department': 'FTE_TECHNIK'},
        #  'admins': {'variable_groups': ['GuestsGroup'], 'variables': ['Guests'], 'department': 'FTE_TECHNIK'}}
 
 # MODEL CALCULATION
# department_output_model = []
# for date in input_matrix.columns:
#     staff_table_model = []
#     for staff in staffs:
#         input_variables = pd.DataFrame(data = [input_matrix[date][staffs[staff]['variables']].tolist()], index = ['VFB'], columns = [staffs[staff]['variables']])
#         recommendedFTE = 0
#         if staff == 'Housekeeping':
#             recommendedFTE = (input_variables['Departed Rooms'].loc['VFB'][0] * 0.5 + input_variables['Occupied Rooms'].loc['VFB'][0] * 0.25 + (1000 * 1/60) / 2) / 8
#         elif staff == 'Reception':
#             recommendedFTE = (input_variables['Departing Guests'].loc['VFB'][0] * 0.33  + input_variables['New Guests'].loc['VFB'][0] * 0.17  + 2 + input_variables['Guests'].loc['VFB'][0] * 1/30 ) / 8
#         elif staff == 'Waitering':
#             recommendedFTE = (2 + input_variables['Breakfasts'].loc['VFB'][0] * 0.1  + 2 + input_variables['Halfboards'].loc['VFB'][0] * 0.20  + input_variables['Guests'].loc['VFB'][0] * 1/60 ) / 8
#         elif staff == 'Kitchen':
#             recommendedFTE = (3 + input_variables['Breakfasts'].loc['VFB'][0] * 0.05  + 3 + input_variables['Halfboards'].loc['VFB'][0] * 1/6  + 1 + (input_variables['Breakfasts'].loc['VFB'][0] + input_variables['Halfboards'].loc['VFB'][0]) * 1/30) / 8 
#         staff_table_model.append(round(recommendedFTE,1))   
#     department_output_model.append(staff_table_model)
# output_table_model = pd.DataFrame(department_output_model, index = input_matrix.columns , columns = staffs.keys()).T

hotels = ['ARK', 'CRY', 'VAS', 'VFB', 'VGE', 'VGT', 'VIC', 'VJZ', 'VKP', 'VKT', 'VLA', 'VND', 'VOG', 'VPF', 'VPS', 'VSA', 'VSF', 'VSZ', 'VZI', 'VSD', 'CRY_VOG', 'VZS_AVP']
parameters = {'Dep_cleaning': 0.5, 'Occ_cleaning':0.25,'common_m2': 1000, 'com_cleaning': 1/60 , 'clean_days': 2,'rec_checkout': 0.33, 'rec_checkin': 0.17, 'rec_sd': 1/30, 'rec_admin':2, 'wai_breakfast': 0.1, 'wai_halfboards': 0.20, 'wai_sd': 1/60, 'wai_prep':1, 'kit_breakfast': 0.05, 'kit_halfboards': 1/6, 'kit_dishwashing': 1/30, 'kit_breakfast_prep': 1, 'kit_halfboard_prep': 2, 'kit_storing': 1}
parameters_backw = {}
all_figures = {}
all_tables = {}
all_tables2 = {}
for hotel in hotels:
    print('Creating ' + hotel + ' report')
    figures = []
    department_output = []
    department_output_model = []
    department_output_cluster = []
    for date in input_matrix[hotel].columns:
        staff_table = []
        staff_table_model = []
        staff_table_cluster = []
        variables_max = {}
        for staff in staffs:
            # FIND CLOSEST IN THE PAST
            total_zeros = total.replace(np.nan, 0)
            department = total_zeros[staffs[staff]['variable_groups'] + ['Hotel']].dropna()
            department.set_index('Hotel', inplace=True)

            # INPUT VARIABLES
            input_department = pd.DataFrame(data = [input_matrix[hotel][date][staffs[staff]['variables']].tolist()], index = [hotel], columns = department.columns)
            
            department_input = pd.concat([department, input_department], axis=0)

            matrix = distance.pdist(department_input.loc[hotel][staffs[staff]['variable_groups']], metric='seuclidean')
            matrix = pd.DataFrame(distance.squareform(matrix))

            nrofclosepoints = round(0.20 * len(matrix))
            most_similar_indices = matrix.nsmallest(nrofclosepoints, matrix.columns[-1], keep='all').index.tolist()

            max_variablegroups = total[total['Hotel'] == hotel][staffs[staff]['variable_groups']].dropna().max(axis=0)
            
            nrofsimilardays_cluster= 17
            nrofsimilardays = 35

            similar_dates = {}
            
            for i in range(1,nrofsimilardays):
                # similar_dates.append(total[total['Hotel'] == 'VFB'][['DepRoomsGroups', 'OccRoomsGroups', 'GuestsGroup']].dropna()[(total[total['Hotel'] == 'VFB'][['DepRoomsGroups', 'OccRoomsGroups', 'GuestsGroup']].dropna() == housekeepers_input.loc['VFB'].iloc[test[i]]).all(axis=1)].index[0])
                similar_dates[total[total['Hotel'] == hotel][staffs[staff]['variable_groups']].dropna()[(total[total['Hotel'] == hotel][staffs[staff]['variable_groups']].dropna() == department_input.loc[hotel].iloc[most_similar_indices[i]]).all(axis=1)].index[0]] = total[total['Hotel'] == hotel].loc[total[total['Hotel'] == hotel][staffs[staff]['variable_groups']].dropna()[(total[total['Hotel'] == hotel][staffs[staff]['variable_groups']].dropna() == department_input.loc[hotel].iloc[most_similar_indices[i]]).all(axis=1)].index[0]]
                # if (pd.DataFrame(similar_dates).loc['Hotel'] == hotel).sum() >= 10:
                #     break
                
            # Also check for hotels in the same cluster
            similar_dates_samecluster = {}
            cluster_hotels = cluster_matrix[cluster_matrix['Cluster'] == cluster_matrix.loc[hotel]['Cluster']].index.tolist()
            for hotel_samecluster in cluster_hotels:
                    for j in range(1,nrofsimilardays_cluster):
                        department_input = pd.concat([department, input_department.rename(index = {hotel:hotel_samecluster})], axis=0)
                        matrix_samecluster = distance.pdist(department_input.loc[hotel_samecluster][staffs[staff]['variable_groups']], metric='seuclidean')
                        matrix_samecluster = pd.DataFrame(distance.squareform(matrix_samecluster))
                        nrofclosepoints_samecluster = round(0.20 * len(matrix_samecluster))
                        most_similar_indices_samecluster = matrix_samecluster.nsmallest(nrofclosepoints_samecluster, matrix_samecluster.columns[-1], keep='all').index.tolist()[1:]
                        # similar_dates.append(total[total['Hotel'] == 'VFB'][['DepRoomsGroups', 'OccRoomsGroups', 'GuestsGroup']].dropna()[(total[total['Hotel'] == 'VFB'][['DepRoomsGroups', 'OccRoomsGroups', 'GuestsGroup']].dropna() == housekeepers_input.loc['VFB'].iloc[test[i]]).all(axis=1)].index[0])
                        similar_dates_samecluster[total[total['Hotel'] == hotel_samecluster][staffs[staff]['variable_groups']].dropna()[(total[total['Hotel'] == hotel_samecluster][staffs[staff]['variable_groups']].dropna() == department_input.loc[hotel_samecluster].iloc[most_similar_indices_samecluster[j]]).all(axis=1)].index[0]] = total[total['Hotel'] == hotel_samecluster].loc[total[total['Hotel'] == hotel_samecluster][staffs[staff]['variable_groups']].dropna()[(total[total['Hotel'] == hotel_samecluster][staffs[staff]['variable_groups']].dropna() == department_input.loc[hotel_samecluster].iloc[most_similar_indices_samecluster[j]]).all(axis=1)].index[0]]
                        # if (pd.DataFrame(similar_dates_samecluster).loc['Hotel'] == hotel_samecluster).sum() >= 4:
                        #     break
                        # if len(pd.DataFrame(similar_dates_samecluster).columns) >= 10:
                        #     break
            # Top n2 comparable days
            # total[total['Hotel'] == hotel].loc[pd.DataFrame(similar_dates).T[staffs[staff]['department']].sort_values().head(nrofsimilardays).index][staffs[staff]['variables'] + [staffs[staff]['department']]]

            # Recommended number of FTE
            # try:
            #     recommendedFTE = pd.DataFrame(similar_dates).T[staffs[staff]['department']].sort_values().quantile([0, 0.05, 0.1, 0.15, 0.20, 0.25, 0.3, 0.35, 0.4, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1])
            # except:
            #     recommendedFTE = pd.DataFrame([similar_dates]).T[staffs[staff]['department']].sort_values().quantile([0, 0.05, 0.1, 0.15, 0.20, 0.25, 0.3, 0.35, 0.4, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1])

            # try:
            #     recommended_FTE_cluster = pd.DataFrame(similar_dates_samecluster).T[staffs[staff]['department']].sort_values().quantile([0, 0.05, 0.1, 0.15, 0.20, 0.25, 0.3, 0.35, 0.4, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1])
            # except:
            #     recommended_FTE_cluster = pd.DataFrame([similar_dates_samecluster]).T[staffs[staff]['department']].sort_values().quantile([0, 0.05, 0.1, 0.15, 0.20, 0.25, 0.3, 0.35, 0.4, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1])                
          

            
            # MODEL CALCULATIONS            
            input_variables = pd.DataFrame(data = [input_matrix[hotel][date][staffs[staff]['variables']].tolist()], index = [hotel], columns = [staffs[staff]['variables']])
            recommendedFTE_model = 0
            if staff == 'Housekeeping':
                recommendedFTE_model = (input_variables['Departed Rooms'].loc[hotel][0] * parameters['Dep_cleaning'] + input_variables['Occupied Rooms'].loc[hotel][0]  * parameters['Occ_cleaning'] + (parameters['common_m2'] * parameters['com_cleaning']) / parameters['clean_days']) / 8
            elif staff == 'Reception':
                recommendedFTE_model = (input_variables['Departing Guests'].loc[hotel][0] * parameters['rec_checkout']  + input_variables['New Guests'].loc[hotel][0] * parameters['rec_checkin']  + parameters['rec_admin'] + input_variables['Guests'].loc[hotel][0]  * parameters['rec_sd'] ) / 8
            elif staff == 'Waitering':
                recommendedFTE_model = (parameters['wai_prep'] + input_variables['Breakfasts'].loc[hotel][0] * parameters['wai_breakfast']  + parameters['wai_prep']  + input_variables['Halfboards'].loc[hotel][0] * parameters['wai_halfboards']  + input_variables['Guests'].loc[hotel][0] * parameters['wai_sd'] ) / 8
            elif staff == 'Kitchen':
                recommendedFTE_model = (parameters['kit_breakfast_prep'] + input_variables['Breakfasts'].loc[hotel][0] * parameters['kit_breakfast']  + parameters['kit_halfboard_prep'] + input_variables['Halfboards'].loc[hotel][0] * parameters['kit_halfboards']   + parameters['kit_storing'] + (input_variables['Breakfasts'].loc[hotel][0] + input_variables['Halfboards'].loc[hotel][0]) * parameters['kit_dishwashing']) / 8 
            from mpl_toolkits.mplot3d import Axes3D
            import matplotlib.pyplot as plt
            from adjustText import adjust_text

            # ftes = pd.DataFrame(similar_dates).T[staffs[staff]['department']].dropna().sort_values()
            # ftes = ftes.set_axis(stats.percentileofscore(ftes,ftes))
            # ftescluster = pd.DataFrame(similar_dates_samecluster).T[staffs[staff]['department']].dropna().sort_values()
            # ftescluster = ftescluster.set_axis(stats.percentileofscore(ftescluster,ftescluster))
            plot_variables = pd.concat([pd.DataFrame(similar_dates).T[staffs[staff]['variables']].dropna(), pd.DataFrame(similar_dates).T[staffs[staff]['department']].dropna()], axis=1)
            plot_variables_uniquefte = plot_variables.drop_duplicates(subset=staffs[staff]['department'], keep="last") 
            plot_variables_uniquefte['percentiles'] = stats.percentileofscore(plot_variables_uniquefte[staffs[staff]['department']].fillna(0),plot_variables_uniquefte[staffs[staff]['department']].fillna(0))
            plot_variables_uniquefte = plot_variables_uniquefte.sort_values(by = 'percentiles')
            plot_variables_cluster = pd.concat([pd.DataFrame(similar_dates_samecluster).T[staffs[staff]['variables']].dropna(), pd.DataFrame(similar_dates_samecluster).T[staffs[staff]['department']].dropna()], axis=1)
            plot_variables_cluster['Hotel'] = pd.DataFrame(similar_dates_samecluster).T['Hotel'].dropna()
            plot_variables_cluster_uniquefte = plot_variables_cluster.drop_duplicates(subset=staffs[staff]['department'], keep="last") 
            plot_variables_cluster_uniquefte['percentiles'] = stats.percentileofscore(plot_variables_cluster_uniquefte[staffs[staff]['department']].fillna(0),plot_variables_cluster_uniquefte[staffs[staff]['department']].fillna(0))
            plot_variables_cluster_uniquefte = plot_variables_cluster_uniquefte.sort_values(by = 'percentiles')


            # recommendedFTE = plot_variables_uniquefte[staffs[staff]['department']].quantile([0, 0.05, 0.1, 0.15, 0.20, 0.25, 0.3, 0.35, 0.4, 0.45, 0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 1])
            recommended_FTE_cluster =  plot_variables_cluster_uniquefte.iloc[(plot_variables_cluster_uniquefte['percentiles']-25).abs().argsort().iloc[0]][staffs[staff]['department']]
            recommendedFTE = plot_variables_uniquefte.iloc[(plot_variables_uniquefte['percentiles']-25).abs().argsort().iloc[0]][staffs[staff]['department']]
                
            pctl_recommendedFTE = stats.percentileofscore(plot_variables_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles')[staffs[staff]['department']].fillna(0),recommendedFTE)           
            pctl_recommendedFTE_model = stats.percentileofscore(plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles')[staffs[staff]['department']].fillna(0),recommendedFTE_model)
            pctl_recommendedFTE_model_cluster = stats.percentileofscore(plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles')[staffs[staff]['department']].fillna(0),recommended_FTE_cluster)

            # average_model_emperical_recommendedFTE = (recommendedFTE*input_matrix['Weights']['Weight']['Emperical Model']+ recommendedFTE_model*input_matrix['Weights']['Weight']['Theoretical Model'] + recommended_FTE_cluster*input_matrix['Weights']['Weight']['Emperical Cluster Model'])
            # pctl_recommendedFTE_average = stats.percentileofscore(plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles')[staffs[staff]['department']].fillna(0),average_model_emperical_recommendedFTE) 


            fig = plt.figure(figsize=(21, 15))
            plt.plot(plot_variables_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles'), label='FTEs', color='grey', marker="o", alpha=0.2)
            for x,y,a,b,c,d  in zip(plot_variables_uniquefte['percentiles'],plot_variables_uniquefte[staffs[staff]['department']], plot_variables_uniquefte[staffs[staff]['variables'][0]], plot_variables_uniquefte[staffs[staff]['variables'][1]], plot_variables_uniquefte[staffs[staff]['variables'][2]], plot_variables_uniquefte.index.date ):
                if len(plot_variables_uniquefte) > 5:
                    label = str(d) + "\n FTE: {:.1f}".format(y) + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(a) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(b) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(c)
                    for x_label in [20, 40, 60, 80, 100]:
                            if x == pd.Series(plot_variables_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').index,plot_variables_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').values).iloc[(pd.Series(plot_variables_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').index,plot_variables_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles'))-x_label).abs().argsort().iloc[0]]:
                                plt.annotate(label, # this is the text
                                            (x,y), # these are the coordinates to position the label
                                            textcoords="offset points", # how to position the text
                                            xytext=(-10,20), # distance from text to points (x,y)
                                            ha='center') # horizontal alignment can be left, right or center
                else:
                    label = str(d) + "\n FTE: {:.1f}".format(y) + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(a) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(b) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(c)
                    plt.annotate(label, # this is the text
                                (x,y), # these are the coordinates to position the label
                                textcoords="offset points", # how to position the text
                                xytext=(-10,20), # distance from text to points (x,y)
                                ha='center') # horizontal alignment can be left, right or center
                
            plt.plot(plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles'), label='FTEs', color='b', marker="o")
            for x,y,a,b,c,d,e  in zip(plot_variables_cluster_uniquefte['percentiles'],plot_variables_cluster_uniquefte[staffs[staff]['department']], plot_variables_cluster_uniquefte[staffs[staff]['variables'][0]], plot_variables_cluster_uniquefte[staffs[staff]['variables'][1]], plot_variables_cluster_uniquefte[staffs[staff]['variables'][2]], plot_variables_cluster_uniquefte.index.date, plot_variables_cluster_uniquefte['Hotel']  ):
                if len(plot_variables_cluster_uniquefte) > 5:
                    label = str(d) + "\n FTE: {:.1f}".format(y) + "\n" + e + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(a) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(b) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(c)
                    for x_label in [20, 40, 60, 80, 100]:
                            if x == pd.Series(plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').index,plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').values).iloc[(pd.Series(plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').index,plot_variables_cluster_uniquefte[['percentiles',staffs[staff]['department']]].set_index('percentiles').values)-x_label).abs().argsort()[:1].iloc[0]]:
                                plt.annotate(label, # this is the text
                                            (x,y), # these are the coordinates to position the label
                                            textcoords="offset points", # how to position the text
                                            xytext=(-10,20), # distance from text to points (x,y)
                                            ha='center') # horizontal alignment can be left, right or center
                else:
                    label = str(d) + "\n FTE: {:.1f}".format(y) + "\n" + e + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(a) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(b) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(c)
                    plt.annotate(label, # this is the text
                                        (x,y), # these are the coordinates to position the label
                                        textcoords="offset points", # how to position the text
                                        xytext=(-10,20), # distance from text to points (x,y)
                                        ha='center') # horizontal alignment can be left, right or center
                
            plt.title("FTE " + staff + " " + hotel +" on comparable days (" + str(pd.to_datetime(date).date()) + ")" ,fontsize=22) 
            plt.plot(pctl_recommendedFTE, recommendedFTE, label='FTEs', color='orange', marker="o", markersize=12)
            plt.annotate('Emperical FTE = ' +  str(round(recommendedFTE,1)) + ',' + '\nbased on:' + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(input_department.iloc[0][0]) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(input_department.iloc[0][1]) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(input_department.iloc[0][2]) , xy=(pctl_recommendedFTE, recommendedFTE), textcoords="offset points", xytext=(-190, 100),
                        arrowprops=dict(facecolor='black', shrink=0.1))
            plt.plot(pctl_recommendedFTE_model, recommendedFTE_model, label='FTEs', color='g', marker="o", markersize=12)
            plt.annotate('Modelled FTE = ' +  str(round(recommendedFTE_model,1)) + ',' + '\nbased on:' + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(input_department.iloc[0][0]) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(input_department.iloc[0][1]) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(input_department.iloc[0][2]) , xy=(pctl_recommendedFTE_model, recommendedFTE_model), textcoords="offset points", xytext=(-190, 100),
                        arrowprops=dict(facecolor='black', shrink=0.1))
            plt.plot(pctl_recommendedFTE_model_cluster, recommended_FTE_cluster, label='FTEs', color = 'purple', marker="o", markersize=12)
            plt.annotate('Emperical Cluster FTE= ' +  str(round(recommended_FTE_cluster,1)) + ',' + '\nbased on:' + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(input_department.iloc[0][0]) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(input_department.iloc[0][1]) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(input_department.iloc[0][2]) , xy=(pctl_recommendedFTE_model_cluster, recommended_FTE_cluster), textcoords="offset points", xytext=(-190, 100),
                        arrowprops=dict(facecolor='black', shrink=0.1))
            # plt.plot(pctl_recommendedFTE_average, average_model_emperical_recommendedFTE, label='FTEs', color='olive', marker="o", markersize=12)
            # plt.annotate('Average FTE = ' +  str(round(average_model_emperical_recommendedFTE,1)) + ',' + '\nbased on:' + "\n" + staffs[staff]['variables'][0] + ": {:.0f}".format(input_department.iloc[0][0]) + ",\n" + staffs[staff]['variables'][1] + ": {:.0f}".format(input_department.iloc[0][1]) + ",\n" + staffs[staff]['variables'][2] + ": {:.0f}".format(input_department.iloc[0][2]) , xy=(pctl_recommendedFTE_average, average_model_emperical_recommendedFTE), textcoords="offset points", xytext=(200, -270),
            #             arrowprops=dict(facecolor='black', shrink=0.1))

            plt.xlabel('Percentiles of comparable days',fontsize=18)
            plt.ylabel('FTE - ' + staff,fontsize=18)
            # fig.tight_layout()
            # plt.show()
            figures.append(fig)
            
            if recommendedFTE_model == 0:
                recommendedFTE_model = float('nan')
            if recommendedFTE == 0:
                recommendedFTE_model = float('nan')
            if recommended_FTE_cluster == 0:
                recommended_FTE_cluster = float('nan')
            
            staff_table_model.append(round(recommendedFTE_model,1))   
            staff_table.append(round(recommendedFTE,1))
            staff_table_cluster.append(round(recommended_FTE_cluster,1))
            variables_max[staff] = max_variablegroups
        department_output_model.append(staff_table_model)
        department_output.append(staff_table)
        department_output_cluster.append(staff_table_cluster)
    output_table = pd.DataFrame(department_output, index = input_matrix[hotel].columns.date , columns = staffs.keys()).T
    output_table.name = 'Emperical'
    output_table.loc['Total'] = round(output_table.sum(numeric_only=True),1)
    output_table_model = pd.DataFrame(department_output_model, index = input_matrix[hotel].columns.date , columns = staffs.keys()).T
    output_table_model.name = 'Model'
    output_table_model.loc['Total'] = round(output_table_model.sum(numeric_only=True),1)
    output_table_cluster = pd.DataFrame(department_output_cluster, index = input_matrix[hotel].columns.date , columns = staffs.keys()).T
    output_table_cluster.name = 'Model'
    output_table_cluster.loc['Total'] = round(output_table_cluster.sum(numeric_only=True),1)
    
    max_variables = pd.DataFrame(variables_max).max(axis=1)
    # input_matrix = {
    # 'Model': ['Theoretical Model', 'Emperical Model', 'Emperical Cluster Model'],
    # 'Weight': [0.00, 0.50, 0.50]
    # }
    output_table_average = round((output_table * input_matrix['Weights']['Weight']['Emperical Model']) + output_table_model *input_matrix['Weights']['Weight']['Theoretical Model'] + output_table_cluster *input_matrix['Weights']['Weight']['Emperical Cluster Model'],1) 
    output_table_average.name = 'Average'

    parameters_backw = {'Dep_cleaning': parameters['Dep_cleaning'] * output_table_average.mean(axis=1).loc['Housekeeping']/output_table_model.mean(axis=1).loc['Housekeeping'], 'Occ_cleaning': parameters['Occ_cleaning'] * output_table_average.mean(axis=1).loc['Housekeeping']/output_table_model.mean(axis=1).loc['Housekeeping'],'common_m2': parameters['common_m2'], 'com_cleaning': parameters['com_cleaning'] * output_table_average.mean(axis=1).loc['Housekeeping']/output_table_model.mean(axis=1).loc['Housekeeping'] , 'rec_checkout': parameters['rec_checkout'] * (output_table_average.mean(axis=1).loc['Reception'] * 8 - parameters['rec_admin'])/(output_table_model.mean(axis=1).loc['Reception'] * 8 - parameters['rec_admin']), 'rec_checkin': parameters['rec_checkin'] * (output_table_average.mean(axis=1).loc['Reception'] * 8 - parameters['rec_admin'])/(output_table_model.mean(axis=1).loc['Reception'] * 8 - parameters['rec_admin']), 'rec_sd':  parameters['rec_sd'] * (output_table_average.mean(axis=1).loc['Reception'] * 8 - parameters['rec_admin'])/(output_table_model.mean(axis=1).loc['Reception'] * 8 - parameters['rec_admin']), 'wai_breakfast':  parameters['wai_breakfast'] * (output_table_average.mean(axis=1).loc['Waitering'] * 8 - 2*parameters['wai_prep'])/(output_table_model.mean(axis=1).loc['Waitering'] * 8 - 2*parameters['wai_prep']), 'wai_halfboards': parameters['wai_halfboards'] * (output_table_average.mean(axis=1).loc['Waitering'] * 8 - 2*parameters['wai_prep'])/(output_table_model.mean(axis=1).loc['Waitering'] * 8 - 2*parameters['wai_prep']), 'wai_sd': parameters['wai_sd'] * (output_table_average.mean(axis=1).loc['Waitering'] * 8 - 2*parameters['wai_prep'])/(output_table_model.mean(axis=1).loc['Waitering'] * 8 - 2*parameters['wai_prep']), 'kit_breakfast': parameters['kit_breakfast'] * (output_table_average.mean(axis=1).loc['Kitchen'] * 8 - parameters['kit_breakfast_prep'] -  parameters['kit_halfboard_prep'] - parameters['kit_storing'])/(output_table_model.mean(axis=1).loc['Kitchen'] * 8 - parameters['kit_breakfast_prep'] -  parameters['kit_halfboard_prep'] - parameters['kit_storing']), 'kit_halfboards': parameters['kit_halfboards'] * (output_table_average.mean(axis=1).loc['Kitchen'] * 8 - parameters['kit_breakfast_prep'] -  parameters['kit_halfboard_prep'] - parameters['kit_storing'])/(output_table_model.mean(axis=1).loc['Kitchen'] * 8 - parameters['kit_breakfast_prep'] -  parameters['kit_halfboard_prep'] - parameters['kit_storing']), 'kit_dishwashing': parameters['kit_dishwashing'] * (output_table_average.mean(axis=1).loc['Kitchen'] * 8 - parameters['kit_breakfast_prep'] -  parameters['kit_halfboard_prep'] - parameters['kit_storing'])/(output_table_model.mean(axis=1).loc['Kitchen'] * 8 - parameters['kit_breakfast_prep'] -  parameters['kit_halfboard_prep'] - parameters['kit_storing'])}


    # Zorg dat je 1 week kan invullen en dat hij dan doorrekent voor alle afdelingen.
    # output naar PDF
    # output_tables = pd.concat([pd.concat([pd.concat([output_table_average, pd.DataFrame([['', '', '', '', '', '', ''], ], columns = output_table.columns, index = [None])]),pd.concat([output_table_model,pd.DataFrame([['', '', '', '', '', '', ''], ], columns = output_table.columns, index = [None])])]),output_table])
    # total_table = pd.concat([pd.concat([output_table_average, pd.DataFrame([['', '', '', '', '', '', ''], ['', '', '', '', '', '', '']], columns = output_table.columns, index = [None,'Based on:'])]), input_matrix])
    total_table = pd.concat([pd.concat([pd.concat([pd.DataFrame(input_matrix[hotel], columns = output_table_average.columns), pd.DataFrame(round(input_matrix[hotel].mean(axis=1)).astype('Int64'), columns = ['Average'])], axis=1),pd.DataFrame([['', '', '', '', '', '', '', '']], columns = output_table_average.columns.tolist() + ['Average'], index = [None])]), pd.concat([pd.DataFrame(output_table_average, columns = output_table_average.columns), pd.DataFrame(round(output_table_average.mean(axis=1)).astype('Int64'), columns = ['Average']).replace(pd.NA,-1).astype(int).replace(-1, np.nan)], axis=1)])
    total_table2 =pd.concat([pd.concat([output_table_model, pd.DataFrame([['', '', '', '', '', '', '']], columns = output_table_average.columns, index = [None])]), pd.concat([output_table, pd.DataFrame([['', '', '', '', '', '', '']], columns = output_table_average.columns, index = [None])]),output_table_cluster])
    total_table3 = pd.concat([pd.concat([pd.concat([pd.concat([pd.DataFrame(input_matrix[hotel], columns = output_table.columns), pd.DataFrame([['', '', '', '', '', '', '']], columns = output_table_average.columns, index = [None])]), output_table_average]),output_table_model]),output_table])

    all_tables[hotel] = total_table
    all_tables2[hotel] = total_table2
    from matplotlib.backends.backend_pdf import PdfPages
    alternating_colors2 =  [['green'] * (len(total_table.columns)-1)] * len(output_table_model) +   [['#FFFFFF']* (len(total_table.columns)-1)] + [['orange']  * (len(total_table.columns)-1) ]* len(output_table) + [['#FFFFFF']* (len(total_table.columns)-1)] + [['purple']  * (len(total_table.columns)-1) ]* len(output_table_cluster)
    alternating_colors = [['#FFFFFF']* len(total_table.columns)] * (len(input_matrix[hotel])+1) + [['olive'] * len(total_table.columns)] * (len(output_table_average))
    alternating_colors3 = [['#FFFFFF']* len(total_table.columns)] * (len(input_matrix[hotel])+1) + [['olive'] * len(total_table.columns)] * len(output_table_average) + [['green'] * len(total_table.columns)] * len(output_table_model) + [['orange'] * len(total_table.columns)] * len(output_table)

    # alternating_colors = [['green'] * len(output_table_average.columns)] * len(output_table_average)
    import numpy as np
    import matplotlib.pyplot as plt

    fig, ax1 = plt.subplots(figsize=(21, 15))
    table = ax1.table(cellText=total_table.values,
                    colLabels=total_table.columns,
                    loc='center',
                    rowLabels=total_table.index,
                    cellColours=alternating_colors,
                    rowColours=['#B0B3A9']*len(total_table),
                    colColours=['#B0B3A9']*len(total_table.columns),
                    colWidths=[0.065 for x in total_table.columns])
    table.scale(1, 2.4)
    table.set_fontsize(13)
    # plt.legend(loc='best')
    ax1.axis('off')
    # fig.tight_layout()
    ax1.axis('tight')
    title = "FTE recommendation: " + hotel + " - week " + str(datetime.datetime.today().isocalendar().week) + ' ' + str(datetime.datetime.today().isocalendar().year)
    subtitle = "This weeks daily required FTE"
    ax1.set_title(f'{title}\n{subtitle}', weight='bold', size=40, color='k')
    text_firstpage1 = 'Recommended FTE'
    # text_firstpage2 = 'Model'
    # text_firstpage3 = 'Emperical Minimum'
    text_firstpage4 = 'Assumptions'
    ax1.text(0.125 ,0.375,text_firstpage1, transform=fig.transFigure, size=15, ha="center", va = "top", weight='bold')
    # ax1.text(0.125,0.615,text_firstpage2, transform=fig.transFigure, size=15, ha="center", va = "top", weight='bold')
    # ax1.text(0.125,0.490,text_firstpage3, transform=fig.transFigure, size=15, ha="center", va = "top", weight='bold')
    ax1.text(0.125,0.55,text_firstpage4, transform=fig.transFigure, size=15, ha="center", va = "top", weight='bold')



    # ax1.text(x=0.0000, y=0.014, s="Housekeepers' FTE can be determined as follows. \n(1) Housekeepers needed to clean \'departed\' rooms during peak hours \n(2) Housekeepers needed to refresh occupied rooms during the day \n(3) Housekeepers to clean the common areas \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg. 20 \'departed' rooms, 120 occupied rooms, check-in 16:00 and check-out 12:00 \nIf it takes 30mins to clean a room, 15min to refresh it and the hotel has a common \narea of 1000m2 that takes 1 min per m2 every 4 days to clean, we need at most:\n\n- (20 * 0.5) = 10 hours for cleaning the rooms of leaving guests, as well as \n- (120 * 0.25)  = 30 hours for refreshing rooms and \n- ((1000 * 1/60) / 4) = 4 hours for the common areas\n Totalling 44 hours of work or 5.5 FTE",  fontsize=16)
    # ax1.text(x=0, y=0.0, s="Given the number of <inputs>, the average time for <department> to do <activity> is approximately <regingeneerd output>",  fontsize=12)
    pp = PdfPages("Recommended_FTE_week_" + hotel +'_'+ str(datetime.datetime.today().isocalendar().week) + '_' + str(datetime.datetime.today().isocalendar().year) + ".pdf")
    pp.savefig(fig)
    
    SecondPage = plt.figure(figsize=(21, 15))
    SecondPage.clf()   
    
    if parameters_backw['Dep_cleaning'] >0 and parameters_backw['Occ_cleaning'] >0 and parameters_backw['com_cleaning'] >0:
        text_housekeeping = 'For Housekeeping, this means that: \ndeparted rooms need to be cleaned in about ' + str(round(parameters_backw['Dep_cleaning'] * 60,1)) + ' minutes on average,\noccupied rooms need to be cleaned in about '+ str(round(parameters_backw['Occ_cleaning'] * 60,1)) + ' minutes\nand common areas m2 need to be cleaned in ' +  str(round(parameters_backw['com_cleaning'] * 60,1)) + ' minutes every ' + str(int(round(parameters['clean_days']))) + ' days, assuming ' + str(int(round(parameters_backw['common_m2']))) + 'm2 of common area.\n\n'
        if input_matrix[hotel].loc['Occupied Rooms'].max() >= max_variables['OccRoomsGroups']:
            notes_housekeeping = 'In the past, the number of occupied rooms has never been higher than ' + str(int(max_variables['OccRoomsGroups'])) + ',\nwhich might disturb the calculations for housekeeping as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Occupied Rooms']) + '.\n\n'
        elif input_matrix[hotel].loc['Departed Rooms'].max() >= max_variables['DepRoomsGroups']:
            notes_housekeeping = 'In the past, the number of departed rooms has never been higher than ' + str(int(max_variables['DepRoomsGroups'])) + ',\nwhich might disturb the calculations for housekeeping as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Departed Rooms']) + '.\n\n'     
        elif input_matrix[hotel].loc['Guests'].max() >= max_variables['GuestsGroup']:
            notes_housekeeping = 'In the past, the number of guests has never been higher than ' + str(int(max_variables['GuestsGroup'])) + ',\nwhich might disturb the calculations for housekeeping as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Guests']) + '.\n\n'                      
        else:
            notes_housekeeping = ''
    else:
        text_housekeeping = ''
        notes_housekeeping = ''
    if parameters_backw['rec_checkin'] >0 and parameters_backw['rec_checkout'] >0 and parameters_backw['rec_sd'] > 0:
        text_reception = 'For Reception, this implies that:\ndeparting guests should take about ' + str(round(parameters_backw['rec_checkout'] * 60,1)) + ' minutes to check-out for a receptionist,\narriving guests should take about '  + str(round(parameters_backw['rec_checkin'] * 60,1)) + ' minutes to check-in,\nguests in general should take (on average) roughly ' + str(round(parameters_backw['rec_sd']*60,1)) + ' minutes of additional time for a receptionist\nand a receptionist should not spend more than '+str(int(round(parameters['rec_admin']))) +' hours on administration time.\n\n'
        if input_matrix[hotel].loc['New Guests'].max() >= max_variables['NewGuestsGroup']:
            notes_reception = 'In the past, the number of new guests has never been higher than ' + str(int(max_variables['NewGuestsGroup'])) + ',\nwhich might disturb the calculations for reception as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['New Guests']) + '.\n\n'
        elif input_matrix[hotel].loc['Departing Guests'].max() >= max_variables['DepGuestsGroup']:
            notes_reception = 'In the past, the number of departing guests has never been higher than ' + str(int(max_variables['DepGuestsGroup'])) + ',\nwhich might disturb the calculations for reception as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Departing Guests']) + '.\n\n'            
        elif input_matrix[hotel].loc['Guests'].max() >= max_variables['GuestsGroup']:
            notes_reception = 'In the past, the number of guests has never been higher than ' + str(int(max_variables['GuestsGroup'])) + ',\nwhich might disturb the calculations for the number of receptionists as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Guests']) + '.\n\n'  
        else:
            notes_reception = ''
    else:
        text_reception = ''
        notes_reception = ''
    if parameters_backw['wai_breakfast'] > 0 and parameters_backw['wai_halfboards'] > 0 and parameters_backw['wai_sd'] >0:
        text_waitering = 'For Waitering, this implies that:\nit should take about ' +str(round(parameters_backw['wai_breakfast']*60,1)) + ' minutes to table set and waiter per ordered breakfast,\nit should take about ' +str(round(parameters_backw['wai_halfboards']*60,1)) + ' minutes to table set and waiter per dining guest, \nas well as '+ str(int(round(parameters['wai_prep'])))+ ' hours for pre-breakfast and pre-dinner preperation, and\nsecondairy duties such as bartending should take about '+str(round(parameters_backw['wai_sd']*60,1)) + ' minutes per guest on average.\n\n'
        if input_matrix[hotel].loc['Breakfasts'].max() >= max_variables['BreakfastsGroup']:
            notes_waitering = 'In the past, the number of new guests has never been higher than ' + str(int(max_variables['BreakfastsGroup'])) + ',\nwhich might disturb the calculations for waitering as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Breakfasts']) + '.\n\n'
        elif input_matrix[hotel].loc['Halfboards'].max() >= max_variables['HalfboardsGroup']:
            notes_waitering = 'In the past, the number of departing guests has never been higher than ' + str(int(max_variables['HalfboardsGroup'])) + ',\nwhich might disturb the calculations for waitering as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Halfboards']) + '.\n\n'            
        elif input_matrix[hotel].loc['Guests'].max() >= max_variables['GuestsGroup']:
            notes_waitering = 'In the past, the number of guests has never been higher than ' + str(int(max_variables['GuestsGroup'])) + ',\nwhich might disturb the calculations for the number of waiters as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Guests']) + '.\n\n'  
        else:
            notes_waitering = ''
    else:
        text_waitering = ''
        notes_waitering = ''
    if parameters_backw['kit_breakfast'] >0 and parameters_backw['kit_halfboards'] > 0 and parameters_backw['kit_dishwashing'] >0:
        text_kitchen = 'For Kitchen staff this means that:\nculinairy operations take about ' + str(round(parameters_backw['kit_breakfast']*60,1)) + ' minutes during breakfast,\ncooking and culinairy operations should take about ' + str(round(parameters_backw['kit_halfboards']*60,1)) + ' minutes during dinner, \nadditionally breakfast preperation should take roughly '+str(int(round(parameters['kit_breakfast_prep']))) + ' hours and dinner preperation roughly '+str(int(round(parameters['kit_halfboard_prep']))) +' hours. \nFinally, storing duties should take about '+str(int(round(parameters['kit_storing']))) +' hours and dishwashing should take about ' + str(round(parameters_backw['kit_dishwashing']*60,1)) + ' minutes per dish.'
        if input_matrix[hotel].loc['Breakfasts'].max() >= max_variables['BreakfastsGroup']:
            notes_kitchen = 'In the past, the number of new guests has never been higher than ' + str(int(max_variables['BreakfastsGroup'])) + ',\nwhich might disturb the calculations for kitchen staff as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Breakfasts']) + '.\n\n'
        elif input_matrix[hotel].loc['Halfboards'].max() >= max_variables['HalfboardsGroup']:
            notes_kitchen = 'In the past, the number of departing guests has never been higher than ' + str(int(max_variables['HalfboardsGroup'])) + ',\nwhich might disturb the calculations for kitchen staff as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Halfboards']) + '.\n\n'         
        elif input_matrix[hotel].loc['Guests'].max() >= max_variables['GuestsGroup']:
            notes_kitchen = 'In the past, the number of guests has never been higher than ' + str(int(max_variables['GuestsGroup'])) + ',\nwhich might disturb the calculations for the number of waiters as this weeks\' average is ' + str(input_matrix[hotel].mean(axis=1).astype(int)['Guests']) + '.\n\n'  
        else:
            notes_kitchen = ''    
    else:
        text_kitchen = ''
        notes_kitchen = ''
        
    if notes_housekeeping == '' and notes_reception == '' and notes_waitering == '' and notes_kitchen == '':
         notes_general = '-'
    else:
        notes_general = ''
        
    plt.axis('off')
    txttitle = "Implications for department tasks"

    text_firstpage5 = r"$\bf{" + 'This\ weeks\'\ average\ production\ times' + "}$" + '\n' + text_housekeeping + text_reception + text_waitering + text_kitchen + notes_general

    text_firstpage6 = r"$\bf{" + 'Notes' + "}$" +'\n' + notes_housekeeping + notes_reception + notes_waitering + notes_kitchen

    SecondPage.text(0.075,0.85, text_firstpage5, transform=SecondPage.transFigure, size=15, ha="left", va = "top")
    SecondPage.text(0.075,0.475, text_firstpage6, transform=SecondPage.transFigure, size=15, ha="left", va = "top")

    SecondPage.text(0.5,0.95,txttitle, transform=SecondPage.transFigure, size=40, ha="center", va = "top", weight='bold')

    pp.savefig()
    plt.close()


    firstPage = plt.figure(figsize=(21, 15))
    firstPage.clf()
    txtHSK = r"$\bf{" + 'Housekeeping' + "}$" + "\nHousekeepers' FTE can be modelled as follows. \n(1) Housekeepers needed to clean \'departed\' rooms during peak hours \n(2) Housekeepers needed to refresh occupied rooms during the day \n(3) Housekeepers to clean the common areas \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg. 20 \'departed' rooms, 120 occupied rooms, check-in 16:00, check-out 12:00 \nIf it takes 30min to clean a room, 15min to refresh it and the common area \nis 1000m2 and takes 1 min per m2 every 2 days to clean, we need at most:\n\n(1) (20 * 0.5) = 10 hours for cleaning the rooms of leaving guests, as well as \n(2) (120 * 0.25)  = 30 hours for refreshing rooms and \n(3) ((1000 * 1/60) / 2) = 4 hours for the common areas\n(4) Totalling 44 hours of work or 5.5 FTE\nNote: If the rooms need to be cleaned between check-in and check-out time, \nthen 10 + 15 + 2 = 27 hours or 3.4 FTE will be spend during peak hours"
    #\n\n\nHousekeepers' FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
    txtREZ = r"$\bf{" + 'Reception' + "}$" + "\nReceptionists' FTE can be modelled as follows. \n(1) Receptionists needed during (peak) check-in times\n(2) Receptionists needed during (peak) check-out times\n(3) Receptionists needed during regular hours \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg.50 arriving guests, 30 departing guests, check-in peak start 16:00\nand check-in peak end 20:00. Furthermore check-out peak starts at 07:00\nand ends at 10:00. 90% of guests come during peak hours.\nThere are in total 200 guests in the hotel that day.\nAlso, administrative time takes up to 2 hours every day and\nother secondary duties time depends on the number of guests. \nIf it takes 20min to check-in, 10min to check-out a guest and 2 min\nper staying guest for secondairy duties, then we need at most:\n\n(1) (0.33 * 50) * 0.9 = 15 hours during check-in peak, and\n(2) (0.17 * 30) * 0.9 = 4.5 hours during check-out peak, and\n(3) (0.33 * 50) * 0.1 + (0.17 * 30) * 0.1 + 2 = 1.7 hours during non peak time\n+ 2 hours of administrative and 200 * 1/30 = 6 hours of secondary duties time\nequals 10 hours of regular time\n(4) Totalling 30 hours of work or 4 FTE\nNote: 15 + 10 / 8 * 3 = 19 hours or about 2.5 FTE in the 3 hour check-in peak."
    #\n\nReceptionists' FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
    txtSERVICE = r"$\bf{" + 'Waitering' + "}$" + "\nWaiters' FTE can be modelled as follows. \n(1) Waiters needed during breakfast\n(2) Waiters needed during dinner time\n(3) Waiters needed for secondary duties during regular hours \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg. 110 breakfasts, 120 dinners. Breakfast starts 06:30 and breakfast ends at 10:00.\nFurthermore dinner starts at 18:00 and ends at 22:00. There are in total 200 guests in \nthe hotel that day. Also, pre-breakfast and pre-dinner preperation takes up to 2 hours\nevery day and bartending and other secondary duties depend on the number of guests.\nIf it takes 6min per breakfast, 12min per dinner to table set and waiter, and 1min per \nstaying guest for secondary duties, then we need at most:\n\n(1) 2 + 1/10 * 110 = 13 hours during breakfast, and\n(2) 2 + 1/5 * 120  = 26 hours during dinner, and\n(3) 1/60 * 200  = 3 hours during regular hours \n(4) Totalling 25 hours of work or 5 FTE."
    #\n\nWaiters' FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
    txtKÜCHE= r"$\bf{" + 'Kitchen' + "}$" + "\nKitchen staff FTE can be modelled as follows. \n(1) Kitchen staff needed during breakfast\n(2) Kitchen staff needed during dinner time\n(3) sum these for the hours worked throughout the day and divide by 8\n\nEg. 110 breakfasts, 120 dinners. Breakfast preperation starts 05:30 and ends at 06:30.\nFurthermore dinner preperation starts at 16:00 and ends at 18:00. If it takes \n3min per breakfast and 10min per dinner to cook and perform other culinairy operations\n, and kitchen storing takes 1 hour, while cleaning and dishwashishing takes 2min\n per meal, then we need at most:\n\n(1) 1 + 1/20 * 110 = 8.5 hours breakfast prep, 1 + 1/30 * 110 = 5 hours cleaning, and\n(2) 2 + 1/6 * 120  = 22 hours dinner prep, 1 + 1/30 * 120 = 5 hours cleaning.\n(4) Totalling 40.5 hours of work or 5 FTE."
    #\n\n\n\n\n\n\n\n\n\nKitchen staff FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
    text_model1 = '●'
    text_emperical1 = '●' 
    text_model2 = '●'
    text_emperical2 = '●'
    plt.axis('off')

    txttitle = "Current FTE calculations"

    firstPage.text(0.075,0.85,txtHSK, transform=firstPage.transFigure, size=15, ha="left", va = "top")
    firstPage.text(0.075,0.475,txtREZ, transform=firstPage.transFigure, size=15, ha="left", va = "top")
    firstPage.text(0.510,0.85,txtSERVICE, transform=firstPage.transFigure, size=15, ha="left", va = "top")
    firstPage.text(0.510,0.475,txtKÜCHE, transform=firstPage.transFigure, size=15, ha="left", va = "top")

    firstPage.text(0.06,0.825,text_model1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
    # firstPage.text(0.06,0.55,text_emperical1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')

    firstPage.text(0.06,0.450,text_model2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
    # firstPage.text(0.06,0.1,text_emperical2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')

    firstPage.text(0.495,0.825,text_model1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
    # firstPage.text(0.495,0.55,text_emperical1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')

    firstPage.text(0.495,0.450,text_model2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
    # firstPage.text(0.495,0.1,text_emperical2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')


    firstPage.text(0.5,0.95,txttitle, transform=firstPage.transFigure, size=40, ha="center", va = "top", weight='bold')

    pp.savefig()
    plt.close()
    # for figure in figures:
    #     pp.savefig(figure)
    pp.close()
    all_figures[hotel] = figures
appendix = PdfPages("Recommended_FTE_week_" + str(datetime.datetime.today().isocalendar().week) + '_' + str(datetime.datetime.today().isocalendar().year) + "_Appendix.pdf")
firstPage = plt.figure(figsize=(21, 15))
firstPage.clf()
txtHSK = r"$\bf{" + 'FTE\'s\ on\ comparable\  days' + "}$" + "\nThe graphs on the following pages show how the - modeled number of FTE\'s - compare to the FTE\'s employed on comparable days in the past. \nIn this context, a day is similar if the relevant input variables on that day were similar. \nFor example, for housekeeping, these input variables are the number of departed rooms, number of occupied rooms and the number of guests.\nWhen tomorrow there are 30 departed rooms, 100 occupied rooms and 200 guests, that day is pretty similar to a day where say, there were 25, 95 and 210, respecively. \nWe can implement an algorithm to search for those similar days and see how many FTE\'s in each department was used. This information can then be shown in graph format.\n- In the graphs, the green dot repesents the modeled number of FTE's of the department on a specific day, according to our staffing model \n- The orange dot represents the best 15% (minimal) of FTE\'s needed in the past on similar days \n- On the y-axis we see the number of FTE\'s\n- On the x-axis we see the percentile of best days (minimal FTE\'s). For example, at 0.5 (median), in 50% of the similar days, there were more (less) FTE's \nthan at the corresponding point on the blue graph.\nIn case a limited number of blue dots are shown (or the blue graph doesn't show up at all), that means that there were only a limited number of similar days (or none at all)"
txtREZ = r"$\bf{" + 'Why\ are\ the\  graphs \ usefull?' + "}$" + "\nThe graphs can be used to compare the (theoretical) modeled optimal FTE with the FTE\'s employed (emperically) by the hotel manager. \nBy comparing these two, it can be observed (1) whether the modeled optimum is realistic and (2) whether the modeled optimum has reasonable likelihood of being achieved."

text_model1 = '●'
text_emperical1 = '●' 
text_model2 = '●'
text_emperical2 = '●'
plt.axis('off')

txttitle = "Appendix - Graph Explanations"

firstPage.text(0.075,0.85,txtHSK, transform=firstPage.transFigure, size=15, ha="left", va = "top")
firstPage.text(0.075,0.625,txtREZ, transform=firstPage.transFigure, size=15, ha="left", va = "top")
# firstPage.text(0.510,0.85,txtSERVICE, transform=firstPage.transFigure, size=15, ha="left", va = "top")
# firstPage.text(0.510,0.475,txtKÜCHE, transform=firstPage.transFigure, size=15, ha="left", va = "top")

firstPage.text(0.06,0.825,text_model1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'blue', weight='bold')
firstPage.text(0.06,0.60,text_model2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'blue', weight='bold')



firstPage.text(0.5,0.95,txttitle, transform=firstPage.transFigure, size=40, ha="center", va = "top", weight='bold')

appendix.savefig()
for figures in all_figures:
    
    print("Appending " + figures + " to the Appendix report")
    for figure in all_figures[figures]:
        appendix.savefig(figure)
appendix.close()

from matplotlib.gridspec import GridSpec

hq_report = PdfPages("Recommended_FTE_week_" + str(datetime.datetime.today().isocalendar().week) + '_' + str(datetime.datetime.today().isocalendar().year) + "_HQ.pdf")
fig = plt.figure(figsize=(42, 30))
plt.tight_layout()
# plt.rcParams["figure.figsize"] = (20,10)
# plt.subplots_adjust(wspace=0.05, hspace=0.05)
G = GridSpec(5,5)
G.update(wspace=0.05, hspace=0.1)   
col_counter = 0
row_counter = 0
for tables in all_tables:
    print("Appending " + tables + " to the HQ report")
    if row_counter % 5 == 0 and row_counter > 0 and col_counter < 5:
        col_counter +=1
        row_counter = 0
    axes_1 = plt.subplot(G[row_counter, col_counter])
    table2 = axes_1.table(cellText=all_tables[tables].values,
                    colLabels=all_tables[tables].columns,
                    loc='best',
                    rowLabels=all_tables[tables].index,
                    cellColours=alternating_colors,
                    rowColours=['#B0B3A9']*len(all_tables[tables]),
                    colColours=['#B0B3A9']*len(all_tables[tables].columns),
                    colWidths=[0.10 for x in all_tables[tables].columns]) 
    axes_1.axis('off')
    axes_1.axis('tight')  
    axes_1.set_title(tables, fontsize=8, y=0.965) 
    table2.set_fontsize(30)
    table2.scale(1, 0.9)
    # plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
    row_counter +=1
hq_report.savefig(fig, bbox_inches='tight')

fig = plt.figure(figsize=(42, 30))
plt.tight_layout()
# plt.rcParams["figure.figsize"] = (20,10)
# plt.subplots_adjust(wspace=0.05, hspace=0.05)
G = GridSpec(5,5)
G.update(wspace=0.05, hspace=0.1)   
col_counter = 0
row_counter = 0
for tables in all_tables2:
    print("Appending " + tables + " to the HQ report")
    if row_counter % 5 == 0 and row_counter > 0 and col_counter < 5:
        col_counter +=1
        row_counter = 0
    axes_1 = plt.subplot(G[row_counter, col_counter])
    table2 = axes_1.table(cellText=all_tables2[tables].values,
                    colLabels=all_tables2[tables].columns,
                    loc='best',
                    rowLabels=all_tables2[tables].index,
                    cellColours=alternating_colors2,
                    rowColours=['#B0B3A9']*len(all_tables2[tables]),
                    colColours=['#B0B3A9']*len(all_tables2[tables].columns),
                    colWidths=[0.10 for x in all_tables2[tables].columns]) 
    axes_1.axis('off')
    axes_1.axis('tight')   
    axes_1.set_title(tables, fontsize=8, y=0.965) 
    table2.set_fontsize(30)
    table2.scale(1, 0.9)
    # plt.subplots_adjust(left=None, bottom=None, right=None, top=None, wspace=None, hspace=None)
    row_counter +=1
plt.tight_layout()
hq_report.savefig(fig, bbox_inches='tight')


firstPage = plt.figure(figsize=(21, 15))
firstPage.clf()
txtHSK = r"$\bf{" + 'Housekeeping' + "}$" + "\nHousekeepers' FTE can be modelled as follows. \n(1) Housekeepers needed to clean \'departed\' rooms during peak hours \n(2) Housekeepers needed to refresh occupied rooms during the day \n(3) Housekeepers to clean the common areas \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg. 20 \'departed' rooms, 120 occupied rooms, check-in 16:00, check-out 12:00 \nIf it takes 30min to clean a room, 15min to refresh it and the common area \nis 1000m2 and takes 1 min per m2 every 2 days to clean, we need at most:\n\n(1) (20 * 0.5) = 10 hours for cleaning the rooms of leaving guests, as well as \n(2) (120 * 0.25)  = 30 hours for refreshing rooms and \n(3) ((1000 * 1/60) / 2) = 4 hours for the common areas\n(4) Totalling 44 hours of work or 5.5 FTE\nNote: If the rooms need to be cleaned between check-in and check-out time, \nthen 10 + 15 + 2 = 27 hours or 3.4 FTE will be spend during peak hours\n\n\nHousekeepers' FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
txtREZ = r"$\bf{" + 'Reception' + "}$" + "\nReceptionists' FTE can be modelled as follows. \n(1) Receptionists needed during (peak) check-in times\n(2) Receptionists needed during (peak) check-out times\n(3) Receptionists needed during regular hours \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg.50 arriving guests, 30 departing guests, check-in peak start 16:00\nand check-in peak end 20:00. Furthermore check-out peak starts at 07:00\nand ends at 10:00. 90% of guests come during peak hours.\nThere are in total 200 guests in the hotel that day.\nAlso, administrative time takes up to 2 hours every day and\nother secondary duties time depends on the number of guests. \nIf it takes 20min to check-in, 10min to check-out a guest and 2 min\nper staying guest for secondairy duties, then we need at most:\n\n(1) (0.33 * 50) * 0.9 = 15 hours during check-in peak, and\n(2) (0.17 * 30) * 0.9 = 4.5 hours during check-out peak, and\n(3) (0.33 * 50) * 0.1 + (0.17 * 30) * 0.1 + 2 = 1.7 hours during non peak time\n+ 2 hours of administrative and 200 * 1/30 = 6 hours of secondary duties time\nequals 10 hours of regular time\n(4) Totalling 30 hours of work or 4 FTE\nNote: 15 + 10 / 8 * 3 = 19 hours or about 2.5 FTE in the 3 hour check-in peak.\n\nReceptionists' FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
txtSERVICE = r"$\bf{" + 'Waitering' + "}$" + "\nWaiters' FTE can be modelled as follows. \n(1) Waiters needed during breakfast\n(2) Waiters needed during dinner time\n(3) Waiters needed for secondary duties during regular hours \n(4) sum these for the hours worked throughout the day and divide by 8\n\nEg. 110 breakfasts, 120 dinners. Breakfast starts 06:30 and breakfast ends at 10:00.\nFurthermore dinner starts at 18:00 and ends at 22:00. There are in total 200 guests in \nthe hotel that day. Also, pre-breakfast and pre-dinner preperation takes up to 2 hours\nevery day and bartending and other secondary duties depend on the number of guests.\nIf it takes 6min per breakfast, 12min per dinner to table set and waiter, and 1min per \nstaying guest for secondary duties, then we need at most:\n\n(1) 2 + 1/10 * 110 = 13 hours during breakfast, and\n(2) 2 + 1/5 * 120  = 26 hours during dinner, and\n(3) 1/60 * 200  = 3 hours during regular hours \n(4) Totalling 25 hours of work or 5 FTE.\n\nWaiters' FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
txtKÜCHE= r"$\bf{" + 'Kitchen' + "}$" + "\nKitchen staff FTE can be modelled as follows. \n(1) Kitchen staff needed during breakfast\n(2) Kitchen staff needed during dinner time\n(3) sum these for the hours worked throughout the day and divide by 8\n\nEg. 110 breakfasts, 120 dinners. Breakfast preperation starts 05:30 and ends at 06:30.\nFurthermore dinner preperation starts at 16:00 and ends at 18:00. If it takes \n3min per breakfast and 10min per dinner to cook and perform other culinairy operations\n, and kitchen storing takes 1 hour, while cleaning and dishwashishing takes 2min\n per meal, then we need at most:\n\n(1) 1 + 1/20 * 110 = 8.5 hours breakfast prep, 1 + 1/30 * 110 = 5 hours cleaning, and\n(2) 2 + 1/6 * 120  = 22 hours dinner prep, 1 + 1/30 * 120 = 5 hours cleaning.\n(4) Totalling 40.5 hours of work or 5 FTE.\n\n\n\n\n\n\n\n\n\nKitchen staff FTE can be emperically validated by \n(1) Determining the distribution of FTE's used in the past on similar days \n(2) Approximating the minimum FTE used on those similar days"
text_model1 = '●'
text_emperical1 = '●' 
text_model2 = '●'
text_emperical2 = '●'
plt.axis('off')

txttitle = "Current FTE calculations"

firstPage.text(0.075,0.85,txtHSK, transform=firstPage.transFigure, size=15, ha="left", va = "top")
firstPage.text(0.075,0.475,txtREZ, transform=firstPage.transFigure, size=15, ha="left", va = "top")
firstPage.text(0.510,0.85,txtSERVICE, transform=firstPage.transFigure, size=15, ha="left", va = "top")
firstPage.text(0.510,0.475,txtKÜCHE, transform=firstPage.transFigure, size=15, ha="left", va = "top")

firstPage.text(0.06,0.825,text_model1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
firstPage.text(0.06,0.55,text_emperical1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')

firstPage.text(0.06,0.450,text_model2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
firstPage.text(0.06,0.1,text_emperical2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')

firstPage.text(0.495,0.825,text_model1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
firstPage.text(0.495,0.55,text_emperical1, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')

firstPage.text(0.495,0.450,text_model2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'green', weight='bold')
firstPage.text(0.495,0.1,text_emperical2, transform=firstPage.transFigure, size=15, ha="left", va = "top", c = 'orange', weight='bold')


firstPage.text(0.5,0.95,txttitle, transform=firstPage.transFigure, size=40, ha="center", va = "top", weight='bold')

hq_report.savefig()
plt.tight_layout()

hq_report.close()



























# APPENDIX: PLOTS FOR REFERENCE
# housekeepers = total[['DepRoomsGroups', 'OccRoomsGroups', 'GuestsGroup', 'FTE_HSK', 'Hotel']]
# housekeepers.set_index('Hotel', inplace=True)

# receptionists = total[['NewGuestsGroup', 'DepGuestsGroup', 'GuestsGroup', 'FTE_REZ', 'Hotel']]
# receptionists.set_index('Hotel', inplace=True)

# waiters = total[['BreakfastsGroup', 'HalfboardsGroup', 'GuestsGroup', 'FTE_SERVICE', 'Hotel']]
# waiters.set_index('Hotel', inplace=True)

# kitchen = total[['BreakfastsGroup', 'HalfboardsGroup', 'GuestsGroup', 'FTE_KÜCHE', 'Hotel']]
# kitchen.set_index('Hotel', inplace=True)



# fig = plt.figure(figsize=(10, 10))
# ax = plt.axes(projection='3d')
# totalplot = ax.scatter3D(housekeepers.loc['VFB']['DepRoomsGroups'], housekeepers.loc['VFB']['OccRoomsGroups'], housekeepers.loc['VFB']['FTE_HSK'], c=housekeepers.loc['VFB']['GuestsGroup'])
# plt.title("Number of Housekeepers used per Departed and Occupied Rooms")
# ax.set_xlabel('Departed Rooms')
# ax.set_ylabel('Occupied Rooms')
# ax.set_zlabel('Housekeepers')
# fig.colorbar(totalplot, ax = ax, shrink = 0.5, aspect = 10, label = 'Guests', location='bottom')
# plt.show()

# fig = plt.figure(figsize=(10, 10))
# ax = plt.axes(projection='3d')
# totalplot = ax.scatter3D(receptionists.loc['VFB']['DepGuestsGroup'], receptionists.loc['VFB']['NewGuestsGroup'], receptionists.loc['VFB']['FTE_REZ'], c=receptionists.loc['VFB']['GuestsGroup'])
# plt.title("Number of Receptionists used per Departed and New Guests")
# ax.set_xlabel('Departed Guests')
# ax.set_ylabel('New Guests')
# ax.set_zlabel('Receptionists')
# fig.colorbar(totalplot, ax = ax, shrink = 0.5, aspect = 10, label = 'Guests', location='bottom')
# plt.show()

# fig = plt.figure(figsize=(10, 10))
# ax = plt.axes(projection='3d')
# totalplot = ax.scatter3D(waiters.loc['VFB']['BreakfastsGroup'], waiters.loc['VFB']['HalfboardsGroup'], waiters.loc['VFB']['FTE_SERVICE'], c=waiters.loc['VFB']['GuestsGroup'])
# plt.title("Number of Waiters used per Breakfasts and Dinners")
# ax.set_xlabel('Breakfasts')
# ax.set_ylabel('Dinners')
# ax.set_zlabel('Waiters')
# fig.colorbar(totalplot, ax = ax, shrink = 0.5, aspect = 10, label = 'Guests', location='bottom')
# plt.show()

# fig = plt.figure(figsize=(10, 10))
# ax = plt.axes(projection='3d')
# totalplot = ax.scatter3D(kitchen.loc['VFB']['BreakfastsGroup'], kitchen.loc['VFB']['HalfboardsGroup'], kitchen.loc['VFB']['FTE_KÜCHE'], c=kitchen.loc['VFB']['GuestsGroup'])
# plt.title("Number of Kitchen staff used per Breakfasts and Dinners")
# ax.set_xlabel('Breakfasts')
# ax.set_ylabel('Dinners')
# ax.set_zlabel('Kitchen staff')
# fig.colorbar(totalplot, ax = ax, shrink = 0.5, aspect = 10, label = 'Guests', location='bottom')
# plt.show()

# admins = total[['FTE_ADMIN', 'GuestsGroup', 'Hotel']].dropna()
# admins.set_index('Hotel', inplace=True)

# fig = plt.figure(figsize=(10, 10))
# plt.scatter(admins.loc['VZI']['FTE_ADMIN'], admins.loc['VZI']['GuestsGroup'], label='Positive', color='b', s=25, marker="o")
# plt.xlabel('Admins')
# plt.ylabel('Guests')
# plt.show()

# spa = total[['FTE_SPA/MASS', 'GuestsGroup', 'Hotel']].dropna()
# spa.set_index('Hotel', inplace=True)

# fig = plt.figure(figsize=(10, 10))
# plt.scatter(spa.loc['VZI']['FTE_SPA/MASS'], spa.loc['VZI']['GuestsGroup'], label='Positive', color='b', s=25, marker="o")
# plt.xlabel('SPA staff')
# plt.ylabel('Guests')
# plt.show()





print('Hello there!')

