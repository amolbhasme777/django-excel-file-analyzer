HOSTNAME = "localhost"
USERNAME = "root"
PASSWORD = "2uY2AHgKATKfCbbgfn"
DATABASE = "vaya_protel_prod"
