import logging
# import mysql.connector
# from mysql.connector import Error
import mariadb
import config
from mariadb import Error


class DatabaseConnection:
    def __init__(self):
        self.connection = None
        self.connect()

    def connect(self):
        """
        The `connect` function establishes a connection to a MariaDB database using the provided configuration
        parameters.
        """
        try:
            HOSTNAME = config.HOSTNAME
            USERNAME = config.USERNAME
            PASSWORD = config.PASSWORD
            DATABASE = config.DATABASE
            PORT = 3306

            self.connection = mariadb.connect(
                user=USERNAME,
                password=PASSWORD,
                host=HOSTNAME,
                port=PORT,
                database=DATABASE,
            )
        except Error as connection_error:
            logging.error(
                connection_error
            )

    def close(self):
        if self.connection is not None:
            self.connection.close()
