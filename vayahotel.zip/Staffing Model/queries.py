query_for_fetch_count = """
        SELECT SUM(`{column_name}`) 
        FROM meal_plan 
        where date = DATE_ADD(CURDATE(), INTERVAL %s Day) 
        AND property_id = %s
        """

query_for_hotel_details = """
            SELECT property_id, property_name FROM hotel_details
            """

query_for_hotel_status_all = '''SELECT hs.date_ as Date, hs.rooms_free as `Rooms Free`, hs.rooms_free_percent as `Rooms Free%`, hs.rooms_occ as `Rooms Occ`, hs.rooms_occ_percent as `Rooms Occ%`, hs.beds_percentage as `Beds%`, hs.arrival_rooms_count as `Arrival Rooms`, hs.arrival_persons_count as `Arrival Persons`, hs.leave_rooms_count as `Leave Rooms`, hs.leave_persons_count as `Leave Persons`, hs.inhouse_beds as `In House Beds`, hs.inhouse_persons as `In House Persons`, hs.logies as Logies, hs.fandb as `F&B`, hs.extras as Extras, hs.total as Total, hs.misc_count as `Misc#`, hs.misc_percent as `Misc%`, hs.property_id as `Hotel ID`
FROM (
    SELECT date_, MAX(created_on) AS max_created_on
    FROM hotel_status
    WHERE date_ BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 DAY)
    AND property_id = %s
    GROUP BY date_
) AS latest_dates
INNER JOIN hotel_status hs ON latest_dates.date_ = hs.date_ AND latest_dates.max_created_on = hs.created_on
WHERE hs.date_ BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 DAY)
AND hs.property_id = %s
ORDER BY hs.date_ ASC;
'''

query_for_hotel_status = '''SELECT hs.date_, hs.rooms_occ, hs.inhouse_persons, hs.arrival_rooms_count, hs.leave_rooms_count, hs.arrival_persons_count, hs.leave_persons_count
FROM (
    SELECT date_, MAX(created_on) AS max_created_on
    FROM hotel_status
    WHERE date_ BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 DAY)
    AND property_id = %s
    GROUP BY date_
) AS latest_dates
INNER JOIN hotel_status hs ON latest_dates.date_ = hs.date_ AND latest_dates.max_created_on = hs.created_on
WHERE hs.date_ BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 6 DAY)
AND hs.property_id = %s
ORDER BY hs.date_ ASC'''