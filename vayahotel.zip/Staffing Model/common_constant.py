CONST_FILE_NAME = "Input_Staffing.xlsx"
CONST_ZERO = 0
CONST_DATES = "Dates"
CONST_SIX = 6
CONST_HEADERS = ["", "Datum"]
CONST_ONE = 1
CONST_WEIGHTS = "Weights"
CONST_HEADERS_WEIGHTS = ["Model", "Weight"]
CONST_WEIGHT_DATA = [
    ("Theoretical Model", 0.00),
    ("Emperical Model", 0.50),
    ("Emperical Cluster Model", 0.50),
]
CONST_TWO = 2
CONST_HOTEL_MAPPING = {
    "Village Park Suite": "AVP",
    "VAYA Kaprun & Chalet Pistenpanorama": "VKP",
    "Residence Kristall": "ARK",
    "Residence Saalbach": "ARS",
    "Resort Achensee": "VAS",
    "VAYA Galtür": "VGT",
    "Hotel Pass Thurn": "VPT",
    "Hotel Vierjahreszeiten": "VJZ",
    "VAYA Kühtai": "VKT",
    "Hotel Victoria": "VIC",
    "VAYA Zillertal": "VZI",
    "VAYA Ladis": "VLA",
    "VAYA Post Saalbach": "VPS",
    "VAYA Gerlos": "VGE",
    "VAYA Sölden": "VSD",
    "VAYA Zell am See": "VZS",
    "VAYA St. Zeno": "VSZ",
    "VAYA St. Anton": "VSA",
    "Hotel Sportiv": "VOG",
    "The Crystal": "CRY",
    "VAYA Fieberbrunn": "VFB",
    "VAYA Seefeld": "VSF",
    "VAYA Nauders": "VND",
    "VAYA Pfunds": "VPF",
    "Vaya Zillertal": "VZI",
}
CONST_DATE = "date_"
CONST_SEVEN = 7
CONST_HALBPENSION = "halfboard"
CONST_FRUHSTUCK = "breakfast"
CONST_BREAKFASTS = "Breakfasts"
CONST_HALFBOARDS = "Halfboards"
CONST_RESERVATIONS = "Reservations"
CONST_COLUMNS = {
    "rooms_occ": "Occupied Rooms",
    "inhouse_persons": "Guests",
    "arrival_rooms_count": "New Rooms",
    "leave_rooms_count": "Departed Rooms",
    "arrival_persons_count": "New Guests",
    "leave_persons_count": "Departing Guests",
}
CONST_EIGHT = 8
CONST_FILE_CREATED = "Staffing input file generated successfully."
CONST_HYPHEN = "-"
CONST_DF_COLUMNS = [
    "Reservations",
    "Occupied Rooms",
    "Guests",
    "New Rooms",
    "Departed Rooms",
    "New Guests",
    "Departing Guests",
    "Breakfasts",
    "Halfboards",
]
CONST_OCCUPIED_ROOMS = "Occupied Rooms"
CONST_GUESTS = "Guests"
CONST_NEW_ROOMS = "New Rooms"
CONST_DEPARTED_ROOMS = "Departed Rooms"
CONST_NEW_GUESTS = "New Guests"
CONST_DEPARTING_GUESTS = "Departing Guests"

CONST_SENDER_MAIL = "rotlistngi@gmail.com"
CONST_SENDER_MAIL_PASSWORD = "wuzh qeyw cjnf fabj"
CONST_RECIPIENT_MAIL = "victor.roos@rotrip.nl"
CONST_RECIPIENT_CC_MAIL = "victor.roos@rotrip.nl"
CONST_SENDER_MAIL = "rotlistngi@gmail.com"
CONST_SENDER_MAIL_PASSWORD = "wuzh qeyw cjnf fabj"
CONST_PMS_EMAIL_SUBJECT = "Input Staffing {date}"
CONST_PMS_WEEKLY_EMAIL_SUBJECT = "Protel PMS Weekly Booking {from_date} to {to_date}"
CONST_PMS_BOOKINGS = "Protel_PMS_Bookings"
CONST_PMS_WEEKLY_BOOKINGS = "Protel_PMS_Weekly_Bookings"
CONST_PMS_FILTER_BOOKINGS_BY_ROOM_TYPE = "Protel_PMS_Bookings_With_Room_Type"
CONST_PROTEL_FORMAT_DATE = "%Y-%m-%d"
CONST_PLAIN = "plain"
CONST_FILE_READ_AND_BINARY_MODE = "rb"
CONST_APPLICATION = "application"
CONST_OCTET_STREAM = "octet-stream"
CONST_DISPLAY_CONTENT = "Content-Disposition"
CONST_ATTACHMENT = "attachment"
CONST_MAIL_SUCCESFULLY_SENT_MESSAGE = "Report sent to mail successfully"
CONST_MAIL_NOT_SENT_MESSAGE = "Report not sent"
CONST_MAIL_PORT_NUMBER = 587
CONST_SMTP_MAIL_ID = "smtp.gmail.com"

CONST_SMTP_SERVER = "smtp.gmail.com"
CONST_MIMENASE_HEADER_CONTENT = "Content-Disposition"


CONST_PMS_EMAIL_BODY = """
Hi Victor,
 
Weekly Input Staffing file for {start_date} to {end_date}, is now available for your review. You can access the report by opening the attached file to this email.
 

Thanks,
Vaya Bot
"""
EXCEL_RECORD_DATE_FORMAT = "%d-%m-%Y"

CONST_ERROR_WHILE_CONNECTING_TO_MARIADB = "Error while connecting to MariaDB :"
CONST_SHEET1 = "Sheet1"
CONST_CURSOR = "cursor"
CONST_CONNECTION = "connection"
CONST_PMS_START_DATE = 1
CONST_PMS_END_DATE = 6
DEFAULT_VALUE = 0
