#!/bin/bash

# Change to the project directory
cd /root/StaffingModel/ || exit

# Check if the virtual environment activation script exists
if [ -f "/root/StaffingModel/venv/bin/activate" ]; then
    # Activate the virtual environment
    source /root/StaffingModel/venv/bin/activate
    
    # Run the Python script
    python3 input_staffing.py
else
    echo "Virtual environment activation script not found. Please make sure the path is correct."
fi
